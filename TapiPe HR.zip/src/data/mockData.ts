import {
  Employee,
  AttendanceRecord,
  PayrollRecord,
  SalaryComponent,
  LeaveApplication,
  HolidayItem,
  DepartmentItem,
  DesignationItem,
  BranchItem,
  CandidateItem,
  JobPosting,
  DocumentItem,
  PerformanceGoal,
  AssetItem,
  SupportTicket,
  VisitorItem,
  NoticeItem,
  AuditLogItem,
  NotificationItem,
  CompanySettings,
  SalaryRules,
} from '../types';

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'EMP-101',
    name: 'Rohan Sharma',
    phone: '+91 98765 43210',
    email: 'rohan.sharma@tapipe.com',
    salary: 120000,
    department: 'Engineering',
    designation: 'Senior Lead Engineer',
    branch: 'Mumbai HQ',
    joiningDate: '2022-03-15',
    status: 'active',
    bankName: 'HDFC Bank',
    bankAccount: 'HDFC0001234987',
    ifscCode: 'HDFC0000123',
    panNumber: 'ABCPS1234F',
    aadhaarNumber: '4321-8765-1098',
    passportNumber: 'Z8901234',
    drivingLicense: 'MH02-2021-00987',
    pfNumber: 'MH/MUM/0012345/000/00101',
    esiNumber: '3100012345',
    uanNumber: '100987654321',
    dob: '1992-06-14',
    gender: 'Male',
    bloodGroup: 'O+',
    fatherName: 'Ramesh Sharma',
    emergencyContactName: 'Sunita Sharma (Wife)',
    emergencyContactPhone: '+91 98765 00000',
    emergencyRelation: 'Spouse',
    nomineeName: 'Sunita Sharma',
    nomineeRelation: 'Spouse',
    address: '402 Sunrise Towers, Powai, Mumbai, MH - 400076',
    highestQualification: 'B.Tech Computer Science (IIT Bombay)',
    experienceYears: 8,
    skills: ['React', 'Node.js', 'System Design', 'Fintech Payments', 'PostgreSQL'],
    insurancePolicyNo: 'STAR-HEALTH-998877',
    medicalConditions: 'None',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  },
  {
    id: 'EMP-102',
    name: 'Priya Patel',
    phone: '+91 98123 45678',
    email: 'priya.patel@tapipe.com',
    salary: 85000,
    department: 'HR',
    designation: 'HR Operations Manager',
    branch: 'Mumbai HQ',
    joiningDate: '2023-01-10',
    status: 'active',
    bankName: 'ICICI Bank',
    bankAccount: 'ICIC0005678123',
    ifscCode: 'ICIC0000567',
    panNumber: 'BNXPP5678K',
    aadhaarNumber: '8765-4321-9876',
    pfNumber: 'MH/MUM/0012345/000/00102',
    esiNumber: '3100012346',
    uanNumber: '100987654322',
    dob: '1994-09-21',
    gender: 'Female',
    bloodGroup: 'B+',
    emergencyContactName: 'Ketan Patel (Brother)',
    emergencyContactPhone: '+91 98123 00000',
    highestQualification: 'MBA in Human Resources (XLRI Jamshedpur)',
    experienceYears: 6,
    skills: ['Talent Acquisition', 'Payroll Compliance', 'Keka HR', 'Employee Relations'],
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
  },
  {
    id: 'EMP-103',
    name: 'Ananya Sen',
    phone: '+91 99887 76655',
    email: 'ananya.sen@tapipe.com',
    salary: 95000,
    department: 'Sales',
    designation: 'Senior Fintech Consultant',
    branch: 'Bengaluru Tech Hub',
    joiningDate: '2022-08-20',
    status: 'active',
    bankName: 'State Bank of India',
    bankAccount: 'SBIN0004321876',
    ifscCode: 'SBIN0000432',
    panNumber: 'CLPAS9876M',
    aadhaarNumber: '1234-5678-9012',
    pfNumber: 'KA/BLR/0098765/000/00103',
    uanNumber: '100987654323',
    dob: '1993-11-05',
    gender: 'Female',
    bloodGroup: 'A+',
    highestQualification: 'BBA Marketing & Finance',
    experienceYears: 7,
    skills: ['B2B Sales', 'Enterprise Accounts', 'Razorpay Integration', 'CRM'],
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
  },
  {
    id: 'EMP-104',
    name: 'Vikram Malhotra',
    phone: '+91 97654 32109',
    email: 'vikram.m@tapipe.com',
    salary: 140000,
    department: 'Finance',
    designation: 'Head of Payroll & Taxation',
    branch: 'Mumbai HQ',
    joiningDate: '2021-06-01',
    status: 'active',
    bankName: 'Axis Bank',
    bankAccount: 'UTIB0009876543',
    ifscCode: 'UTIB0000987',
    panNumber: 'DKPVM3456L',
    aadhaarNumber: '9988-7766-5544',
    pfNumber: 'MH/MUM/0012345/000/00104',
    uanNumber: '100987654324',
    dob: '1988-03-30',
    gender: 'Male',
    bloodGroup: 'AB+',
    highestQualification: 'Chartered Accountant (CA), M.Com',
    experienceYears: 11,
    skills: ['Corporate Taxation', 'PF & ESI Compliance', 'GST', 'Financial Auditing'],
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
  },
  {
    id: 'EMP-105',
    name: 'Aarav Mehta',
    phone: '+91 98234 56789',
    email: 'aarav.mehta@tapipe.com',
    salary: 78000,
    department: 'Design',
    designation: 'UI/UX Product Designer',
    branch: 'Mumbai HQ',
    joiningDate: '2023-05-12',
    status: 'active',
    bankName: 'Kotak Mahindra Bank',
    bankAccount: 'KKBK0002468135',
    ifscCode: 'KKBK0000246',
    panNumber: 'EPMAM6543R',
    aadhaarNumber: '5566-7788-9900',
    pfNumber: 'MH/MUM/0012345/000/00105',
    uanNumber: '100987654325',
    dob: '1996-01-18',
    gender: 'Male',
    bloodGroup: 'O+',
    highestQualification: 'B.Des (NID Ahmedabad)',
    experienceYears: 4,
    skills: ['Figma', 'Design Systems', 'Micro-interactions', 'Tailwind CSS'],
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
  },
  {
    id: 'EMP-106',
    name: 'Neha Gupta',
    phone: '+91 96543 21098',
    email: 'neha.gupta@tapipe.com',
    salary: 70000,
    department: 'Operations',
    designation: 'Operations Specialist',
    branch: 'Delhi NCR',
    joiningDate: '2023-09-01',
    status: 'active',
    bankName: 'Bank of Baroda',
    bankAccount: 'BARB0001357924',
    ifscCode: 'BARB0000135',
    panNumber: 'FRTNG8765Q',
    aadhaarNumber: '6677-8899-0011',
    pfNumber: 'DL/DEL/0054321/000/00106',
    uanNumber: '100987654326',
    dob: '1995-07-25',
    gender: 'Female',
    bloodGroup: 'A-',
    highestQualification: 'B.Com Honours (DU)',
    experienceYears: 5,
    skills: ['Vendor Management', 'Process Automation', 'MIS Reports'],
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
  },
  {
    id: 'EMP-107',
    name: 'Rahul Verma',
    phone: '+91 95432 10987',
    email: 'rahul.verma@tapipe.com',
    salary: 105000,
    department: 'Engineering',
    designation: 'Full Stack Developer',
    branch: 'Bengaluru Tech Hub',
    joiningDate: '2022-11-15',
    status: 'active',
    bankName: 'HDFC Bank',
    bankAccount: 'HDFC0004567891',
    ifscCode: 'HDFC0000456',
    panNumber: 'GHYRV4321P',
    aadhaarNumber: '7788-9900-1122',
    pfNumber: 'KA/BLR/0098765/000/00107',
    uanNumber: '100987654327',
    dob: '1993-04-12',
    gender: 'Male',
    bloodGroup: 'B+',
    highestQualification: 'M.Tech Software Engineering',
    experienceYears: 6,
    skills: ['Node.js', 'GraphQL', 'AWS', 'Docker', 'Next.js'],
    avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
  },
  {
    id: 'EMP-108',
    name: 'Kavita Singh',
    phone: '+91 94321 09876',
    email: 'kavita.singh@tapipe.com',
    salary: 62000,
    department: 'Sales',
    designation: 'Sales Associate',
    branch: 'Pune Office',
    joiningDate: '2024-02-01',
    status: 'on_leave',
    bankName: 'Canara Bank',
    bankAccount: 'CNRB0008765432',
    ifscCode: 'CNRB0000876',
    panNumber: 'HJKSK5678Z',
    aadhaarNumber: '8899-0011-2233',
    pfNumber: 'MH/PUN/0087654/000/00108',
    uanNumber: '100987654328',
    dob: '1997-12-08',
    gender: 'Female',
    bloodGroup: 'O-',
    highestQualification: 'B.Sc Economics',
    experienceYears: 2,
    skills: ['Lead Generation', 'Client Onboarding', 'HubSpot'],
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
  },
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: 'ATT-001',
    employeeId: 'EMP-101',
    employeeName: 'Rohan Sharma',
    date: '2026-07-31',
    checkIn: '09:15 AM',
    checkOut: '06:30 PM',
    status: 'present',
    workHours: 9.25,
    lateMinutes: 15,
    overtimeHours: 0.5,
    location: 'BKC HQ (Geo-verified)',
    method: 'GPS',
  },
  {
    id: 'ATT-002',
    employeeId: 'EMP-102',
    employeeName: 'Priya Patel',
    date: '2026-07-31',
    checkIn: '09:02 AM',
    checkOut: '06:00 PM',
    status: 'present',
    workHours: 8.96,
    lateMinutes: 2,
    location: 'BKC HQ (Scanner #2)',
    method: 'QR Code',
  },
  {
    id: 'ATT-003',
    employeeId: 'EMP-103',
    employeeName: 'Ananya Sen',
    date: '2026-07-31',
    checkIn: '08:55 AM',
    checkOut: '06:15 PM',
    status: 'wfh',
    workHours: 9.33,
    notes: 'Approved Work From Home',
    location: 'Bengaluru (Remote)',
    method: 'GPS',
  },
  {
    id: 'ATT-004',
    employeeId: 'EMP-104',
    employeeName: 'Vikram Malhotra',
    date: '2026-07-31',
    checkIn: '08:50 AM',
    checkOut: '06:45 PM',
    status: 'present',
    workHours: 9.9,
    location: 'BKC HQ (Turnstile #1)',
    method: 'Biometric',
  },
  {
    id: 'ATT-005',
    employeeId: 'EMP-105',
    employeeName: 'Aarav Mehta',
    date: '2026-07-31',
    checkIn: '10:00 AM',
    checkOut: '02:00 PM',
    status: 'half_day',
    workHours: 4.0,
    notes: 'Medical Appointment',
    location: 'BKC HQ',
    method: 'Face ID',
  },
  {
    id: 'ATT-006',
    employeeId: 'EMP-106',
    employeeName: 'Neha Gupta',
    date: '2026-07-31',
    checkIn: '09:10 AM',
    checkOut: '06:10 PM',
    status: 'present',
    workHours: 9.0,
    location: 'Delhi Office',
    method: 'QR Code',
  },
  {
    id: 'ATT-007',
    employeeId: 'EMP-107',
    employeeName: 'Rahul Verma',
    date: '2026-07-31',
    checkIn: undefined,
    checkOut: undefined,
    status: 'absent',
    workHours: 0,
    notes: 'Unannounced Absence',
    method: 'Manual',
  },
  {
    id: 'ATT-008',
    employeeId: 'EMP-108',
    employeeName: 'Kavita Singh',
    date: '2026-07-31',
    checkIn: undefined,
    checkOut: undefined,
    status: 'on_leave',
    workHours: 0,
    notes: 'Approved Casual Leave',
  },
];

export function generateInitialPayroll(employees: Employee[], rules?: SalaryRules): PayrollRecord[] {
  const pfEnabled = rules ? rules.pfEnabled : true;
  const esiEnabled = rules ? rules.esiEnabled : true;
  const ptEnabled = rules ? rules.ptEnabled : true;
  const tdsEnabled = rules ? rules.tdsEnabled : true;
  const loanEnabled = rules ? rules.loanEnabled : true;
  const overtimeEnabled = rules ? rules.overtimeEnabled : true;
  const bonusEnabled = rules ? rules.bonusEnabled : true;
  const lateDeductionEnabled = rules ? rules.lateDeductionEnabled : true;
  const reimbursementEnabled = rules ? rules.reimbursementEnabled : true;

  const pfRate = (rules?.pfPercentage ?? 12) / 100;
  const esiRate = (rules?.esiPercentage ?? 0.75) / 100;
  const stdDays = rules?.standardWorkingDays ?? 26;

  return employees.map((emp) => {
    const base = Math.round(emp.salary * 0.5); // 50% Basic
    const hra = Math.round(base * 0.4); // 40% of Basic HRA
    const specialAllowance = Math.round(emp.salary - (base + hra));
    const medicalAllowance = 1250;
    const travelAllowance = 1600;
    const internetAllowance = 1000;
    
    const workingDays = stdDays;
    const presentDays = emp.status === 'on_leave' ? 22 : emp.id === 'EMP-107' ? 21 : 25;
    const halfDays = emp.id === 'EMP-105' ? 1 : 0;
    const paidLeaves = emp.status === 'on_leave' ? 3 : 1;
    
    const effectiveDays = presentDays + (halfDays * 0.5) + paidLeaves;
    const earnedSalary = Math.round((emp.salary / workingDays) * Math.min(effectiveDays, workingDays));
    
    const rawBonus = emp.id === 'EMP-101' ? 8000 : emp.id === 'EMP-104' ? 12000 : 3000;
    const bonus = bonusEnabled ? rawBonus : 0;

    const rawOvertime = emp.id === 'EMP-101' ? 2500 : 0;
    const overtimePay = overtimeEnabled ? rawOvertime : 0;

    const reimbursements = reimbursementEnabled ? 1500 : 0;

    // Deductions
    const pfDeduction = pfEnabled ? Math.round(base * pfRate) : 0;
    const esiDeduction = (esiEnabled && emp.salary <= 21000) ? Math.round(emp.salary * esiRate) : 0;
    const tdsDeduction = tdsEnabled ? (emp.salary > 100000 ? Math.round(emp.salary * 0.1) : emp.salary > 70000 ? Math.round(emp.salary * 0.05) : 0) : 0;
    const professionalTax = ptEnabled ? 200 : 0;
    const loanDeduction = (loanEnabled && emp.id === 'EMP-107') ? 2000 : 0;
    const latePenalty = (lateDeductionEnabled && emp.id === 'EMP-101') ? 300 : 0;

    const grossSalary = earnedSalary + bonus + overtimePay + reimbursements;
    const totalDeductions = pfDeduction + esiDeduction + tdsDeduction + professionalTax + loanDeduction + latePenalty;
    const netSalary = Math.max(0, grossSalary - totalDeductions);

    return {
      id: `PAY-${emp.id.replace('EMP-', '')}-202607`,
      employeeId: emp.id,
      employeeName: emp.name,
      department: emp.department,
      designation: emp.designation,
      month: 'July 2026',
      baseSalary: base,
      hra,
      specialAllowance,
      medicalAllowance,
      travelAllowance,
      internetAllowance,
      bonus,
      overtimePay,
      reimbursements,
      workingDays,
      presentDays,
      halfDays,
      paidLeaves,
      earnedSalary,
      pfDeduction,
      esiDeduction,
      tdsDeduction,
      professionalTax,
      loanDeduction,
      latePenalty,
      grossSalary,
      netSalary,
      status: 'processed',
      paymentDate: '2026-07-31',
      paymentMode: 'Bank Transfer',
      transactionId: `TXN${Math.floor(1000000000 + Math.random() * 9000000000)}`,
    };
  });
}

export const INITIAL_SALARY_COMPONENTS: SalaryComponent[] = [
  { id: 'SC-01', name: 'Basic Salary', type: 'earning', calculationType: 'percentage_base', value: 50, taxable: true, status: 'active' },
  { id: 'SC-02', name: 'House Rent Allowance (HRA)', type: 'earning', calculationType: 'percentage_base', value: 20, taxable: true, status: 'active' },
  { id: 'SC-03', name: 'Special Allowance', type: 'earning', calculationType: 'percentage_base', value: 30, taxable: true, status: 'active' },
  { id: 'SC-04', name: 'Medical Allowance', type: 'earning', calculationType: 'flat', value: 1250, taxable: false, status: 'active' },
  { id: 'SC-05', name: 'Travel & Conveyance', type: 'earning', calculationType: 'flat', value: 1600, taxable: false, status: 'active' },
  { id: 'SC-06', name: 'Provident Fund (PF)', type: 'deduction', calculationType: 'percentage_base', value: 12, taxable: false, status: 'active' },
  { id: 'SC-07', name: 'Employee State Insurance (ESI)', type: 'deduction', calculationType: 'percentage_base', value: 0.75, taxable: false, status: 'active' },
  { id: 'SC-08', name: 'Professional Tax (PT)', type: 'deduction', calculationType: 'flat', value: 200, taxable: false, status: 'active' },
];

export const INITIAL_LEAVE_APPLICATIONS: LeaveApplication[] = [
  {
    id: 'LV-101',
    employeeId: 'EMP-108',
    employeeName: 'Kavita Singh',
    department: 'Sales',
    type: 'Casual Leave',
    startDate: '2026-07-30',
    endDate: '2026-07-31',
    daysCount: 2,
    reason: 'Family function in hometown Pune',
    status: 'approved',
    appliedDate: '2026-07-25',
    approvedBy: 'Sumit (Super Admin)',
  },
  {
    id: 'LV-102',
    employeeId: 'EMP-105',
    employeeName: 'Aarav Mehta',
    department: 'Design',
    type: 'Sick Leave',
    startDate: '2026-08-03',
    endDate: '2026-08-04',
    daysCount: 2,
    reason: 'Fever and doctor rest advice',
    status: 'pending',
    appliedDate: '2026-07-30',
  },
  {
    id: 'LV-103',
    employeeId: 'EMP-103',
    employeeName: 'Ananya Sen',
    department: 'Sales',
    type: 'Comp Off',
    startDate: '2026-08-10',
    endDate: '2026-08-10',
    daysCount: 1,
    reason: 'Worked on weekend for Razorpay client deployment',
    status: 'approved',
    appliedDate: '2026-07-28',
    approvedBy: 'Priya Patel (HR)',
  },
  {
    id: 'LV-104',
    employeeId: 'EMP-107',
    employeeName: 'Rahul Verma',
    department: 'Engineering',
    type: 'Paid Leave',
    startDate: '2026-08-18',
    endDate: '2026-08-22',
    daysCount: 5,
    reason: 'Annual family vacation',
    status: 'pending',
    appliedDate: '2026-07-31',
  },
];

export const INITIAL_HOLIDAYS: HolidayItem[] = [
  { id: 'HOL-01', date: '2026-08-15', name: 'Independence Day', day: 'Saturday', type: 'National', branch: 'All Branches' },
  { id: 'HOL-02', date: '2026-08-28', name: 'Raksha Bandhan', day: 'Friday', type: 'Regional', branch: 'Mumbai HQ, Delhi NCR' },
  { id: 'HOL-03', date: '2026-09-04', name: 'Ganesh Chaturthi', day: 'Friday', type: 'Regional', branch: 'Mumbai HQ, Pune' },
  { id: 'HOL-04', date: '2026-10-02', name: 'Gandhi Jayanti', day: 'Friday', type: 'National', branch: 'All Branches' },
  { id: 'HOL-05', date: '2026-10-20', name: 'Dussehra', day: 'Tuesday', type: 'National', branch: 'All Branches' },
  { id: 'HOL-06', date: '2026-11-08', name: 'Diwali (Laxmi Pujan)', day: 'Sunday', type: 'National', branch: 'All Branches' },
  { id: 'HOL-07', date: '2026-12-25', name: 'Christmas', day: 'Friday', type: 'National', branch: 'All Branches' },
];

export const INITIAL_DEPARTMENTS: DepartmentItem[] = [
  { id: 'DEP-01', name: 'Engineering', code: 'ENG', headName: 'Rohan Sharma', employeeCount: 12, monthlyBudget: 1400000 },
  { id: 'DEP-02', name: 'HR & People Ops', code: 'HR', headName: 'Priya Patel', employeeCount: 4, monthlyBudget: 350000 },
  { id: 'DEP-03', name: 'Sales & Growth', code: 'SAL', headName: 'Ananya Sen', employeeCount: 8, monthlyBudget: 750000 },
  { id: 'DEP-04', name: 'Finance & Taxation', code: 'FIN', headName: 'Vikram Malhotra', employeeCount: 3, monthlyBudget: 420000 },
  { id: 'DEP-05', name: 'UI/UX Design', code: 'DES', headName: 'Aarav Mehta', employeeCount: 3, monthlyBudget: 300000 },
  { id: 'DEP-06', name: 'Operations', code: 'OPS', headName: 'Neha Gupta', employeeCount: 5, monthlyBudget: 450000 },
];

export const INITIAL_DESIGNATIONS: DesignationItem[] = [
  { id: 'DSG-01', title: 'Senior Lead Engineer', department: 'Engineering', level: 'L5', minSalary: 110000, maxSalary: 180000 },
  { id: 'DSG-02', title: 'Full Stack Developer', department: 'Engineering', level: 'L3', minSalary: 70000, maxSalary: 120000 },
  { id: 'DSG-03', title: 'HR Operations Manager', department: 'HR & People Ops', level: 'L4', minSalary: 75000, maxSalary: 110000 },
  { id: 'DSG-04', title: 'Senior Fintech Consultant', department: 'Sales & Growth', level: 'L4', minSalary: 80000, maxSalary: 130000 },
  { id: 'DSG-05', title: 'UI/UX Product Designer', department: 'UI/UX Design', level: 'L3', minSalary: 65000, maxSalary: 95000 },
];

export const INITIAL_BRANCHES: BranchItem[] = [
  { id: 'BR-01', name: 'Mumbai HQ', code: 'MUM01', city: 'Mumbai', state: 'Maharashtra', address: '302 Fintech Towers, BKC, Mumbai 400051', employeeCount: 18 },
  { id: 'BR-02', name: 'Bengaluru Tech Hub', code: 'BLR01', city: 'Bengaluru', state: 'Karnataka', address: '7th Floor, Outer Ring Rd, Bellandur, Bengaluru 560103', employeeCount: 12 },
  { id: 'BR-03', name: 'Delhi NCR Office', code: 'DEL01', city: 'Gurugram', state: 'Haryana', address: 'Tower B, Cyber City, Phase 2, Gurugram 122002', employeeCount: 5 },
  { id: 'BR-04', name: 'Pune Innovation Center', code: 'PUN01', city: 'Pune', state: 'Maharashtra', address: 'Kharadi IT Park, Hinjawadi Phase 1, Pune 411057', employeeCount: 3 },
];

export const INITIAL_CANDIDATES: CandidateItem[] = [
  {
    id: 'CND-101',
    name: 'Siddharth Roy',
    email: 'siddharth.roy@gmail.com',
    phone: '+91 91234 56789',
    position: 'DevOps & Cloud Engineer',
    department: 'Engineering',
    experienceYears: 5,
    stage: 'Technical Round',
    expectedCtc: 110000,
    appliedDate: '2026-07-20',
    rating: 4.5,
  },
  {
    id: 'CND-102',
    name: 'Meera Deshmukh',
    email: 'meera.d@yahoo.com',
    phone: '+91 92345 67890',
    position: 'Product Marketing Manager',
    department: 'Sales & Growth',
    experienceYears: 4,
    stage: 'HR Round',
    expectedCtc: 85000,
    appliedDate: '2026-07-22',
    rating: 4.0,
  },
  {
    id: 'CND-103',
    name: 'Karan Malhotra',
    email: 'karan.m@gmail.com',
    phone: '+91 93456 78901',
    position: 'Backend Developer (Go/Node)',
    department: 'Engineering',
    experienceYears: 3,
    stage: 'Offered',
    expectedCtc: 90000,
    appliedDate: '2026-07-15',
    rating: 4.8,
  },
];

export const INITIAL_JOBS: JobPosting[] = [
  { id: 'JOB-01', title: 'Senior DevOps & Cloud Engineer', department: 'Engineering', location: 'Mumbai HQ / Remote', openings: 2, type: 'Full-time', status: 'Active', applicantsCount: 18, postedDate: '2026-07-10' },
  { id: 'JOB-02', title: 'Product Marketing Manager', department: 'Sales & Growth', location: 'Bengaluru Tech Hub', openings: 1, type: 'Full-time', status: 'Active', applicantsCount: 12, postedDate: '2026-07-14' },
  { id: 'JOB-03', title: 'Fintech Compliance Auditor', department: 'Finance & Taxation', location: 'Mumbai HQ', openings: 1, type: 'Full-time', status: 'Active', applicantsCount: 8, postedDate: '2026-07-18' },
];

export const INITIAL_DOCUMENTS: DocumentItem[] = [
  { id: 'DOC-101', employeeId: 'EMP-101', employeeName: 'Rohan Sharma', type: 'Offer Letter', title: 'Employment Offer Letter - Sr Lead Engineer', issuedDate: '2022-03-01', status: 'Issued' },
  { id: 'DOC-102', employeeId: 'EMP-101', employeeName: 'Rohan Sharma', type: 'Appointment Letter', title: 'Official Appointment Letter', issuedDate: '2022-03-15', status: 'Issued' },
  { id: 'DOC-103', employeeId: 'EMP-102', employeeName: 'Priya Patel', type: 'Promotion Letter', title: 'HR Manager Promotion Letter', issuedDate: '2024-01-01', status: 'Issued' },
  { id: 'DOC-104', employeeId: 'EMP-104', employeeName: 'Vikram Malhotra', type: 'ID Card', title: 'TapiPE Smart RFID Employee Card', issuedDate: '2021-06-01', status: 'Issued' },
];

export const INITIAL_PERFORMANCE_GOALS: PerformanceGoal[] = [
  { id: 'GOL-01', employeeId: 'EMP-101', employeeName: 'Rohan Sharma', goalTitle: 'Deploy Instant Payout API Engine', kpiMetrics: '99.99% Uptime & <100ms latency', targetDate: '2026-08-31', progressPercent: 85, rating: 5, status: 'In Progress' },
  { id: 'GOL-02', employeeId: 'EMP-102', employeeName: 'Priya Patel', goalTitle: 'Reduce Employee Onboarding Time to 24 Hrs', kpiMetrics: '100% digital KYC & document verification', targetDate: '2026-09-15', progressPercent: 90, rating: 4.8, status: 'In Progress' },
  { id: 'GOL-03', employeeId: 'EMP-105', employeeName: 'Aarav Mehta', goalTitle: 'Redesign Payroll Dashboard UI', kpiMetrics: 'Razorpay / Linear level design quality', targetDate: '2026-07-31', progressPercent: 100, rating: 5, status: 'Achieved' },
];

export const INITIAL_ASSETS: AssetItem[] = [
  { id: 'AST-01', assetTag: 'TAP-LAP-001', name: 'MacBook Pro M3 Max 16"', category: 'Laptop', serialNumber: 'C02G100987', assignedEmployeeId: 'EMP-101', assignedEmployeeName: 'Rohan Sharma', issueDate: '2022-03-15', condition: 'Brand New' },
  { id: 'AST-02', assetTag: 'TAP-LAP-002', name: 'MacBook Air M2 15"', category: 'Laptop', serialNumber: 'C02F200456', assignedEmployeeId: 'EMP-102', assignedEmployeeName: 'Priya Patel', issueDate: '2023-01-10', condition: 'Good' },
  { id: 'AST-03', assetTag: 'TAP-MON-001', name: 'Dell UltraSharp 27" 4K Monitor', category: 'Monitor', serialNumber: 'CN-098765-1122', assignedEmployeeId: 'EMP-105', assignedEmployeeName: 'Aarav Mehta', issueDate: '2023-05-12', condition: 'Good' },
  { id: 'AST-04', assetTag: 'TAP-LAP-003', name: 'Lenovo ThinkPad X1 Carbon', category: 'Laptop', serialNumber: 'PF-30098711', assignedEmployeeId: 'EMP-104', assignedEmployeeName: 'Vikram Malhotra', issueDate: '2021-06-01', condition: 'Good' },
  { id: 'AST-05', assetTag: 'TAP-LAP-004', name: 'MacBook Pro M2 Pro 14"', category: 'Laptop', serialNumber: 'C02H300123', assignedEmployeeId: undefined, assignedEmployeeName: undefined, condition: 'Brand New' },
];

export const INITIAL_SUPPORT_TICKETS: SupportTicket[] = [
  { id: 'TCK-01', ticketNo: 'TICK-901', employeeName: 'Rahul Verma', category: 'IT Support', subject: 'Docker memory issue on M2 MacBook', priority: 'High', status: 'In Progress', createdAt: '2026-07-30 11:30 AM' },
  { id: 'TCK-02', ticketNo: 'TICK-902', employeeName: 'Kavita Singh', category: 'Payroll Discrepancy', subject: 'Tax deduction discrepancy in June payslip', priority: 'Medium', status: 'Resolved', createdAt: '2026-07-28 03:15 PM' },
  { id: 'TCK-03', ticketNo: 'TICK-903', employeeName: 'Aarav Mehta', category: 'Admin & Facilities', subject: 'Ergonomic chair replacement request', priority: 'Low', status: 'Open', createdAt: '2026-07-31 09:45 AM' },
];

export const INITIAL_VISITORS: VisitorItem[] = [
  { id: 'VIS-01', visitorName: 'Sameer Singhania', company: 'Razorpay Partner Team', phone: '+91 98989 12345', hostEmployee: 'Sumit (Super Admin)', purpose: 'Strategic Fintech Partnership Discussion', checkInTime: '10:30 AM', checkOutTime: '01:15 PM', badgeNumber: 'VIS-089', status: 'Checked Out' },
  { id: 'VIS-02', visitorName: 'Dr. Archana Kulkarni', company: 'Star Health Insurance', phone: '+91 97979 54321', hostEmployee: 'Priya Patel', purpose: 'Annual Employee Health Insurance Renewal', checkInTime: '02:00 PM', badgeNumber: 'VIS-090', status: 'Inside' },
];

export const INITIAL_NOTICES: NoticeItem[] = [
  { id: 'NTC-01', title: 'Form 16 Tax Filing Available for FY 2025-26', category: 'Policy Update', content: 'All employees can now download their signed Form 16 Part A & B directly from the Document Center module.', publishedDate: '2026-07-20', author: 'Vikram Malhotra (Finance)', pinned: true },
  { id: 'NTC-02', title: 'Independence Day Holiday & Special Townhall', category: 'Holiday Notice', content: 'TapiPE HR offices will remain closed on Saturday, August 15, 2026. Join us for virtual Townhall on Aug 14.', publishedDate: '2026-07-28', author: 'Priya Patel (HR)', pinned: true },
  { id: 'NTC-03', title: 'New Health Insurance Wellness Perks Added', category: 'Announcement', content: 'Free annual preventive health checkups are now available at Apollo Clinics with TapiPE ID Card.', publishedDate: '2026-07-25', author: 'HR Ops', pinned: false },
];

export const INITIAL_AUDIT_LOGS: AuditLogItem[] = [
  { id: 'LOG-01', user: 'Sumit (Super Admin)', role: 'Super Admin', action: 'GENERATED_PAYROLL_BULK', module: 'Payroll', ipAddress: '103.22.41.9', timestamp: '2026-07-31 10:15 AM' },
  { id: 'LOG-02', user: 'Priya Patel', role: 'HR Manager', action: 'APPROVED_LEAVE_APPLICATION', module: 'Leave', ipAddress: '103.22.41.14', timestamp: '2026-07-30 04:30 PM' },
  { id: 'LOG-03', user: 'Rohan Sharma', role: 'Staff', action: 'CLOCK_IN_GPS_VERIFIED', module: 'Attendance', ipAddress: '157.33.20.5', timestamp: '2026-07-31 09:15 AM' },
  { id: 'LOG-04', user: 'Vikram Malhotra', role: 'Admin', action: 'UPDATE_COMPANY_TAX_RULES', module: 'Settings', ipAddress: '103.22.41.9', timestamp: '2026-07-29 02:00 PM' },
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'NOT-1',
    title: 'July 2026 Payroll Processed',
    message: 'Monthly salary calculation for 8 active employees completed successfully.',
    time: '10 mins ago',
    type: 'payroll',
    read: false,
  },
  {
    id: 'NOT-2',
    title: 'New Leave Request Received',
    message: 'Aarav Mehta submitted a sick leave application for 2 days.',
    time: '1 hour ago',
    type: 'info',
    read: false,
  },
  {
    id: 'NOT-3',
    title: 'Tax Filing Deadline',
    message: 'Form 16 TDS submission deadline is approaching in 5 days.',
    time: 'Yesterday',
    type: 'warning',
    read: true,
  },
];

export const INITIAL_COMPANY_SETTINGS: CompanySettings = {
  companyName: 'TapiPE Fintech Pvt. Ltd.',
  legalEntity: 'TapiPE Fintech Private Limited',
  address: '302 Fintech Towers, Bandra Kurla Complex (BKC)',
  city: 'Mumbai',
  state: 'Maharashtra',
  pincode: '400051',
  gstin: '27AAAAA0000A1Z5',
  panNumber: 'AAACT1234F',
  contactEmail: 'payroll@tapipe.com',
  contactPhone: '+91 22 6789 0000',
  currency: 'INR (₹)',
  payCycleDay: 31,
  pfRegistrationNo: 'MH/MUM/0012345/000',
  esiRegistrationNo: '3100012345001',
  companyLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200',
  darkLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200',
  lightLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200',
  faviconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100',
  website: 'https://tapipe.in',
  bankName: 'HDFC Bank Ltd.',
  bankAccountNo: '50200012345678',
  ifscCode: 'HDFC0000001',
  digitalSignatureUrl: 'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?w=200',
};

export const INITIAL_SALARY_RULES: SalaryRules = {
  standardWorkingDays: 26,
  pfPercentage: 12,
  esiPercentage: 0.75,
  overtimeRatePerHour: 250,
  allowancesPercent: 20,
  pfEnabled: true,
  esiEnabled: true,
  ptEnabled: true,
  tdsEnabled: true,
  loanEnabled: true,
  overtimeEnabled: true,
  nightShiftEnabled: true,
  bonusEnabled: true,
  lateDeductionEnabled: true,
  reimbursementEnabled: true,
};

export const INITIAL_LEAVE_TYPES = [
  { id: 'LT-01', name: 'Casual Leave', code: 'CL', maxDaysPerYear: 12, paid: true, carryForward: false, description: 'Short personal time off' },
  { id: 'LT-02', name: 'Sick Leave', code: 'SL', maxDaysPerYear: 12, paid: true, carryForward: true, description: 'Medical emergencies & illness' },
  { id: 'LT-03', name: 'Earned / Privilege Leave', code: 'EL', maxDaysPerYear: 15, paid: true, carryForward: true, description: 'Annual planned vacations' },
  { id: 'LT-04', name: 'Maternity Leave', code: 'ML', maxDaysPerYear: 180, paid: true, carryForward: false, description: 'Maternity statutory leave' },
  { id: 'LT-05', name: 'Paternity Leave', code: 'PL', maxDaysPerYear: 15, paid: true, carryForward: false, description: 'New father parental time off' },
];

export const INITIAL_DOCUMENT_TEMPLATES = [
  {
    id: 'TMPL-01',
    type: 'Offer Letter',
    title: 'Standard Employee Offer Letter',
    category: 'Onboarding',
    templateBody: 'Dear {{EMPLOYEE_NAME}},\n\nWe are pleased to offer you the position of {{DESIGNATION}} in {{DEPARTMENT}} at {{COMPANY_NAME}}.\nYour monthly compensation will be ₹{{SALARY}}.\nJoining Date: {{JOINING_DATE}}.\n\nSincerely,\n{{SIGNATORY}}',
    lastUpdated: '2026-07-25',
    isCustom: false,
  },
  {
    id: 'TMPL-02',
    type: 'Appointment Letter',
    title: 'Official Employment Appointment Letter',
    category: 'Onboarding',
    templateBody: 'Dear {{EMPLOYEE_NAME}},\n\nThis letter confirms your formal appointment as {{DESIGNATION}} at {{COMPANY_NAME}} starting {{JOINING_DATE}}.\nLocation: {{BRANCH}}.\n\nSincerely,\n{{SIGNATORY}}',
    lastUpdated: '2026-07-26',
    isCustom: false,
  },
  {
    id: 'TMPL-03',
    type: 'Warning Letter',
    title: 'Formal Workplace Performance Warning',
    category: 'Compliance',
    templateBody: 'Dear {{EMPLOYEE_NAME}},\n\nThis letter serves as a formal warning regarding workplace compliance and performance standards in {{DEPARTMENT}}.\n\nIssued by HR,\n{{COMPANY_NAME}}',
    lastUpdated: '2026-07-20',
    isCustom: false,
  },
  {
    id: 'TMPL-04',
    type: 'Experience Letter',
    title: 'Relieving & Experience Certificate',
    category: 'Offboarding',
    templateBody: 'To Whom It May Concern,\n\nThis is to certify that {{EMPLOYEE_NAME}} served as {{DESIGNATION}} at {{COMPANY_NAME}} from {{JOINING_DATE}} to {{EXIT_DATE}}.\nTheir performance was exemplary.\n\nSincerely,\n{{SIGNATORY}}',
    lastUpdated: '2026-07-22',
    isCustom: false,
  },
  {
    id: 'TMPL-05',
    type: 'Relieving Letter',
    title: 'Official Clearance & Relieving Order',
    category: 'Offboarding',
    templateBody: 'Dear {{EMPLOYEE_NAME}},\n\nYour resignation has been accepted and you are formally relieved of duties as {{DESIGNATION}} from {{COMPANY_NAME}}.\nAll dues cleared.\n\nSincerely,\n{{SIGNATORY}}',
    lastUpdated: '2026-07-22',
    isCustom: false,
  },
  {
    id: 'TMPL-06',
    type: 'Confirmation Letter',
    title: 'Probation Confirmation Letter',
    category: 'Onboarding',
    templateBody: 'Dear {{EMPLOYEE_NAME}},\n\nWe are pleased to inform you that you have successfully completed your probation as {{DESIGNATION}} in {{DEPARTMENT}}.\n\nSincerely,\n{{SIGNATORY}}',
    lastUpdated: '2026-07-24',
    isCustom: false,
  },
];

export const MONTHLY_SALARY_TRENDS = [
  { month: 'Jan', amount: 580000 },
  { month: 'Feb', amount: 595000 },
  { month: 'Mar', amount: 610000 },
  { month: 'Apr', amount: 615000 },
  { month: 'May', amount: 630000 },
  { month: 'Jun', amount: 627000 },
  { month: 'Jul', amount: 755000 },
];
