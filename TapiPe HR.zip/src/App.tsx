import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { EmployeeManagement } from './components/EmployeeManagement';
import { Attendance } from './components/Attendance';
import { Payroll } from './components/Payroll';
import { SalaryStructure } from './components/SalaryStructure';
import { LeaveManagement } from './components/LeaveManagement';
import { HolidayCalendar } from './components/HolidayCalendar';
import { DepartmentsBranches } from './components/DepartmentsBranches';
import { Recruitment } from './components/Recruitment';
import { DocumentCenter } from './components/DocumentCenter';
import { Performance } from './components/Performance';
import { AssetsInventory } from './components/AssetsInventory';
import { VisitorHelpdesk } from './components/VisitorHelpdesk';
import { NoticesAnnouncements } from './components/NoticesAnnouncements';
import { Reports } from './components/Reports';
import { UserAccess } from './components/UserAccess';
import { Settings } from './components/Settings';
import { AuditLogsView } from './components/AuditLogsView';
import { PayslipModal } from './components/PayslipModal';
import { AIChatbot } from './components/AIChatbot';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { ProfileModal } from './components/ProfileModal';
import { LoginView } from './components/LoginView';
import { AccessDenied } from './components/AccessDenied';

import {
  NavigationPage,
  UserRole,
  UserAccount,
  Employee,
  AttendanceRecord,
  PayrollRecord,
  NotificationItem,
  CompanySettings,
  SalaryRules,
  AttendanceStatus,
  SalaryComponent,
  LeaveApplication,
  HolidayItem,
  DepartmentItem,
  DesignationItem,
  BranchItem,
  CandidateItem,
  DocumentItem,
  PerformanceReview,
  GoalItem,
  AssetCustomItem,
  SupportTicket,
  VisitorLog,
  CompanyNotice,
} from './types';

import {
  loadUsersFromStorage,
  saveUsersToStorage,
  loadSessionFromStorage,
  saveSessionToStorage,
  getDefaultPermissionsForRole,
  getDefaultRedirectPageForRole,
} from './services/authStore';

import {
  INITIAL_EMPLOYEES,
  INITIAL_ATTENDANCE,
  generateInitialPayroll,
  INITIAL_NOTIFICATIONS,
  INITIAL_COMPANY_SETTINGS,
  INITIAL_SALARY_RULES,
  MONTHLY_SALARY_TRENDS,
  INITIAL_SALARY_COMPONENTS,
  INITIAL_LEAVE_APPLICATIONS,
  INITIAL_HOLIDAYS,
  INITIAL_DEPARTMENTS,
  INITIAL_DESIGNATIONS,
  INITIAL_BRANCHES,
  INITIAL_CANDIDATES,
  INITIAL_JOBS,
  INITIAL_DOCUMENTS,
  INITIAL_DOCUMENT_TEMPLATES,
  INITIAL_ASSETS,
  INITIAL_SUPPORT_TICKETS,
  INITIAL_VISITORS,
  INITIAL_AUDIT_LOGS,
} from './data/mockData';

export default function App() {
  // Authentication & Users State
  const [users, setUsers] = useState<UserAccount[]>(() => loadUsersFromStorage());
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => loadSessionFromStorage());

  // Navigation Page
  const [currentPage, setCurrentPage] = useState<NavigationPage>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);

  // Theme Mode
  const [isDarkMode, setIsDarkMode] = useState<boolean>(
    () => localStorage.getItem('tapipe_theme') === 'dark'
  );

  // Core Collections State with LocalStorage Persistence
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('tapipe_employees');
    return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
  });
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('tapipe_attendance');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });
  const [payroll, setPayroll] = useState<PayrollRecord[]>(() => {
    const saved = localStorage.getItem('tapipe_payroll');
    return saved ? JSON.parse(saved) : generateInitialPayroll(INITIAL_EMPLOYEES);
  });
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [companySettings, setCompanySettings] = useState<CompanySettings>(INITIAL_COMPANY_SETTINGS);
  const [salaryRules, setSalaryRules] = useState<SalaryRules>(INITIAL_SALARY_RULES);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('tapipe_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('tapipe_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('tapipe_payroll', JSON.stringify(payroll));
  }, [payroll]);

  // Extra Functional Modules State
  const [salaryComponents, setSalaryComponents] = useState<SalaryComponent[]>(INITIAL_SALARY_COMPONENTS);
  const [leaveApplications, setLeaveApplications] = useState<LeaveApplication[]>(INITIAL_LEAVE_APPLICATIONS);
  const [holidays, setHolidays] = useState<HolidayItem[]>(INITIAL_HOLIDAYS);
  const [departments, setDepartments] = useState<DepartmentItem[]>(INITIAL_DEPARTMENTS);
  const [designations, setDesignations] = useState<DesignationItem[]>(INITIAL_DESIGNATIONS);
  const [branches, setBranches] = useState<BranchItem[]>(INITIAL_BRANCHES);
  const [candidates, setCandidates] = useState<CandidateItem[]>(INITIAL_CANDIDATES);
  const [documents, setDocuments] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [documentTemplates, setDocumentTemplates] = useState(INITIAL_DOCUMENT_TEMPLATES);
  const [performanceReviews, setPerformanceReviews] = useState<PerformanceReview[]>([
    {
      id: 'REV-01',
      employeeId: 'EMP-101',
      employeeName: 'Rohan Sharma',
      department: 'Engineering',
      reviewerName: 'Sumit (Super Admin)',
      reviewPeriod: 'Q2 2026',
      rating: 4.9,
      promoted: true,
      comments: 'Exceeded all architectural goals and delivered instant payout APIs.',
    },
    {
      id: 'REV-02',
      employeeId: 'EMP-102',
      employeeName: 'Priya Patel',
      department: 'HR Operations',
      reviewerName: 'Sumit (Super Admin)',
      reviewPeriod: 'Q2 2026',
      rating: 4.7,
      promoted: false,
      comments: 'Streamlined onboarding compliance across all 4 branch offices.',
    },
  ]);
  const [goals, setGoals] = useState<GoalItem[]>([
    {
      id: 'GOL-01',
      employeeId: 'EMP-101',
      employeeName: 'Rohan Sharma',
      title: 'Deploy Instant Payout API Engine',
      category: 'KPI Target',
      targetDate: '2026-08-31',
      progress: 85,
      status: 'In Progress',
    },
    {
      id: 'GOL-02',
      employeeId: 'EMP-102',
      employeeName: 'Priya Patel',
      title: 'Reduce Employee Onboarding Time to 24 Hrs',
      category: 'Process Improvement',
      targetDate: '2026-09-15',
      progress: 90,
      status: 'In Progress',
    },
  ]);
  const [assets, setAssets] = useState<AssetCustomItem[]>([
    {
      id: 'AST-01',
      name: 'MacBook Pro M3 Max 16-inch',
      category: 'Laptop',
      serialNumber: 'C02G100987',
      assignedToEmployeeName: 'Rohan Sharma',
      assignedDate: '2022-03-15',
      status: 'Assigned',
      warrantyExpiry: '2028-12-31',
    },
    {
      id: 'AST-02',
      name: 'Dell UltraSharp 27-inch 4K Monitor',
      category: 'Monitor',
      serialNumber: 'CN-098765-1122',
      assignedToEmployeeName: 'Aarav Mehta',
      assignedDate: '2023-05-12',
      status: 'Assigned',
      warrantyExpiry: '2027-05-12',
    },
  ]);
  const [tickets, setTickets] = useState<SupportTicket[]>([
    {
      id: 'TCK-01',
      employeeId: 'EMP-107',
      employeeName: 'Rahul Verma',
      category: 'IT Support',
      subject: 'Docker memory issue on M2 MacBook',
      description: 'Docker desktop crashing on high loads.',
      priority: 'High',
      status: 'In Progress',
      createdDate: '2026-07-30',
    },
  ]);
  const [visitors, setVisitors] = useState<VisitorLog[]>([
    {
      id: 'VIS-01',
      visitorName: 'Sameer Singhania',
      phone: '+91 98989 12345',
      company: 'Razorpay Partner Team',
      purpose: 'Strategic Fintech Partnership',
      hostEmployeeName: 'Sumit (Super Admin)',
      checkInTime: '10:30 AM',
      date: '2026-07-31',
      status: 'Checked Out',
    },
  ]);
  const [notices, setNotices] = useState<CompanyNotice[]>([
    {
      id: 'NTC-01',
      title: 'Form 16 Tax Filing Available for FY 2025-26',
      content: 'All employees can now download their signed Form 16 Part A & B directly from the Document Center module.',
      category: 'HR Policy',
      postedBy: 'Vikram Malhotra (Finance)',
      postedDate: '2026-07-20',
      isPinned: true,
    },
    {
      id: 'NTC-02',
      title: 'Independence Day Holiday & Special Townhall',
      content: 'TapiPE HR offices will remain closed on Saturday, August 15, 2026. Join us for virtual Townhall on Aug 14.',
      category: 'Event',
      postedBy: 'Priya Patel (HR)',
      postedDate: '2026-07-28',
      isPinned: true,
    },
  ]);

  // Modal Visibility
  const [isAIChatOpen, setIsAIChatOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  const handleUpdateCurrentUser = (patch: Partial<UserAccount>) => {
    if (!currentUser) return;
    const updated = { ...currentUser, ...patch };
    setCurrentUser(updated);
    localStorage.setItem('tapipe_session_user', JSON.stringify(updated));
    setUsers(users.map((u) => (u.id === updated.id ? updated : u)));
  };
  const [isAddEmployeeModalOpen, setIsAddEmployeeModalOpen] = useState<boolean>(false);
  const [activePayslipRecord, setActivePayslipRecord] = useState<PayrollRecord | null>(null);

  // Apply Dark Class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Save users to storage on update
  const handleUsersUpdate = (newUsers: UserAccount[]) => {
    setUsers(newUsers);
    saveUsersToStorage(newUsers);
  };

  // Auth Handlers
  const handleLoginSuccess = (user: UserAccount, rememberMe: boolean) => {
    setCurrentUser(user);
    saveSessionToStorage(user, rememberMe);

    // Redirect according to role
    const defaultPage = getDefaultRedirectPageForRole(user.role);
    setCurrentPage(defaultPage);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    saveSessionToStorage(null);
  };

  const handleRoleChangeSimulate = (newRole: UserRole) => {
    if (!currentUser) return;
    const updatedUser: UserAccount = {
      ...currentUser,
      role: newRole,
      permissions: getDefaultPermissionsForRole(newRole),
    };
    setCurrentUser(updatedUser);
    saveSessionToStorage(updatedUser, true);

    // Ensure user lands on allowed page after role switch
    const defaultPage = getDefaultRedirectPageForRole(newRole);
    setCurrentPage(defaultPage);
  };

  // User Management Actions (Super Admin)
  const handleAddUser = (newUserData: Omit<UserAccount, 'id' | 'createdAt'>) => {
    const newUser: UserAccount = {
      ...newUserData,
      id: `USR-${String(users.length + 1).padStart(3, '0')}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    const updated = [...users, newUser];
    handleUsersUpdate(updated);
  };

  const handleUpdateUser = (updatedUser: UserAccount) => {
    const updated = users.map((u) => (u.id === updatedUser.id ? updatedUser : u));
    handleUsersUpdate(updated);

    if (currentUser && currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser);
      saveSessionToStorage(updatedUser, true);
    }
  };

  const handleDeleteUser = (id: string) => {
    const updated = users.filter((u) => u.id !== id);
    handleUsersUpdate(updated);
  };

  const handleToggleDisableUser = (id: string) => {
    const updated = users.map((u) => (u.id === id ? { ...u, isDisabled: !u.isDisabled } : u));
    handleUsersUpdate(updated);
  };

  const handleResetPassword = (id: string, newPass: string) => {
    const updated = users.map((u) => (u.id === id ? { ...u, password: newPass } : u));
    handleUsersUpdate(updated);
    alert('Password updated successfully!');
  };

  // Payroll Recalculations
  const recalculatePayroll = (empList: Employee[]) => {
    setPayroll(generateInitialPayroll(empList));
  };

  // Handlers for Employees
  const handleAddEmployee = (newEmpData: Omit<Employee, 'id'>) => {
    const newId = `EMP-${101 + employees.length}`;
    const newEmp: Employee = {
      ...newEmpData,
      id: newId,
    };
    const updatedList = [newEmp, ...employees];
    setEmployees(updatedList);
    recalculatePayroll(updatedList);

    setAttendance((prev) => [
      {
        id: `ATT-${Date.now()}`,
        employeeId: newId,
        employeeName: newEmp.name,
        date: new Date().toISOString().split('T')[0],
        status: 'present',
        checkIn: '09:00 AM',
        checkOut: '06:00 PM',
        workHours: 9.0,
      },
      ...prev,
    ]);

    setNotifications((prev) => [
      {
        id: `NOT-${Date.now()}`,
        title: 'New Employee Onboarded',
        message: `${newEmp.name} added to ${newEmp.department} department.`,
        time: 'Just now',
        type: 'info',
        read: false,
      },
      ...prev,
    ]);
  };

  const handleUpdateEmployee = (updatedEmp: Employee) => {
    const updatedList = employees.map((e) => (e.id === updatedEmp.id ? updatedEmp : e));
    setEmployees(updatedList);
    recalculatePayroll(updatedList);
  };

  const handleDeleteEmployee = (id: string) => {
    const updatedList = employees.filter((e) => e.id !== id);
    setEmployees(updatedList);
    setAttendance((prev) => prev.filter((a) => a.employeeId !== id));
    setPayroll((prev) => prev.filter((p) => p.employeeId !== id));
  };

  // Handlers for Attendance
  const handleUpdateAttendanceStatus = (
    employeeId: string,
    status: AttendanceStatus,
    checkIn?: string,
    checkOut?: string
  ) => {
    setAttendance((prev) =>
      prev.map((att) => {
        if (att.employeeId === employeeId) {
          return {
            ...att,
            status,
            checkIn: checkIn || (status === 'present' ? '09:15 AM' : att.checkIn),
            checkOut: checkOut || (status === 'present' ? '06:15 PM' : att.checkOut),
            workHours: status === 'present' ? 9.0 : status === 'half_day' ? 4.0 : 0,
          };
        }
        return att;
      })
    );
  };

  // Handlers for Payroll
  const handleUpdatePayrollBonusDeduction = (id: string, bonus: number, deduction: number) => {
    setPayroll((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const totalDeductions = p.pfDeduction + p.esiDeduction + p.tdsDeduction + deduction;
          const newNet = Math.max(0, p.earnedSalary + bonus - totalDeductions);
          return {
            ...p,
            bonus,
            deduction,
            netSalary: newNet,
          };
        }
        return p;
      })
    );
  };

  const handleProcessAllPayroll = () => {
    setPayroll((prev) =>
      prev.map((p) => ({
        ...p,
        status: 'paid',
        paymentDate: new Date().toISOString().split('T')[0],
      }))
    );

    setNotifications((prev) => [
      {
        id: `NOT-${Date.now()}`,
        title: 'July 2026 Payroll Processed',
        message: 'Direct bank disbursement completed for all active employees.',
        time: 'Just now',
        type: 'payroll',
        read: false,
      },
      ...prev,
    ]);

    alert('✅ July 2026 Payroll Batch successfully processed & bank transfers initiated!');
  };

  // Leave Handlers
  const handleApproveLeave = (id: string) => {
    setLeaveApplications((prev) =>
      prev.map((l) => (l.id === id ? { ...l, status: 'approved' } : l))
    );
  };

  const handleRejectLeave = (id: string) => {
    setLeaveApplications((prev) =>
      prev.map((l) => (l.id === id ? { ...l, status: 'rejected' } : l))
    );
  };

  const handleApplyLeave = (leave: LeaveApplication) => {
    setLeaveApplications([leave, ...leaveApplications]);
  };

  // Render Login View if not logged in
  if (!currentUser) {
    return <LoginView users={users} onLoginSuccess={handleLoginSuccess} />;
  }

  // Permission Check for current page
  const hasPagePermission =
    currentUser.role === 'super_admin'
      ? true
      : currentUser.permissions
      ? currentUser.permissions[currentPage] ?? false
      : true;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors">
      {/* Sidebar */}
      <Sidebar
        currentPage={currentPage}
        currentUser={currentUser}
        onNavigate={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        openAIChat={() => setIsAIChatOpen(true)}
        unreadNotificationsCount={notifications.filter((n) => !n.read).length}
      />

      {/* Main Container */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <Header
          currentUser={currentUser}
          onRoleChange={handleRoleChangeSimulate}
          onLogout={handleLogout}
          isDarkMode={isDarkMode}
          onToggleTheme={() => setIsDarkMode(!isDarkMode)}
          openAIChat={() => setIsAIChatOpen(true)}
          openSearch={() => setIsSearchOpen(true)}
          openProfileModal={() => setIsProfileModalOpen(true)}
          notifications={notifications}
          onMarkNotificationRead={(id) =>
            setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
          }
          onClearNotifications={() => setNotifications([])}
          companyName={companySettings.companyName}
        />

        {/* Dynamic Navigation Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar">
          {!hasPagePermission ? (
            <AccessDenied
              currentUser={currentUser}
              targetPage={currentPage}
              onNavigateHome={() => setCurrentPage('dashboard')}
            />
          ) : (
            <>
              {currentPage === 'dashboard' && (
                <Dashboard
                  employees={employees}
                  attendance={attendance}
                  payroll={payroll}
                  monthlyTrends={MONTHLY_SALARY_TRENDS}
                  onNavigate={setCurrentPage}
                  role={currentUser.role}
                  onOpenAddEmployee={() => setIsAddEmployeeModalOpen(true)}
                  onOpenCheckInModal={() => setCurrentPage('attendance')}
                  onOpenPayslipModal={(rec) => setActivePayslipRecord(rec)}
                />
              )}

              {currentPage === 'employees' && (
                <EmployeeManagement
                  employees={employees}
                  role={currentUser.role}
                  onAddEmployee={handleAddEmployee}
                  onUpdateEmployee={handleUpdateEmployee}
                  onDeleteEmployee={handleDeleteEmployee}
                  isAddModalOpen={isAddEmployeeModalOpen}
                  onCloseAddModal={() => setIsAddEmployeeModalOpen(false)}
                />
              )}

              {currentPage === 'attendance' && (
                <Attendance
                  attendance={attendance}
                  employees={employees}
                  role={currentUser.role}
                  onUpdateAttendanceStatus={handleUpdateAttendanceStatus}
                  isCheckInModalOpen={false}
                  onCloseCheckInModal={() => {}}
                />
              )}

              {currentPage === 'payroll' && (
                <Payroll
                  payroll={payroll}
                  salaryRules={salaryRules}
                  role={currentUser.role}
                  onUpdatePayrollBonusDeduction={handleUpdatePayrollBonusDeduction}
                  onOpenPayslipModal={(rec) => setActivePayslipRecord(rec)}
                  onProcessAllPayroll={handleProcessAllPayroll}
                />
              )}

              {currentPage === 'salary_structure' && (
                <SalaryStructure
                  components={salaryComponents}
                  rules={salaryRules}
                  onUpdateRules={(r) => setSalaryRules(r)}
                  onAddComponent={(comp) => setSalaryComponents([...salaryComponents, comp])}
                />
              )}

              {currentPage === 'leave_management' && (
                <LeaveManagement
                  leaves={leaveApplications}
                  onApprove={handleApproveLeave}
                  onReject={handleRejectLeave}
                  onApplyLeave={handleApplyLeave}
                />
              )}

              {currentPage === 'holiday_calendar' && (
                <HolidayCalendar
                  holidays={holidays}
                  onAddHoliday={(h) => setHolidays([...holidays, h])}
                />
              )}

              {currentPage === 'departments_branches' && (
                <DepartmentsBranches
                  departments={departments}
                  designations={designations}
                  branches={branches}
                  onAddDept={(d) => setDepartments([...departments, d])}
                  onAddBranch={(b) => setBranches([...branches, b])}
                />
              )}

              {currentPage === 'recruitment' && (
                <Recruitment
                  candidates={candidates}
                  jobs={INITIAL_JOBS}
                  onAddCandidate={(c) => setCandidates([...candidates, c])}
                  onUpdateStage={(id, stage) =>
                    setCandidates((prev) => prev.map((c) => (c.id === id ? { ...c, stage } : c)))
                  }
                />
              )}

              {currentPage === 'document_center' && (
                <DocumentCenter
                  documents={documents}
                  employees={employees}
                  templates={documentTemplates}
                  onAddDocument={(doc) => setDocuments([doc, ...documents])}
                  onSaveTemplate={(tmpl) => {
                    const exists = documentTemplates.some((t) => t.id === tmpl.id);
                    if (exists) {
                      setDocumentTemplates(documentTemplates.map((t) => (t.id === tmpl.id ? tmpl : t)));
                    } else {
                      setDocumentTemplates([tmpl, ...documentTemplates]);
                    }
                  }}
                  onDeleteTemplate={(tmplId) =>
                    setDocumentTemplates(documentTemplates.filter((t) => t.id !== tmplId))
                  }
                />
              )}

              {currentPage === 'performance' && (
                <Performance
                  reviews={performanceReviews}
                  goals={goals}
                  onAddReview={(rev) => setPerformanceReviews([rev, ...performanceReviews])}
                  onAddGoal={(g) => setGoals([...goals, g])}
                />
              )}

              {currentPage === 'assets_inventory' && (
                <AssetsInventory
                  assets={assets}
                  onAddAsset={(ast) => setAssets([...assets, ast])}
                />
              )}

              {currentPage === 'visitor_helpdesk' && (
                <VisitorHelpdesk
                  tickets={tickets}
                  visitors={visitors}
                  onAddTicket={(t) => setTickets([t, ...tickets])}
                  onAddVisitor={(v) => setVisitors([v, ...visitors])}
                />
              )}

              {currentPage === 'notices_announcements' && (
                <NoticesAnnouncements
                  notices={notices}
                  onAddNotice={(n) => setNotices([...notices, n])}
                />
              )}

              {currentPage === 'reports' && (
                <Reports
                  employees={employees}
                  attendance={attendance}
                  payroll={payroll}
                />
              )}

              {currentPage === 'access' && (
                <UserAccess
                  currentUser={currentUser}
                  users={users}
                  onAddUser={handleAddUser}
                  onUpdateUser={handleUpdateUser}
                  onDeleteUser={handleDeleteUser}
                  onToggleDisableUser={handleToggleDisableUser}
                  onResetPassword={handleResetPassword}
                  onRoleChange={handleRoleChangeSimulate}
                />
              )}

              {currentPage === 'settings' && (
                <Settings
                  companySettings={companySettings}
                  salaryRules={salaryRules}
                  onSaveSettings={(s, r) => {
                    setCompanySettings(s);
                    setSalaryRules(r);
                  }}
                />
              )}

              {currentPage === 'audit_logs' && (
                <AuditLogsView logs={INITIAL_AUDIT_LOGS} />
              )}
            </>
          )}
        </main>
      </div>

      {/* Global Modals */}
      <PayslipModal
        record={activePayslipRecord}
        companySettings={companySettings}
        onClose={() => setActivePayslipRecord(null)}
      />

      <AIChatbot
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        employees={employees}
        payroll={payroll}
        attendance={attendance}
      />

      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        employees={employees}
        payroll={payroll}
        onNavigate={setCurrentPage}
        onOpenPayslipModal={(rec) => setActivePayslipRecord(rec)}
      />

      {isProfileModalOpen && currentUser && (
        <ProfileModal
          currentUser={currentUser}
          onUpdateUser={handleUpdateCurrentUser}
          onClose={() => setIsProfileModalOpen(false)}
        />
      )}
    </div>
  );
}
