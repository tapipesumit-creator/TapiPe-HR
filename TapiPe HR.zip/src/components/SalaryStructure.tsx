import React, { useState } from 'react';
import { Layers, Plus, Check, Edit2, Trash2, DollarSign, Calculator, ShieldCheck } from 'lucide-react';
import { SalaryComponent, SalaryRules } from '../types';

interface SalaryStructureProps {
  components: SalaryComponent[];
  rules: SalaryRules;
  onUpdateRules: (rules: SalaryRules) => void;
  onAddComponent: (component: SalaryComponent) => void;
}

export const SalaryStructure: React.FC<SalaryStructureProps> = ({
  components: initialComponents,
  rules,
  onUpdateRules,
  onAddComponent,
}) => {
  const [componentsList, setComponentsList] = useState<SalaryComponent[]>(initialComponents);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCompName, setNewCompName] = useState('');
  const [newCompType, setNewCompType] = useState<'earning' | 'deduction'>('earning');
  const [newCalcType, setNewCalcType] = useState<'flat' | 'percentage_base'>('percentage_base');
  const [newValue, setNewValue] = useState(10);
  const [newTaxable, setNewTaxable] = useState(true);

  // Salary Calculator Simulation State
  const [testCtc, setTestCtc] = useState<number>(100000);

  // Calculation Breakdown
  const basicSalary = Math.round(testCtc * (rules.allowancesPercent ? 0.5 : 0.5)); // 50%
  const hra = Math.round(basicSalary * 0.4); // 40% of basic
  const specialAllowance = Math.round(testCtc - (basicSalary + hra));
  const pf = Math.round(basicSalary * (rules.pfPercentage / 100));
  const esi = testCtc > 21000 ? 0 : Math.round(testCtc * (rules.esiPercentage / 100));
  const tds = testCtc > 100000 ? Math.round(testCtc * 0.1) : testCtc > 70000 ? Math.round(testCtc * 0.05) : 0;
  const netInHand = testCtc - (pf + esi + tds + 200);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompName.trim()) return;

    const item: SalaryComponent = {
      id: `SC-${Date.now()}`,
      name: newCompName,
      type: newCompType,
      calculationType: newCalcType,
      value: Number(newValue),
      taxable: newTaxable,
      status: 'active',
    };

    setComponentsList([...componentsList, item]);
    onAddComponent(item);
    setShowAddModal(false);
    setNewCompName('');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Salary Architecture
            </span>
            <span className="text-xs text-slate-400">Indian Statutory Rules</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Salary Structure & Components
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Configure Basic, HRA, Special Allowance, PF 12%, ESI, and Tax Deduction Slabs.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-600/30 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          Add Salary Component
        </button>
      </div>

      {/* Live Calculator & Rules Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-time CTC Salary Breakdown Simulator */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <Calculator className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Instant CTC Simulator</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Test monthly gross to net in-hand</p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Monthly Gross CTC (₹)
            </label>
            <input
              type="number"
              value={testCtc}
              onChange={(e) => setTestCtc(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-bold text-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60 space-y-2 text-xs">
            <div className="flex justify-between font-bold text-slate-800 dark:text-slate-200">
              <span>Basic Salary (50%):</span>
              <span className="font-mono">₹{basicSalary.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>HRA (40% of Basic):</span>
              <span className="font-mono">₹{hra.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>Special Allowance:</span>
              <span className="font-mono">₹{specialAllowance.toLocaleString('en-IN')}</span>
            </div>
            <div className="border-t border-purple-200 dark:border-purple-800 pt-2 flex justify-between font-bold text-rose-600 dark:text-rose-400">
              <span>Statutory Deductions (PF+ESI+TDS+PT):</span>
              <span className="font-mono">-₹{(pf + esi + tds + 200).toLocaleString('en-IN')}</span>
            </div>
            <div className="border-t border-purple-300 dark:border-purple-700 pt-2 flex justify-between text-sm font-extrabold text-emerald-700 dark:text-emerald-400">
              <span>Net In-Hand Salary:</span>
              <span className="font-mono">₹{netInHand.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Global Statutory Settings */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Statutory Rules & Defaults</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">EPFO, ESIC, Income Tax parameters</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="font-bold text-slate-700 dark:text-slate-300">Standard Working Days / Month</span>
              <input
                type="number"
                value={rules.standardWorkingDays}
                onChange={(e) => onUpdateRules({ ...rules, standardWorkingDays: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-bold text-slate-900 dark:text-white mt-1"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="font-bold text-slate-700 dark:text-slate-300">PF Employee Contribution (%)</span>
              <input
                type="number"
                value={rules.pfPercentage}
                onChange={(e) => onUpdateRules({ ...rules, pfPercentage: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-bold text-slate-900 dark:text-white mt-1"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="font-bold text-slate-700 dark:text-slate-300">ESI Rate (%) (&lt;₹21k gross)</span>
              <input
                type="number"
                step="0.05"
                value={rules.esiPercentage}
                onChange={(e) => onUpdateRules({ ...rules, esiPercentage: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-bold text-slate-900 dark:text-white mt-1"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="font-bold text-slate-700 dark:text-slate-300">Overtime Rate (₹ / Hour)</span>
              <input
                type="number"
                value={rules.overtimeRatePerHour}
                onChange={(e) => onUpdateRules({ ...rules, overtimeRatePerHour: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-bold text-slate-900 dark:text-white mt-1"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Salary Components Table */}
      <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Active Salary Components</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Earnings & Statutory Deductions</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                <th className="p-3.5">Component Name</th>
                <th className="p-3.5">Type</th>
                <th className="p-3.5">Calculation Basis</th>
                <th className="p-3.5">Value / Percentage</th>
                <th className="p-3.5">Taxable</th>
                <th className="p-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
              {componentsList.map((comp) => (
                <tr key={comp.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                  <td className="p-3.5 font-bold text-slate-900 dark:text-white">{comp.name}</td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                        comp.type === 'earning'
                          ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300'
                          : 'bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300'
                      }`}
                    >
                      {comp.type}
                    </span>
                  </td>
                  <td className="p-3.5">
                    {comp.calculationType === 'percentage_base' ? '% of Base Salary' : 'Flat Monthly Amount'}
                  </td>
                  <td className="p-3.5 font-mono font-bold">
                    {comp.calculationType === 'percentage_base' ? `${comp.value}%` : `₹${comp.value}`}
                  </td>
                  <td className="p-3.5">
                    {comp.taxable ? (
                      <span className="text-emerald-600 font-semibold">Taxable</span>
                    ) : (
                      <span className="text-slate-400">Exempt</span>
                    )}
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-bold text-[10px]">
                      Active
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Component Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Add Salary Component</h3>
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Internet Allowance, Bonus"
                  value={newCompName}
                  onChange={(e) => setNewCompName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Type</label>
                  <select
                    value={newCompType}
                    onChange={(e) => setNewCompType(e.target.value as 'earning' | 'deduction')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    <option value="earning">Earning</option>
                    <option value="deduction">Deduction</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Basis</label>
                  <select
                    value={newCalcType}
                    onChange={(e) => setNewCalcType(e.target.value as 'flat' | 'percentage_base')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    <option value="percentage_base">% Base</option>
                    <option value="flat">Flat ₹ Amount</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Value</label>
                <input
                  type="number"
                  value={newValue}
                  onChange={(e) => setNewValue(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="taxableCheck"
                  checked={newTaxable}
                  onChange={(e) => setNewTaxable(e.target.checked)}
                  className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
                />
                <label htmlFor="taxableCheck" className="font-semibold text-slate-700 dark:text-slate-300">
                  Is Taxable Income
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold"
                >
                  Save Component
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
