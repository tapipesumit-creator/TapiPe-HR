import React, { useState } from 'react';
import {
  Building2,
  Lock,
  Mail,
  Shield,
  ArrowRight,
  AlertCircle,
  Eye,
  EyeOff,
  UserCheck,
  CheckCircle2,
} from 'lucide-react';
import { UserAccount } from '../types';
import { INITIAL_DEFAULT_USERS } from '../services/authStore';

interface LoginViewProps {
  users: UserAccount[];
  onLoginSuccess: (user: UserAccount, rememberMe: boolean) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ users, onLoginSuccess }) => {
  const [email, setEmail] = useState('admin@tapipe.in');
  const [password, setPassword] = useState('Admin@123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmedEmail = email.trim().toLowerCase();
    const foundUser = users.find((u) => u.email.toLowerCase() === trimmedEmail);

    if (!foundUser) {
      setErrorMsg('User account not found with this email address.');
      return;
    }

    if (foundUser.isDisabled) {
      setErrorMsg('This account has been disabled by the Super Admin. Please contact IT support.');
      return;
    }

    if (foundUser.password !== password) {
      setErrorMsg('Incorrect password. Please verify and try again.');
      return;
    }

    // Success!
    onLoginSuccess(foundUser, rememberMe);
  };

  const handleQuickLogin = (defaultUserEmail: string, defaultUserPass: string) => {
    setEmail(defaultUserEmail);
    setPassword(defaultUserPass);
    setErrorMsg('');

    const foundUser = users.find((u) => u.email.toLowerCase() === defaultUserEmail.toLowerCase());
    if (foundUser) {
      if (foundUser.isDisabled) {
        setErrorMsg('Account is disabled by Super Admin.');
        return;
      }
      onLoginSuccess(foundUser, true);
    }
  };

  return (
    <div className="min-h-screen w-screen flex flex-col justify-center items-center bg-slate-950 text-slate-100 p-4 sm:p-6 font-sans relative overflow-x-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10 space-y-6">
        {/* Header Branding */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-emerald-400 text-white shadow-xl shadow-indigo-500/20 mb-2">
            <Building2 className="w-7 h-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            TapiPE HR Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 font-medium">
            Role-Based Access Control & Enterprise Payroll System
          </p>
        </div>

        {/* Login Form Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-indigo-400" />
              Account Authentication
            </span>
            <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              SOC-2 Secured
            </span>
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            {/* Email Field */}
            <div>
              <label className="block font-bold text-slate-300 mb-1.5">Corporate Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                <input
                  type="email"
                  required
                  placeholder="admin@tapipe.in"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-800 bg-slate-950 text-white font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all placeholder:text-slate-600"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label className="block font-bold text-slate-300 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-800 bg-slate-950 text-white font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all placeholder:text-slate-600"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-400 font-medium select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 bg-slate-950 border-slate-800 focus:ring-indigo-500"
                />
                Remember me on this browser
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 hover:from-indigo-500 hover:to-purple-500 text-white font-extrabold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all mt-2"
            >
              Sign In to Portal
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Quick Test Accounts Grid */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between px-1">
            <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider">
              Quick 1-Click Role Login
            </span>
            <span className="text-[10px] text-indigo-400 font-semibold">Auto-Seeded Users</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {/* Super Admin */}
            <button
              onClick={() => handleQuickLogin('admin@tapipe.in', 'Admin@123')}
              className="p-3 rounded-2xl bg-purple-950/40 border border-purple-500/30 hover:border-purple-400 text-left transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-purple-200 group-hover:text-white">
                  Super Admin (Sumit)
                </span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                  Full Control
                </span>
              </div>
              <div className="text-[10px] text-purple-300/70 font-mono">admin@tapipe.in | Admin@123</div>
            </button>

            {/* Admin */}
            <button
              onClick={() => handleQuickLogin('admin1@tapipe.in', 'Admin@123')}
              className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 hover:border-indigo-400 text-left transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-indigo-200 group-hover:text-white">Admin</span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                  Ops & Payroll
                </span>
              </div>
              <div className="text-[10px] text-indigo-300/70 font-mono">admin1@tapipe.in | Admin@123</div>
            </button>

            {/* HR */}
            <button
              onClick={() => handleQuickLogin('hr@tapipe.in', 'Hr@123')}
              className="p-3 rounded-2xl bg-pink-950/40 border border-pink-500/30 hover:border-pink-400 text-left transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-pink-200 group-hover:text-white">HR Manager</span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-pink-500/20 text-pink-300">
                  HR Portal
                </span>
              </div>
              <div className="text-[10px] text-pink-300/70 font-mono">hr@tapipe.in | Hr@123</div>
            </button>

            {/* Staff */}
            <button
              onClick={() => handleQuickLogin('staff@tapipe.in', 'Staff@123')}
              className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 hover:border-emerald-400 text-left transition-all group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-emerald-200 group-hover:text-white">Staff Member</span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                  Staff View
                </span>
              </div>
              <div className="text-[10px] text-emerald-300/70 font-mono">staff@tapipe.in | Staff@123</div>
            </button>

            {/* Employee */}
            <button
              onClick={() => handleQuickLogin('employee@tapipe.in', 'Employee@123')}
              className="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/30 hover:border-amber-400 text-left transition-all group sm:col-span-2"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-amber-200 group-hover:text-white">
                  Employee Self-Service (Kavita)
                </span>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                  Employee Portal
                </span>
              </div>
              <div className="text-[10px] text-amber-300/70 font-mono">
                employee@tapipe.in | Employee@123
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
