import React, { useState } from 'react';
import { CalendarHeart, Plus, CheckCircle2, XCircle, Clock, Filter, User } from 'lucide-react';
import { LeaveApplication } from '../types';

interface LeaveManagementProps {
  leaves: LeaveApplication[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onApplyLeave: (leave: LeaveApplication) => void;
}

export const LeaveManagement: React.FC<LeaveManagementProps> = ({
  leaves,
  onApprove,
  onReject,
  onApplyLeave,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showApplyModal, setShowApplyModal] = useState(false);

  const [employeeName, setEmployeeName] = useState('Aarav Mehta');
  const [type, setType] = useState<LeaveApplication['type']>('Casual Leave');
  const [startDate, setStartDate] = useState('2026-08-10');
  const [endDate, setEndDate] = useState('2026-08-11');
  const [reason, setReason] = useState('Personal work');

  const filteredLeaves = leaves.filter((l) => {
    if (filterStatus === 'all') return true;
    return l.status === filterStatus;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLeave: LeaveApplication = {
      id: `LV-${Date.now()}`,
      employeeId: 'EMP-105',
      employeeName,
      department: 'Design',
      type,
      startDate,
      endDate,
      daysCount: 2,
      reason,
      status: 'pending',
      appliedDate: new Date().toISOString().split('T')[0],
    };
    onApplyLeave(newLeave);
    setShowApplyModal(false);
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Leave & Approvals
            </span>
            <span className="text-xs text-slate-400">Casual, Sick, Paid, Maternity & Comp-Off</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Leave Management Workflow
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Approve employee requests, monitor leave quotas, and prevent overlap conflicts.
          </p>
        </div>

        <button
          onClick={() => setShowApplyModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          Apply for Leave
        </button>
      </div>

      {/* Leave Quota Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Casual Leave (CL)</div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white">12 Days / Year</div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">Avg 8 Remaining</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Sick Leave (SL)</div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white">12 Days / Year</div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">Avg 10 Remaining</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Earned / Paid Leave (PL)</div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white">18 Days / Year</div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">Avg 14 Remaining</div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Maternity / Paternity</div>
          <div className="mt-2 text-2xl font-extrabold text-slate-900 dark:text-white">26 / 2 Weeks</div>
          <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold mt-1">Statutory Benefit</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex items-center justify-between bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-700 dark:text-slate-200">Filter Status:</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          {['all', 'pending', 'approved', 'rejected'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-xl font-bold capitalize transition-all ${
                filterStatus === st
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Leave Requests Table */}
      <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                <th className="p-3.5">Employee</th>
                <th className="p-3.5">Leave Type</th>
                <th className="p-3.5">Duration</th>
                <th className="p-3.5">Days</th>
                <th className="p-3.5">Reason</th>
                <th className="p-3.5">Applied Date</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
              {filteredLeaves.map((leave) => (
                <tr key={leave.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                  <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                    {leave.employeeName}
                    <span className="block text-[10px] font-normal text-slate-400">{leave.department}</span>
                  </td>
                  <td className="p-3.5 font-bold text-indigo-600 dark:text-indigo-400">{leave.type}</td>
                  <td className="p-3.5">
                    {leave.startDate} to {leave.endDate}
                  </td>
                  <td className="p-3.5 font-bold">{leave.daysCount} days</td>
                  <td className="p-3.5 max-w-xs truncate text-slate-600 dark:text-slate-300">{leave.reason}</td>
                  <td className="p-3.5 text-slate-400">{leave.appliedDate}</td>
                  <td className="p-3.5">
                    {leave.status === 'approved' && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-bold text-[10px] flex items-center gap-1 w-max">
                        <CheckCircle2 className="w-3 h-3" /> Approved
                      </span>
                    )}
                    {leave.status === 'pending' && (
                      <span className="px-2.5 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-bold text-[10px] flex items-center gap-1 w-max animate-pulse">
                        <Clock className="w-3 h-3" /> Pending
                      </span>
                    )}
                    {leave.status === 'rejected' && (
                      <span className="px-2.5 py-1 rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 font-bold text-[10px] flex items-center gap-1 w-max">
                        <XCircle className="w-3 h-3" /> Rejected
                      </span>
                    )}
                  </td>
                  <td className="p-3.5 text-right space-x-2">
                    {leave.status === 'pending' && (
                      <>
                        <button
                          onClick={() => onApprove(leave.id)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow-2xs"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => onReject(leave.id)}
                          className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] shadow-2xs"
                        >
                          Reject
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Apply Leave Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Apply for Leave</h3>
            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Employee Name</label>
                <input
                  type="text"
                  required
                  value={employeeName}
                  onChange={(e) => setEmployeeName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Leave Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                >
                  <option value="Casual Leave">Casual Leave</option>
                  <option value="Sick Leave">Sick Leave</option>
                  <option value="Paid Leave">Paid Leave</option>
                  <option value="Comp Off">Comp Off</option>
                  <option value="Maternity Leave">Maternity Leave</option>
                  <option value="Paternity Leave">Paternity Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Reason</label>
                <textarea
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  Submit Leave
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
