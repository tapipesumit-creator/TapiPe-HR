import React, { useState } from 'react';
import { Target, Star, TrendingUp, Plus, Award, UserCheck } from 'lucide-react';
import { PerformanceReview, GoalItem } from '../types';

interface PerformanceProps {
  reviews: PerformanceReview[];
  goals: GoalItem[];
  onAddReview: (r: PerformanceReview) => void;
  onAddGoal: (g: GoalItem) => void;
}

export const Performance: React.FC<PerformanceProps> = ({
  reviews: initialReviews,
  goals: initialGoals,
  onAddReview,
  onAddGoal,
}) => {
  const [reviewList, setReviewList] = useState<PerformanceReview[]>(initialReviews);
  const [goalList, setGoalList] = useState<GoalItem[]>(initialGoals);

  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalEmp, setGoalEmp] = useState('Vikram Malhotra');

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle.trim()) return;

    const newG: GoalItem = {
      id: `G-${Date.now()}`,
      employeeId: 'EMP-101',
      employeeName: goalEmp,
      title: goalTitle,
      category: 'KPI Target',
      progress: 25,
      targetDate: '2026-09-30',
      status: 'In Progress',
    };

    setGoalList([...goalList, newG]);
    onAddGoal(newG);
    setShowGoalModal(false);
    setGoalTitle('');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Talent Appraisal
            </span>
            <span className="text-xs text-slate-400">Quarterly Reviews & OKR Goals</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Performance & Appraisals
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Review quarterly ratings, track employee KPI goals, and evaluate promotion readiness.
          </p>
        </div>

        <button
          onClick={() => setShowGoalModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          Assign New Goal / KPI
        </button>
      </div>

      {/* Grid: Appraisals + OKR Progress */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Performance Reviews */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 dark:text-white text-base border-b border-slate-100 dark:border-slate-700 pb-3 flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-600" />
            Completed Appraisals
          </h3>

          <div className="space-y-3">
            {reviewList.map((rev) => (
              <div
                key={rev.id}
                className="p-4 rounded-xl bg-slate-50/50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{rev.employeeName}</h4>
                    <span className="text-xs text-slate-500 dark:text-slate-400">{rev.department} • Reviewer: {rev.reviewerName}</span>
                  </div>
                  <div className="flex items-center gap-1 bg-amber-100 dark:bg-amber-950 px-2.5 py-1 rounded-lg text-amber-800 dark:text-amber-200 font-black text-xs">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    <span>{rev.rating} / 5</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 italic">"{rev.comments}"</p>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Review Cycle: {rev.reviewPeriod}</span>
                  {rev.promoted ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <TrendingUp className="w-3.5 h-3.5" /> Promoted
                    </span>
                  ) : (
                    <span className="text-slate-500">Maintained Level</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Active Employee Goals */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 dark:text-white text-base border-b border-slate-100 dark:border-slate-700 pb-3 flex items-center gap-2">
            <Target className="w-5 h-5 text-purple-600" />
            Active KPI Goals & OKRs
          </h3>

          <div className="space-y-4">
            {goalList.map((g) => (
              <div
                key={g.id}
                className="p-4 rounded-xl bg-slate-50/50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{g.title}</h4>
                    <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">{g.employeeName}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-[10px]">
                    {g.status}
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                    <span>Progress Target</span>
                    <span>{g.progress}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                    <div
                      style={{ width: `${g.progress}%` }}
                      className="h-full bg-indigo-600 rounded-full transition-all duration-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Assign KPI / OKR Goal</h3>
            <form onSubmit={handleCreateGoal} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Employee Name</label>
                <input
                  type="text"
                  required
                  value={goalEmp}
                  onChange={(e) => setGoalEmp(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Goal / KPI Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Reduce API response latency below 50ms"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowGoalModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
