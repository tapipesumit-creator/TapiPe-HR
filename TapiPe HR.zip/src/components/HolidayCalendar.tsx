import React, { useState } from 'react';
import { CalendarDays, Plus, MapPin, Flag, Calendar as CalIcon, Edit2, Trash2, Download, Upload, Repeat } from 'lucide-react';
import { HolidayItem } from '../types';

interface HolidayCalendarProps {
  holidays: HolidayItem[];
  onAddHoliday: (item: HolidayItem) => void;
}

export const HolidayCalendar: React.FC<HolidayCalendarProps> = ({
  holidays: initialHolidays,
  onAddHoliday,
}) => {
  const [list, setList] = useState<HolidayItem[]>(initialHolidays);
  const [showModal, setShowModal] = useState(false);
  const [editingHoliday, setEditingHoliday] = useState<HolidayItem | null>(null);

  const [date, setDate] = useState('2026-08-28');
  const [name, setName] = useState('');
  const [type, setType] = useState<HolidayItem['type']>('National');
  const [branch, setBranch] = useState('All Branches');
  const [isRecurring, setIsRecurring] = useState(false);

  const openModal = (item?: HolidayItem) => {
    if (item) {
      setEditingHoliday(item);
      setDate(item.date);
      setName(item.name);
      setType(item.type);
      setBranch(item.branch);
      setIsRecurring(!!item.isRecurring);
    } else {
      setEditingHoliday(null);
      setDate('2026-08-28');
      setName('');
      setType('National');
      setBranch('All Branches');
      setIsRecurring(false);
    }
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const dt = new Date(date);
    const dayName = dt.toLocaleDateString('en-US', { weekday: 'long' });

    const newHol: HolidayItem = {
      id: editingHoliday ? editingHoliday.id : `HOL-${Date.now()}`,
      date,
      name,
      day: dayName,
      type,
      branch,
      isRecurring,
    };

    if (editingHoliday) {
      setList(list.map((h) => (h.id === newHol.id ? newHol : h)));
    } else {
      setList([...list, newHol]);
      onAddHoliday(newHol);
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this official holiday?')) {
      setList(list.filter((h) => h.id !== id));
    }
  };

  const exportExcel = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,ID,Date,Day,Holiday Name,Type,Branch,Recurring\n' +
      list.map((h) => `${h.id},${h.date},${h.day},"${h.name}",${h.type},"${h.branch}",${h.isRecurring ? 'Yes' : 'No'}`).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'Official_TapiPE_Holidays_2026.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const importExcel = () => {
    const mockImport: HolidayItem = {
      id: `HOL-${Date.now()}`,
      date: '2026-11-08',
      name: 'Diwali Festive Holiday',
      day: 'Sunday',
      type: 'National',
      branch: 'All Branches',
      isRecurring: true,
    };
    setList([mockImport, ...list]);
    alert('Imported 1 holiday successfully from Excel template!');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Company Calendar
            </span>
            <span className="text-xs text-slate-400">Year 2026 Holidays</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Official Holiday Calendar
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            National, regional, and branch-specific official non-working days.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={importExcel}
            className="flex items-center gap-1.5 px-3 py-2.5 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            <Upload className="w-4 h-4 text-indigo-400" /> Import Excel
          </button>
          <button
            onClick={exportExcel}
            className="flex items-center gap-1.5 px-3 py-2.5 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            <Download className="w-4 h-4 text-emerald-400" /> Export CSV
          </button>
          <button
            onClick={() => openModal()}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Holiday
          </button>
        </div>
      </div>

      {/* Grid of Holiday Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3 hover:border-indigo-400 transition-all relative"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                  <CalIcon className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-extrabold text-slate-900 dark:text-white text-sm">{item.name}</h3>
                    {item.isRecurring && (
                      <span className="p-0.5 rounded-md bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300" title="Annual Recurring">
                        <Repeat className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    {item.day}, {item.date}
                  </span>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1">
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    item.type === 'National'
                      ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300'
                  }`}
                >
                  {item.type}
                </span>
                <div className="flex items-center gap-1 mt-1">
                  <button
                    onClick={() => openModal(item)}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded-md"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded-md"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-medium">
                <MapPin className="w-3.5 h-3.5 text-slate-400" /> {item.branch}
              </span>
              <span className="font-bold text-indigo-600 dark:text-indigo-400">Paid Holiday</span>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Holiday Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl w-full max-w-md p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingHoliday ? 'Edit Official Holiday' : 'Add New Official Holiday'}
            </h3>
            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Holiday Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Diwali, Independence Day"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    <option value="National">National</option>
                    <option value="Regional">Regional</option>
                    <option value="Optional">Optional</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">Branch</label>
                  <select
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    <option value="All Branches">All Branches</option>
                    <option value="Mumbai HQ">Mumbai HQ</option>
                    <option value="Bengaluru Tech Hub">Bengaluru Tech Hub</option>
                    <option value="Delhi NCR">Delhi NCR</option>
                    <option value="Pune Office">Pune Office</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="recurring-check"
                  checked={isRecurring}
                  onChange={(e) => setIsRecurring(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded-md"
                />
                <label htmlFor="recurring-check" className="font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                  Annual Recurring Holiday
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  Save Holiday
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

