import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  FileText,
  Calendar,
  Filter,
  TrendingUp,
  Users,
  DollarSign,
  PieChart,
  Printer,
  CheckCircle2,
} from 'lucide-react';
import { Employee, AttendanceRecord, PayrollRecord } from '../types';

interface ReportsProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  payroll: PayrollRecord[];
}

export const Reports: React.FC<ReportsProps> = ({
  employees,
  attendance,
  payroll,
}) => {
  const [reportType, setReportType] = useState<'salary' | 'attendance'>('salary');
  const [dateRange, setDateRange] = useState('July 2026');

  // Department-wise Salary aggregation
  const deptSalaryMap: Record<string, { count: number; totalBase: number; totalNet: number }> = {};
  payroll.forEach((p) => {
    if (!deptSalaryMap[p.department]) {
      deptSalaryMap[p.department] = { count: 0, totalBase: 0, totalNet: 0 };
    }
    deptSalaryMap[p.department].count += 1;
    deptSalaryMap[p.department].totalBase += p.baseSalary;
    deptSalaryMap[p.department].totalNet += p.netSalary;
  });

  const grandTotalNet = payroll.reduce((acc, curr) => acc + curr.netSalary, 0);

  // Export to Excel CSV Function
  const handleExportCSV = () => {
    let csvData = '';

    if (reportType === 'salary') {
      csvData = 'Employee ID,Employee Name,Department,Base Salary,Bonus,PF Deduction,Net Salary,Month\n';
      payroll.forEach((p) => {
        csvData += `"${p.employeeId}","${p.employeeName}","${p.department}",${p.baseSalary},${p.bonus},${p.pfDeduction},${p.netSalary},"${p.month}"\n`;
      });
    } else {
      csvData = 'Employee ID,Employee Name,Date,Check In,Check Out,Work Hours,Status\n';
      attendance.forEach((a) => {
        csvData += `"${a.employeeId}","${a.employeeName}","${a.date}","${a.checkIn || ''}","${a.checkOut || ''}",${a.workHours || 0},"${a.status}"\n`;
      });
    }

    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `TapiPE_HR_${reportType.toUpperCase()}_REPORT_${dateRange.replace(/\s+/g, '_')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              HR & Financial Reports
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
              Analytics
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Export audit-ready CSV & PDF reports for salary disbursement and attendance logs.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 transition-all hover:scale-102"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Excel (CSV)
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Report Selector Tabs & Filter */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700">
        <div className="flex items-center gap-2 bg-white dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setReportType('salary')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              reportType === 'salary'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            Salary Expense Report
          </button>
          <button
            onClick={() => setReportType('attendance')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              reportType === 'attendance'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Attendance Analytics Report
          </button>
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-400" />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
          >
            <option value="July 2026">July 2026 (Current)</option>
            <option value="June 2026">June 2026</option>
            <option value="Q2 2026">Q2 2026 Summary</option>
            <option value="Year 2026">Full Year 2026 YTD</option>
          </select>
        </div>
      </div>

      {/* REPORT TYPE 1: SALARY REPORT */}
      {reportType === 'salary' ? (
        <div className="space-y-6">
          {/* Department Breakdown Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(deptSalaryMap).map(([dept, data]) => {
              const pctOfTotal = Math.round((data.totalNet / (grandTotalNet || 1)) * 100);
              return (
                <div
                  key={dept}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">{dept}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
                      {data.count} Staff
                    </span>
                  </div>

                  <div>
                    <span className="text-2xl font-black text-slate-900 dark:text-white">
                      ₹{data.totalNet.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-slate-400 block mt-0.5">
                      Net Payout ({pctOfTotal}% of total)
                    </span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${pctOfTotal}%` }}
                      className="bg-indigo-600 h-full rounded-full"
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full Detailed Salary Table */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 font-bold text-sm text-slate-900 dark:text-white flex items-center justify-between">
              <span>Full Disbursement Breakdown ({dateRange})</span>
              <span className="text-xs font-bold text-emerald-600">Total: ₹{grandTotalNet.toLocaleString('en-IN')}</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <th className="py-3 px-4">Employee ID</th>
                    <th className="py-3 px-4">Employee Name</th>
                    <th className="py-3 px-4">Department</th>
                    <th className="py-3 px-4">Base Salary</th>
                    <th className="py-3 px-4">PF (12%)</th>
                    <th className="py-3 px-4">TDS Tax</th>
                    <th className="py-3 px-4">Net Payout</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs text-slate-800 dark:text-slate-200">
                  {payroll.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                      <td className="py-3 px-4 font-mono font-semibold text-slate-400">{p.employeeId}</td>
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{p.employeeName}</td>
                      <td className="py-3 px-4">{p.department}</td>
                      <td className="py-3 px-4">₹{p.baseSalary.toLocaleString('en-IN')}</td>
                      <td className="py-3 px-4 text-rose-600">₹{p.pfDeduction.toLocaleString('en-IN')}</td>
                      <td className="py-3 px-4 text-rose-600">₹{p.tdsDeduction.toLocaleString('en-IN')}</td>
                      <td className="py-3 px-4 font-black text-slate-900 dark:text-white">
                        ₹{p.netSalary.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* REPORT TYPE 2: ATTENDANCE REPORT */
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Overall Attendance Rate</span>
              <div className="mt-2 text-3xl font-black text-emerald-600 dark:text-emerald-400">92.8%</div>
              <p className="text-xs text-slate-500 mt-1">Based on 208 total logged working hours</p>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Punctuality Score</span>
              <div className="mt-2 text-3xl font-black text-indigo-600 dark:text-indigo-400">96.2%</div>
              <p className="text-xs text-slate-500 mt-1">Checked-in before 09:30 AM deadline</p>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs">
              <span className="text-xs font-bold text-slate-400 uppercase">Total Approved Leaves</span>
              <div className="mt-2 text-3xl font-black text-amber-600 dark:text-amber-400">4 Days</div>
              <p className="text-xs text-slate-500 mt-1">Casual & Sick leave requests</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 font-bold text-sm text-slate-900 dark:text-white">
              Daily Shift Duration Log ({dateRange})
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Employee</th>
                    <th className="py-3 px-4">Check In</th>
                    <th className="py-3 px-4">Check Out</th>
                    <th className="py-3 px-4">Hours Worked</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs text-slate-800 dark:text-slate-200">
                  {attendance.map((att) => (
                    <tr key={att.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/40">
                      <td className="py-3 px-4 font-mono">{att.date}</td>
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{att.employeeName}</td>
                      <td className="py-3 px-4">{att.checkIn || 'N/A'}</td>
                      <td className="py-3 px-4">{att.checkOut || 'N/A'}</td>
                      <td className="py-3 px-4 font-semibold">{att.workHours || 0} hrs</td>
                      <td className="py-3 px-4 uppercase font-bold text-[10px]">
                        <span
                          className={`px-2 py-0.5 rounded-full ${
                            att.status === 'present'
                              ? 'bg-emerald-100 text-emerald-800'
                              : att.status === 'half_day'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {att.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
