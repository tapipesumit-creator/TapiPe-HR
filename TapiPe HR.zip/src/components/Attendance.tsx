import React, { useState, useEffect } from 'react';
import {
  CalendarCheck2,
  Clock,
  UserCheck,
  UserX,
  Briefcase,
  AlertCircle,
  CheckCircle2,
  Play,
  Square,
  MapPin,
  Calendar,
  Search,
  Filter,
  Check,
} from 'lucide-react';
import { AttendanceRecord, Employee, AttendanceStatus, UserRole } from '../types';

interface AttendanceProps {
  attendance: AttendanceRecord[];
  employees: Employee[];
  role: UserRole;
  onUpdateAttendanceStatus: (employeeId: string, status: AttendanceStatus, checkIn?: string, checkOut?: string) => void;
  isCheckInModalOpen: boolean;
  onCloseCheckInModal: () => void;
}

export const Attendance: React.FC<AttendanceProps> = ({
  attendance,
  employees,
  role,
  onUpdateAttendanceStatus,
  isCheckInModalOpen,
  onCloseCheckInModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Live Timer for Check-In Module
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isCheckedIn, setIsCheckedIn] = useState(true);
  const [userCheckInTime, setUserCheckInTime] = useState('09:15 AM');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleToggleSelfCheckIn = () => {
    if (!isCheckedIn) {
      const nowStr = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setIsCheckedIn(true);
      setUserCheckInTime(nowStr);
      // Mark Rohan Sharma (EMP-101) as present
      onUpdateAttendanceStatus('EMP-101', 'present', nowStr, undefined);
    } else {
      const outStr = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setIsCheckedIn(false);
      onUpdateAttendanceStatus('EMP-101', 'present', userCheckInTime, outStr);
    }
  };

  // Filtered attendance list
  const filteredAttendance = attendance.filter((att) => {
    const matchesSearch =
      att.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      att.employeeId.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || att.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const presentCount = attendance.filter((a) => a.status === 'present').length;
  const absentCount = attendance.filter((a) => a.status === 'absent').length;
  const halfDayCount = attendance.filter((a) => a.status === 'half_day').length;
  const leaveCount = attendance.filter((a) => a.status === 'on_leave').length;

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Attendance & Time Tracking
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
              Live Tracker
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time biometric & remote check-in logs, punctuality rate & shift durations.
          </p>
        </div>

        {/* Current Date Badge */}
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700/60 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200">
          <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <span>
            {currentTime.toLocaleDateString('en-IN', {
              weekday: 'short',
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            })}
          </span>
        </div>
      </div>

      {/* Interactive Check-In / Check-Out Widget */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white shadow-xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 text-indigo-300 flex items-center justify-center font-black text-2xl shadow-inner shrink-0">
            <Clock className="w-8 h-8 animate-pulse text-indigo-400" />
          </div>
          <div>
            <div className="text-3xl font-black tracking-tight text-white font-mono">
              {currentTime.toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              })}
            </div>
            <p className="text-xs text-slate-300 mt-0.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" /> TapiPE HQ, BKC Mumbai (Shift: 09:00 AM - 06:00 PM)
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
          <div className="text-center sm:text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              My Status Today
            </span>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full inline-block mt-0.5 ${
                isCheckedIn ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-700 text-slate-300'
              }`}
            >
              {isCheckedIn ? `Checked In at ${userCheckInTime}` : 'Not Checked In'}
            </span>
          </div>

          <button
            onClick={handleToggleSelfCheckIn}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-xs shadow-lg transition-all transform hover:scale-105 ${
              isCheckedIn
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold shadow-emerald-500/30'
            }`}
          >
            {isCheckedIn ? (
              <>
                <Square className="w-4 h-4 fill-current" />
                Check Out Now
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                Punch In Now
              </>
            )}
          </button>
        </div>
      </div>

      {/* Quick Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-xs font-bold text-slate-400 uppercase">Present</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{presentCount}</span>
            <span className="text-xs text-emerald-600 font-semibold">Employees</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-xs font-bold text-slate-400 uppercase">Half Day</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-amber-600 dark:text-amber-400">{halfDayCount}</span>
            <span className="text-xs text-amber-600 font-semibold">Employees</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-xs font-bold text-slate-400 uppercase">On Leave</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400">{leaveCount}</span>
            <span className="text-xs text-indigo-600 font-semibold">Approved</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-xs font-bold text-slate-400 uppercase">Absent</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400">{absentCount}</span>
            <span className="text-xs text-rose-600 font-semibold">Unexcused</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search employee attendance..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
          {['all', 'present', 'half_day', 'on_leave', 'absent'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize whitespace-nowrap transition-all ${
                statusFilter === st
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-600'
              }`}
            >
              {st === 'all' ? 'All Status' : st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Attendance Table */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4">Check-In Time</th>
                <th className="py-3.5 px-4">Check-Out Time</th>
                <th className="py-3.5 px-4">Work Hours</th>
                <th className="py-3.5 px-4">Current Status</th>
                {role === 'admin' && <th className="py-3.5 px-4 text-right">Quick Status Toggle</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs text-slate-800 dark:text-slate-200">
              {filteredAttendance.map((att) => (
                <tr key={att.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-slate-900 dark:text-white">{att.employeeName}</div>
                    <div className="text-[10px] font-mono text-slate-400">{att.employeeId}</div>
                  </td>

                  <td className="py-3.5 px-4">
                    {att.checkIn ? (
                      <span className="font-mono text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {att.checkIn}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic">-- : --</span>
                    )}
                  </td>

                  <td className="py-3.5 px-4">
                    {att.checkOut ? (
                      <span className="font-mono text-xs font-semibold text-slate-800 dark:text-slate-200">
                        {att.checkOut}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic">-- : --</span>
                    )}
                  </td>

                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {att.workHours ? `${att.workHours} hrs` : '0 hrs'}
                    </span>
                  </td>

                  <td className="py-3.5 px-4">
                    {att.status === 'present' && (
                      <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Present
                      </span>
                    )}
                    {att.status === 'half_day' && (
                      <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 inline-flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Half Day
                      </span>
                    )}
                    {att.status === 'on_leave' && (
                      <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 inline-flex items-center gap-1">
                        <Briefcase className="w-3 h-3" /> On Leave
                      </span>
                    )}
                    {att.status === 'absent' && (
                      <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 inline-flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Absent
                      </span>
                    )}
                  </td>

                  {role === 'admin' && (
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onUpdateAttendanceStatus(att.employeeId, 'present', '09:00 AM', '06:00 PM')}
                          className={`px-2 py-1 text-[10px] font-bold rounded-md transition-colors ${
                            att.status === 'present'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-emerald-100'
                          }`}
                        >
                          P
                        </button>
                        <button
                          onClick={() => onUpdateAttendanceStatus(att.employeeId, 'half_day', '09:00 AM', '01:00 PM')}
                          className={`px-2 py-1 text-[10px] font-bold rounded-md transition-colors ${
                            att.status === 'half_day'
                              ? 'bg-amber-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-amber-100'
                          }`}
                        >
                          HD
                        </button>
                        <button
                          onClick={() => onUpdateAttendanceStatus(att.employeeId, 'on_leave')}
                          className={`px-2 py-1 text-[10px] font-bold rounded-md transition-colors ${
                            att.status === 'on_leave'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-indigo-100'
                          }`}
                        >
                          L
                        </button>
                        <button
                          onClick={() => onUpdateAttendanceStatus(att.employeeId, 'absent')}
                          className={`px-2 py-1 text-[10px] font-bold rounded-md transition-colors ${
                            att.status === 'absent'
                              ? 'bg-rose-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-rose-100'
                          }`}
                        >
                          A
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
