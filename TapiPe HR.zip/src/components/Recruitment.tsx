import React, { useState } from 'react';
import { Briefcase, UserPlus, Star, ChevronRight, FileText, CheckCircle2, Search } from 'lucide-react';
import { CandidateItem, JobPosting } from '../types';

interface RecruitmentProps {
  candidates: CandidateItem[];
  jobs: JobPosting[];
  onAddCandidate: (c: CandidateItem) => void;
  onUpdateStage: (id: string, stage: CandidateItem['stage']) => void;
}

export const Recruitment: React.FC<RecruitmentProps> = ({
  candidates: initialCandidates,
  jobs,
  onAddCandidate,
  onUpdateStage,
}) => {
  const [candidatesList, setCandidatesList] = useState<CandidateItem[]>(initialCandidates);
  const [activeTab, setActiveTab] = useState<'pipeline' | 'jobs'>('pipeline');
  const [searchQuery, setSearchQuery] = useState('');

  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [position, setPosition] = useState('Senior DevOps Engineer');
  const [exp, setExp] = useState(4);
  const [ctc, setCtc] = useState(95000);

  const stages: CandidateItem['stage'][] = [
    'Applied',
    'Screening',
    'Technical Round',
    'HR Round',
    'Offered',
    'Joined',
  ];

  const handleStageChange = (id: string, newStage: CandidateItem['stage']) => {
    setCandidatesList((prev) =>
      prev.map((c) => (c.id === id ? { ...c, stage: newStage } : c))
    );
    onUpdateStage(id, newStage);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newCand: CandidateItem = {
      id: `CND-${Date.now()}`,
      name,
      email,
      phone: '+91 98000 11122',
      position,
      department: 'Engineering',
      experienceYears: Number(exp),
      stage: 'Applied',
      expectedCtc: Number(ctc),
      appliedDate: new Date().toISOString().split('T')[0],
      rating: 4.5,
    };

    setCandidatesList([...candidatesList, newCand]);
    onAddCandidate(newCand);
    setShowAddModal(false);
    setName('');
  };

  const filteredCandidates = candidatesList.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.position.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Talent Acquisition
            </span>
            <span className="text-xs text-slate-400">Recruitment & Hiring Funnel</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Recruitment & Candidate Pipeline
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Track candidates from screening to technical interview, offer letter, and onboarding.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          Add Candidate
        </button>
      </div>

      {/* Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-800/90 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div className="flex items-center gap-2 text-xs font-bold w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'pipeline'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Candidate Pipeline ({candidatesList.length})
          </button>
          <button
            onClick={() => setActiveTab('jobs')}
            className={`px-4 py-2 rounded-xl transition-all ${
              activeTab === 'jobs'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            Open Job Postings ({jobs.length})
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search candidates or role..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
          />
        </div>
      </div>

      {/* Candidate Pipeline View */}
      {activeTab === 'pipeline' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCandidates.map((cand) => (
            <div
              key={cand.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{cand.name}</h3>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">{cand.position}</p>
                </div>
                <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-md text-amber-700 dark:text-amber-300 font-bold text-xs">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span>{cand.rating}</span>
                </div>
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl">
                <div>Experience: <span className="font-bold text-slate-900 dark:text-white">{cand.experienceYears} Years</span></div>
                <div>Expected CTC: <span className="font-bold text-slate-900 dark:text-white">₹{cand.expectedCtc.toLocaleString('en-IN')} / mo</span></div>
                <div>Contact: <span className="font-bold text-slate-900 dark:text-white">{cand.phone}</span></div>
              </div>

              {/* Stage Selector */}
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                  Interview Stage
                </label>
                <select
                  value={cand.stage}
                  onChange={(e) => handleStageChange(cand.id, e.target.value as any)}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-bold text-indigo-600 dark:text-indigo-300"
                >
                  {stages.map((stg) => (
                    <option key={stg} value={stg}>
                      {stg}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Open Jobs View */}
      {activeTab === 'jobs' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.map((job) => (
            <div
              key={job.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{job.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{job.department}</p>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-bold text-[10px]">
                  {job.status}
                </span>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span>Openings: <strong className="text-slate-900 dark:text-white">{job.openings}</strong></span>
                <span>Applicants: <strong className="text-indigo-600 dark:text-indigo-400">{job.applicantsCount}</strong></span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Candidate Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Add Candidate Application</h3>
            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Siddharth Roy"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Email</label>
                <input
                  type="email"
                  required
                  placeholder="candidate@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Applied Position</label>
                <input
                  type="text"
                  required
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Experience (Yrs)</label>
                  <input
                    type="number"
                    value={exp}
                    onChange={(e) => setExp(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Expected CTC (Monthly ₹)</label>
                  <input
                    type="number"
                    value={ctc}
                    onChange={(e) => setCtc(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Candidate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
