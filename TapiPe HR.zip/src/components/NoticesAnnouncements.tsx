import React, { useState } from 'react';
import { Megaphone, Plus, Pin, Calendar, Tag, Edit2, Trash2, Archive, Clock } from 'lucide-react';
import { CompanyNotice } from '../types';

interface NoticesAnnouncementsProps {
  notices: CompanyNotice[];
  onAddNotice: (n: CompanyNotice) => void;
}

export const NoticesAnnouncements: React.FC<NoticesAnnouncementsProps> = ({
  notices: initialNotices,
  onAddNotice,
}) => {
  const [noticeList, setNoticeList] = useState<CompanyNotice[]>(initialNotices);
  const [showModal, setShowModal] = useState(false);
  const [editingNotice, setEditingNotice] = useState<CompanyNotice | null>(null);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<CompanyNotice['category']>('HR Policy');
  const [pinned, setPinned] = useState(true);
  const [scheduledDate, setScheduledDate] = useState('');

  const openModal = (notice?: CompanyNotice) => {
    if (notice) {
      setEditingNotice(notice);
      setTitle(notice.title);
      setContent(notice.content);
      setCategory(notice.category);
      setPinned(notice.isPinned);
      setScheduledDate(notice.scheduledDate || '');
    } else {
      setEditingNotice(null);
      setTitle('');
      setContent('');
      setCategory('HR Policy');
      setPinned(true);
      setScheduledDate('');
    }
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newN: CompanyNotice = {
      id: editingNotice ? editingNotice.id : `NTC-${Date.now()}`,
      title,
      content,
      category,
      postedBy: 'Sumit (Super Admin)',
      postedDate: new Date().toISOString().split('T')[0],
      isPinned: pinned,
      scheduledDate,
      isArchived: false,
    };

    if (editingNotice) {
      setNoticeList(noticeList.map((n) => (n.id === newN.id ? newN : n)));
    } else {
      setNoticeList([newN, ...noticeList]);
      onAddNotice(newN);
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Delete this announcement?')) {
      setNoticeList(noticeList.filter((n) => n.id !== id));
    }
  };

  const togglePin = (notice: CompanyNotice) => {
    setNoticeList(
      noticeList.map((n) => (n.id === notice.id ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const toggleArchive = (notice: CompanyNotice) => {
    setNoticeList(
      noticeList.map((n) => (n.id === notice.id ? { ...n, isArchived: !n.isArchived } : n))
    );
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Internal Broadcast
            </span>
            <span className="text-xs text-slate-400">TapiPE Fintech Newsfeed</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Notices & Company Announcements
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Broadcast HR policies, upcoming holiday reminders, quarterly townhall invites, and security updates.
          </p>
        </div>

        <button
          onClick={() => openModal()}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          Broadcast Announcement
        </button>
      </div>

      {/* Grid of Notices */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {noticeList.map((n) => (
          <div
            key={n.id}
            className={`p-5 rounded-2xl bg-white dark:bg-slate-800/90 border shadow-sm space-y-3 relative ${
              n.isArchived ? 'opacity-60 bg-slate-50 dark:bg-slate-900' : ''
            } ${
              n.isPinned
                ? 'border-indigo-500/80 ring-1 ring-indigo-500/30'
                : 'border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 font-bold text-[10px] text-slate-700 dark:text-slate-300">
                  {n.category}
                </span>
                {n.scheduledDate && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400 font-bold text-[10px]">
                    <Clock className="w-3 h-3" /> Scheduled: {n.scheduledDate}
                  </span>
                )}
                {n.isArchived && (
                  <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold text-[10px]">
                    Archived
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => togglePin(n)}
                  title={n.isPinned ? 'Unpin' : 'Pin to Top'}
                  className={`p-1.5 rounded-lg text-xs font-bold ${
                    n.isPinned ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950' : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  <Pin className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => toggleArchive(n)}
                  title={n.isArchived ? 'Restore' : 'Archive'}
                  className="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                >
                  <Archive className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => openModal(n)}
                  title="Edit"
                  className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(n.id)}
                  title="Delete"
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <h3 className="font-extrabold text-slate-900 dark:text-white text-base pt-1">{n.title}</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{n.content}</p>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400 font-medium">
              <span>Posted by {n.postedBy}</span>
              <span>{n.postedDate}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingNotice ? 'Edit Announcement' : 'Broadcast New Notice'}
            </h3>
            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Notice Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Q3 Townhall Meeting & FY27 Vision"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Notice Content</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Type the announcement details here..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="HR Policy">HR Policy</option>
                    <option value="Event">Event</option>
                    <option value="Townhall">Townhall</option>
                    <option value="Security">Security</option>
                    <option value="Holiday">Holiday</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Schedule Publish Date</label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="pinCheck"
                  checked={pinned}
                  onChange={(e) => setPinned(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600"
                />
                <label htmlFor="pinCheck" className="font-semibold text-slate-700 dark:text-slate-300">
                  Pin to top of newsfeed
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Announcement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

