import React, { useState } from 'react';
import {
  X,
  User,
  Building,
  Phone,
  Mail,
  Calendar,
  CreditCard,
  FileText,
  Upload,
  Camera,
  Trash2,
  Edit3,
  Check,
  Briefcase,
  ShieldAlert,
  Award,
  Clock,
  Laptop,
  Heart,
  Users,
  FileCheck,
  Lock,
  Eye,
  Download,
  Plus,
  Share2,
  FolderOpen,
  DollarSign,
  TrendingUp,
  AlertCircle,
  Sparkles,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { Employee, DocumentItem } from '../types';

export interface VaultDocItem {
  id: string;
  category: string;
  title: string;
  fileUrl: string;
  fileType: string;
  fileSize: string;
  uploadDate: string;
  expiryDate?: string;
  version: string;
  isArchived?: boolean;
}

interface EmployeeProfileModalProps {
  employee: Employee;
  onUpdateEmployee: (updated: Employee) => void;
  onClose: () => void;
}

export const EmployeeProfileModal: React.FC<EmployeeProfileModalProps> = ({
  employee,
  onUpdateEmployee,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'personal'
    | 'professional'
    | 'salary'
    | 'attendance'
    | 'leave'
    | 'performance'
    | 'documents'
    | 'notes'
    | 'timeline'
    | 'bank'
    | 'education'
    | 'experience'
    | 'assets'
    | 'emergency'
    | 'nominee'
  >('overview');

  const [isEditing, setIsEditing] = useState(false);
  const [empData, setEmpData] = useState<Employee>(employee);

  // Notes state
  const [notes, setNotes] = useState<{ id: string; text: string; date: string; author: string }[]>([
    {
      id: 'note-1',
      text: 'Completed annual compliance training ahead of deadline.',
      date: '2026-06-15',
      author: 'HR Admin',
    },
    {
      id: 'note-2',
      text: 'Promoted to Senior Lead level due to exceptional Q2 performance.',
      date: '2026-04-01',
      author: 'Sumit Sharma (VP HR)',
    },
  ]);
  const [newNote, setNewNote] = useState('');

  // Timeline state
  const [timeline, setTimeline] = useState<
    { id: string; title: string; date: string; description: string; tag: string }[]
  >([
    {
      id: 'tl-1',
      title: 'Joined TapiPE Fintech',
      date: employee.joiningDate || '2024-01-15',
      description: 'Onboarded as Full-Time Employee in Engineering team.',
      tag: 'Onboarding',
    },
    {
      id: 'tl-2',
      title: 'Probation Completed',
      date: '2024-07-15',
      description: 'Confirmed post 6-month review with performance rating 4.8/5.',
      tag: 'Confirmation',
    },
    {
      id: 'tl-3',
      title: 'Annual Performance Appraisal',
      date: '2025-04-01',
      description: '15% CTC revision & awarded Star Performer badge.',
      tag: 'Appraisal',
    },
  ]);

  // Vault Documents state
  const [vaultDocs, setVaultDocs] = useState<VaultDocItem[]>([
    {
      id: 'doc-v1',
      category: 'Offer Letter',
      title: 'TapiPE_Official_Offer_Letter.pdf',
      fileUrl: employee.joiningKitUrl || 'https://example.com/offer.pdf',
      fileType: 'PDF',
      fileSize: '1.4 MB',
      uploadDate: employee.joiningDate || '2024-01-10',
      version: 'v1.0',
    },
    {
      id: 'doc-v2',
      category: 'Aadhaar Card',
      title: 'Aadhaar_Card_Verified.pdf',
      fileUrl: employee.aadhaarDocUrl || 'https://example.com/aadhaar.pdf',
      fileType: 'PDF',
      fileSize: '850 KB',
      uploadDate: '2024-01-15',
      version: 'v1.0',
    },
    {
      id: 'doc-v3',
      category: 'PAN Card',
      title: 'PAN_Card_Copy.jpg',
      fileUrl: employee.panDocUrl || 'https://example.com/pan.jpg',
      fileType: 'JPG',
      fileSize: '420 KB',
      uploadDate: '2024-01-15',
      version: 'v1.0',
    },
    {
      id: 'doc-v4',
      category: 'Salary Slip',
      title: 'Payslip_July_2026.pdf',
      fileUrl: 'https://example.com/payslip.pdf',
      fileType: 'PDF',
      fileSize: '512 KB',
      uploadDate: '2026-07-30',
      version: 'v1.0',
    },
  ]);

  const [newDocCategory, setNewDocCategory] = useState('Offer Letter');
  const [newDocTitle, setNewDocTitle] = useState('');
  const [selectedPreviewDoc, setSelectedPreviewDoc] = useState<VaultDocItem | null>(null);

  // Photo handlers
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const updated = { ...empData, avatarUrl: reader.result as string };
        setEmpData(updated);
        onUpdateEmployee(updated);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    const updated = { ...empData, avatarUrl: '' };
    setEmpData(updated);
    onUpdateEmployee(updated);
  };

  // Save changes
  const handleSaveAll = () => {
    onUpdateEmployee(empData);
    setIsEditing(false);
  };

  // Add Vault document
  const handleAddVaultDoc = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const newDoc: VaultDocItem = {
        id: `vdoc-${Date.now()}`,
        category: newDocCategory,
        title: newDocTitle || file.name,
        fileUrl: reader.result as string,
        fileType: file.name.split('.').pop()?.toUpperCase() || 'FILE',
        fileSize: `${(file.size / 1024).toFixed(0)} KB`,
        uploadDate: new Date().toISOString().split('T')[0],
        version: 'v1.0',
      };
      setVaultDocs([newDoc, ...vaultDocs]);
      setNewDocTitle('');
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteVaultDoc = (id: string) => {
    if (confirm('Delete document from vault?')) {
      setVaultDocs(vaultDocs.filter((d) => d.id !== id));
    }
  };

  const tabsList = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'personal', label: 'Personal', icon: Heart },
    { id: 'professional', label: 'Professional', icon: Briefcase },
    { id: 'salary', label: 'Salary & Tax', icon: DollarSign },
    { id: 'documents', label: 'Document Vault', icon: FolderOpen },
    { id: 'attendance', label: 'Attendance', icon: Clock },
    { id: 'leave', label: 'Leave', icon: Calendar },
    { id: 'performance', label: 'Performance', icon: TrendingUp },
    { id: 'timeline', label: 'Timeline', icon: Award },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'bank', label: 'Bank Details', icon: CreditCard },
    { id: 'education', label: 'Education', icon: FileCheck },
    { id: 'experience', label: 'Experience', icon: Building },
    { id: 'assets', label: 'Assets', icon: Laptop },
    { id: 'emergency', label: 'Emergency', icon: ShieldAlert },
    { id: 'nominee', label: 'Nominee', icon: Users },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-6xl max-h-[92vh] flex flex-col overflow-hidden my-auto">
        {/* Top Header Banner */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-indigo-900/50">
          <div className="flex items-center gap-4">
            {/* Employee Photo */}
            <div className="relative group">
              {empData.avatarUrl ? (
                <img
                  src={empData.avatarUrl}
                  alt={empData.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-500 shadow-md"
                />
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-indigo-600 text-white font-extrabold text-2xl flex items-center justify-center border-2 border-indigo-400 shadow-md">
                  {empData.name.substring(0, 2).toUpperCase()}
                </div>
              )}

              {/* Photo Upload Overlay */}
              <label className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-white cursor-pointer transition-all">
                <Camera className="w-6 h-6" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black tracking-tight">{empData.name}</h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                  {empData.status}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  {empData.id}
                </span>
              </div>
              <p className="text-xs text-indigo-200 font-semibold flex items-center gap-2">
                <span>{empData.designation}</span> • <span>{empData.department}</span>
              </p>
              <div className="flex items-center gap-4 text-[11px] text-slate-300 pt-0.5">
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-indigo-400" /> {empData.email}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" /> {empData.phone}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {empData.avatarUrl && (
              <button
                onClick={handleRemovePhoto}
                className="px-3 py-1.5 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 text-xs font-bold flex items-center gap-1 border border-rose-700/50"
                title="Remove Photo"
              >
                <Trash2 className="w-3.5 h-3.5" /> Remove Photo
              </button>
            )}

            {isEditing ? (
              <button
                onClick={handleSaveAll}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
              >
                <Check className="w-4 h-4" /> Save Profile
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md"
              >
                <Edit3 className="w-4 h-4" /> Edit Profile
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Scrollbar */}
        <div className="bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 overflow-x-auto custom-scrollbar flex items-center gap-1 p-2">
          {tabsList.map((t) => {
            const IconComp = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as any)}
                className={`px-3.5 py-2 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <IconComp className="w-3.5 h-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar text-xs bg-slate-50/50 dark:bg-slate-900/50">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stat Cards Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Monthly Salary CTC</span>
                  <p className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                    ₹{empData.salary.toLocaleString('en-IN')}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Joining Date</span>
                  <p className="text-sm font-extrabold text-slate-800 dark:text-slate-100">
                    {empData.joiningDate}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">PAN Number</span>
                  <p className="text-sm font-extrabold font-mono text-slate-800 dark:text-slate-100">
                    {empData.panNumber || 'ABCPS9999X'}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Branch Office</span>
                  <p className="text-sm font-extrabold text-indigo-600 dark:text-indigo-400">
                    {empData.branch || 'Mumbai Main HQ'}
                  </p>
                </div>
              </div>

              {/* Quick Info Sections */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <User className="w-4 h-4 text-indigo-600" /> Key Personal Identity
                  </h3>
                  <div className="space-y-2 text-slate-700 dark:text-slate-300">
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">Date of Birth:</span>
                      <span className="font-bold">{empData.dob || '1995-08-14'}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">Gender:</span>
                      <span className="font-bold">{empData.gender || 'Male'}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">Blood Group:</span>
                      <span className="font-bold text-rose-600">{empData.bloodGroup || 'O+ Positive'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">Aadhaar Number:</span>
                      <span className="font-bold font-mono">{empData.aadhaarNumber || '9876 5432 1098'}</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-600" /> Banking & Compliance
                  </h3>
                  <div className="space-y-2 text-slate-700 dark:text-slate-300">
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">Bank Account:</span>
                      <span className="font-bold font-mono">{empData.bankAccount}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">PF Universal Account (UAN):</span>
                      <span className="font-bold font-mono">{empData.uanNumber || '100987654321'}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 dark:border-slate-700 pb-1.5">
                      <span className="text-slate-400 font-semibold">PF Number:</span>
                      <span className="font-bold font-mono">{empData.pfNumber || 'MH/BOM/0012345/000'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-semibold">ESI Insurance No:</span>
                      <span className="font-bold font-mono">{empData.esiNumber || '310098765432'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PERSONAL */}
          {activeTab === 'personal' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Date of Birth</label>
                  <input
                    type="date"
                    disabled={!isEditing}
                    value={empData.dob || '1995-08-14'}
                    onChange={(e) => setEmpData({ ...empData, dob: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Gender</label>
                  <select
                    disabled={!isEditing}
                    value={empData.gender || 'Male'}
                    onChange={(e) => setEmpData({ ...empData, gender: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Blood Group</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.bloodGroup || 'O+'}
                    onChange={(e) => setEmpData({ ...empData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Father's Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.fatherName || 'Ramesh Sharma'}
                    onChange={(e) => setEmpData({ ...empData, fatherName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Residential Address</label>
                  <textarea
                    rows={2}
                    disabled={!isEditing}
                    value={empData.address || 'Flat 402, Seawood Towers, BKC Road, Bandra East, Mumbai - 400051'}
                    onChange={(e) => setEmpData({ ...empData, address: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PROFESSIONAL */}
          {activeTab === 'professional' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Professional Role & Employment Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Designation</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.designation}
                    onChange={(e) => setEmpData({ ...empData, designation: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Department</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.department}
                    onChange={(e) => setEmpData({ ...empData, department: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Branch Office Location</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.branch || 'Mumbai HQ'}
                    onChange={(e) => setEmpData({ ...empData, branch: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Employment Status</label>
                  <select
                    disabled={!isEditing}
                    value={empData.status}
                    onChange={(e) => setEmpData({ ...empData, status: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  >
                    <option value="active">Active</option>
                    <option value="on_leave">On Leave</option>
                    <option value="inactive">Inactive / Resigned</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SALARY & TAX */}
          {activeTab === 'salary' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Compensation, PF, ESI & Tax Slabs</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Monthly CTC (INR ₹)</label>
                  <input
                    type="number"
                    disabled={!isEditing}
                    value={empData.salary}
                    onChange={(e) => setEmpData({ ...empData, salary: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold text-emerald-600 dark:text-emerald-400 text-sm disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">PAN Card Number</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.panNumber}
                    onChange={(e) => setEmpData({ ...empData, panNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold font-mono disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">PF Universal Number (UAN)</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.uanNumber || '100987654321'}
                    onChange={(e) => setEmpData({ ...empData, uanNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold font-mono disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">ESI Insurance Number</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.esiNumber || '310098765432'}
                    onChange={(e) => setEmpData({ ...empData, esiNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold font-mono disabled:opacity-80"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: DOCUMENT VAULT */}
          {activeTab === 'documents' && (
            <div className="space-y-5">
              {/* Upload Header Box */}
              <div className="p-5 rounded-2xl bg-indigo-50 dark:bg-slate-800 border border-indigo-200 dark:border-indigo-900/60 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-indigo-900 dark:text-indigo-200 flex items-center gap-2">
                      <FolderOpen className="w-4 h-4 text-indigo-600" /> Upload Document to Vault
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      Supports PDF, DOCX, JPG, PNG, Excel, CSV up to 25MB. Automatically encrypted and saved permanently.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div>
                    <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                      Document Category
                    </label>
                    <select
                      value={newDocCategory}
                      onChange={(e) => setNewDocCategory(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                    >
                      <option value="Offer Letter">Offer Letter</option>
                      <option value="Appointment Letter">Appointment Letter</option>
                      <option value="Confirmation Letter">Confirmation Letter</option>
                      <option value="Experience Letter">Experience Letter</option>
                      <option value="Relieving Letter">Relieving Letter</option>
                      <option value="Salary Slip">Salary Slip</option>
                      <option value="Aadhaar Card">Aadhaar Card</option>
                      <option value="PAN Card">PAN Card</option>
                      <option value="Passport">Passport</option>
                      <option value="Driving Licence">Driving Licence</option>
                      <option value="Bank Passbook">Bank Passbook</option>
                      <option value="Cancelled Cheque">Cancelled Cheque</option>
                      <option value="Resume">Resume</option>
                      <option value="Educational Certificate">Educational Certificate</option>
                      <option value="Police Verification">Police Verification</option>
                      <option value="NDA / Agreement">NDA / Agreement</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold mb-1 text-slate-700 dark:text-slate-300">
                      Custom Title (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Passport_Renewal_2026.pdf"
                      value={newDocTitle}
                      onChange={(e) => setNewDocTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                    />
                  </div>

                  <div className="flex items-end">
                    <label className="w-full cursor-pointer px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center justify-center gap-2 shadow-md">
                      <Upload className="w-4 h-4" /> Upload File
                      <input type="file" onChange={handleAddVaultDoc} className="hidden" />
                    </label>
                  </div>
                </div>
              </div>

              {/* Vault Document Table */}
              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 dark:bg-slate-700/50 text-slate-500 dark:text-slate-300 font-extrabold uppercase text-[10px]">
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Document Title</th>
                      <th className="p-3.5">Type & Size</th>
                      <th className="p-3.5">Upload Date</th>
                      <th className="p-3.5">Version</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium">
                    {vaultDocs.map((vd) => (
                      <tr key={vd.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30">
                        <td className="p-3.5 font-bold text-indigo-600 dark:text-indigo-400">
                          {vd.category}
                        </td>
                        <td className="p-3.5 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          <FileText className="w-4 h-4 text-slate-400" />
                          {vd.title}
                        </td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 font-mono text-[10px] font-bold">
                            {vd.fileType} ({vd.fileSize})
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-500 dark:text-slate-400">{vd.uploadDate}</td>
                        <td className="p-3.5">
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold">
                            {vd.version}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => setSelectedPreviewDoc(vd)}
                              title="Preview Document"
                              className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={vd.fileUrl}
                              download={vd.title}
                              title="Download"
                              className="p-1.5 text-slate-400 hover:text-emerald-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </a>
                            <button
                              onClick={() => handleDeleteVaultDoc(vd.id)}
                              title="Delete"
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 6: ATTENDANCE */}
          {activeTab === 'attendance' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" /> July 2026 Attendance Summary
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 font-extrabold text-center">
                  <span className="block text-xl">22</span>
                  <span className="text-[10px] uppercase font-bold">Present Days</span>
                </div>
                <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300 font-extrabold text-center">
                  <span className="block text-xl">1</span>
                  <span className="text-[10px] uppercase font-bold">Late Arrivals</span>
                </div>
                <div className="p-3.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900 text-blue-800 dark:text-blue-300 font-extrabold text-center">
                  <span className="block text-xl">2</span>
                  <span className="text-[10px] uppercase font-bold">Paid Leaves</span>
                </div>
                <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 font-extrabold text-center">
                  <span className="block text-xl">0</span>
                  <span className="text-[10px] uppercase font-bold">Unexcused Absences</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: LEAVE */}
          {activeTab === 'leave' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Annual Leave Balances & History</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                  <span className="font-bold text-slate-500">Casual Leave (CL)</span>
                  <p className="text-lg font-black text-indigo-600">6 / 12 Days Remaining</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                  <span className="font-bold text-slate-500">Sick Leave (SL)</span>
                  <p className="text-lg font-black text-emerald-600">8 / 12 Days Remaining</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                  <span className="font-bold text-slate-500">Earned Leave (EL)</span>
                  <p className="text-lg font-black text-purple-600">12 / 18 Days Remaining</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: PERFORMANCE */}
          {activeTab === 'performance' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center justify-between">
                <span>Annual Review Rating & Goals</span>
                <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-black text-xs">
                  Rating: 4.8 / 5.0 (Exceeds Expectations)
                </span>
              </h3>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Demonstrated high velocity delivery on payment Gateway migration, reducing API latency by 35%. Promoted to Senior Lead tier.
              </p>
            </div>
          )}

          {/* TAB 9: TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Career Milestone Timeline</h3>
              <div className="relative border-l-2 border-indigo-200 dark:border-indigo-900 ml-3 space-y-6">
                {timeline.map((item) => (
                  <div key={item.id} className="relative pl-6">
                    <div className="absolute -left-2 top-1.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-2 border-white dark:border-slate-800" />
                    <div className="flex items-center justify-between">
                      <h4 className="font-extrabold text-slate-900 dark:text-white text-xs">{item.title}</h4>
                      <span className="text-[10px] font-bold text-slate-400">{item.date}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 10: NOTES */}
          {activeTab === 'notes' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">HR & Manager Confidential Notes</h3>
              <div className="space-y-3">
                {notes.map((n) => (
                  <div key={n.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                    <div className="flex justify-between font-bold text-slate-500">
                      <span>{n.author}</span>
                      <span>{n.date}</span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200">{n.text}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <input
                  type="text"
                  placeholder="Add confidential HR note..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
                <button
                  onClick={() => {
                    if (!newNote.trim()) return;
                    setNotes([
                      ...notes,
                      {
                        id: `note-${Date.now()}`,
                        text: newNote,
                        date: new Date().toISOString().split('T')[0],
                        author: 'Sumit Sharma (VP HR)',
                      },
                    ]);
                    setNewNote('');
                  }}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold"
                >
                  Add Note
                </button>
              </div>
            </div>
          )}

          {/* TAB 11: BANK DETAILS */}
          {activeTab === 'bank' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Bank Account & Remittance Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Bank Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.bankName || 'HDFC Bank Ltd'}
                    onChange={(e) => setEmpData({ ...empData, bankName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Account Number</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.bankAccount}
                    onChange={(e) => setEmpData({ ...empData, bankAccount: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold font-mono disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">IFSC Code</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.ifscCode || 'HDFC0000240'}
                    onChange={(e) => setEmpData({ ...empData, ifscCode: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold font-mono disabled:opacity-80"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 12: EDUCATION */}
          {activeTab === 'education' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Highest Qualification & Academic History</h3>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="font-bold text-indigo-600">B.Tech in Computer Science & Engineering</span>
                <p className="text-slate-600 dark:text-slate-300">IIT Bombay • Graduated 2017 • Distinction (CGPA 9.2/10)</p>
              </div>
            </div>
          )}

          {/* TAB 13: EXPERIENCE */}
          {activeTab === 'experience' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Previous Work Experience</h3>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-1">
                <span className="font-bold text-slate-900 dark:text-white">Software Engineer at Paytm Payments</span>
                <p className="text-slate-500">2020 - 2023 (3 Years) • Relieving & Experience Letter Verified</p>
              </div>
            </div>
          )}

          {/* TAB 14: ASSETS */}
          {activeTab === 'assets' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Allocated Company Assets</h3>
              <div className="space-y-2">
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Apple MacBook Pro M3 Max 16"</span>
                    <span className="block text-[10px] text-slate-400">Tag: AST-2026-001 | S/N: C02G789231</span>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-[10px]">
                    Assigned
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 15: EMERGENCY */}
          {activeTab === 'emergency' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Emergency Contacts</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Contact Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.emergencyContactName || 'Sunita Sharma'}
                    onChange={(e) => setEmpData({ ...empData, emergencyContactName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Phone Number</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.emergencyContactPhone || '+91 98200 11223'}
                    onChange={(e) => setEmpData({ ...empData, emergencyContactPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 16: NOMINEE */}
          {activeTab === 'nominee' && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">PF & Gratuity Nominee Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Nominee Name</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.nomineeName || 'Sunita Sharma'}
                    onChange={(e) => setEmpData({ ...empData, nomineeName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
                <div>
                  <label className="block font-bold mb-1 text-slate-600 dark:text-slate-400">Relationship</label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={empData.nomineeRelation || 'Spouse'}
                    onChange={(e) => setEmpData({ ...empData, nomineeRelation: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-semibold disabled:opacity-80"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
          <span className="text-slate-500 font-medium">
            TapiPE Enterprise HRMS • Verified Profile Record ({empData.id})
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-700 text-white font-bold hover:bg-slate-800"
          >
            Close Modal
          </button>
        </div>
      </div>

      {/* Document Preview Overlay */}
      {selectedPreviewDoc && (
        <div className="fixed inset-0 z-60 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-2xl space-y-4 border border-slate-200 dark:border-slate-700 shadow-2xl">
            <div className="flex justify-between items-center">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Document Preview: {selectedPreviewDoc.title}
              </h3>
              <button
                onClick={() => setSelectedPreviewDoc(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 text-center space-y-3">
              <FileText className="w-16 h-16 text-indigo-600 mx-auto" />
              <p className="font-bold text-slate-800 dark:text-slate-100">{selectedPreviewDoc.category}</p>
              <p className="text-xs text-slate-500">{selectedPreviewDoc.title} ({selectedPreviewDoc.fileSize})</p>
              <div className="pt-3 flex justify-center gap-2">
                <a
                  href={selectedPreviewDoc.fileUrl}
                  download={selectedPreviewDoc.title}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" /> Download Official File
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
