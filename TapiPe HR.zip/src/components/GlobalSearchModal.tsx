import React, { useState, useEffect } from 'react';
import {
  Search,
  X,
  Users,
  Receipt,
  BarChart3,
  CalendarCheck2,
  Settings,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { Employee, PayrollRecord, NavigationPage } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  employees: Employee[];
  payroll: PayrollRecord[];
  onNavigate: (page: NavigationPage) => void;
  onOpenPayslipModal: (record: PayrollRecord) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  employees,
  payroll,
  onNavigate,
  onOpenPayslipModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const matchedEmployees = searchTerm
    ? employees.filter(
        (e) =>
          e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          e.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
          e.phone.includes(searchTerm)
      )
    : [];

  const matchedPayroll = searchTerm
    ? payroll.filter((p) =>
        p.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const pagesList: { id: NavigationPage; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Dashboard & HR Summary', icon: Users },
    { id: 'employees', label: 'Employee Management Directory', icon: Users },
    { id: 'attendance', label: 'Attendance & Live Clock-In', icon: CalendarCheck2 },
    { id: 'payroll', label: 'Payroll Processing & Payslips', icon: Receipt },
    { id: 'reports', label: 'Financial & Attendance Reports', icon: BarChart3 },
    { id: 'access', label: 'User Roles & Access Control', icon: ShieldCheck },
    { id: 'settings', label: 'Company Settings & PF Rules', icon: Settings },
  ];

  const matchedPages = searchTerm
    ? pagesList.filter((p) => p.label.toLowerCase().includes(searchTerm.toLowerCase()))
    : pagesList;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-start justify-center pt-20 p-4 animate-in fade-in">
      <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden relative">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search employees, pages, payslips (e.g., Rohan, July, Engineering)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent text-sm font-semibold text-slate-900 dark:text-white focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4 custom-scrollbar text-xs">
          {/* Quick Pages Navigation */}
          {matchedPages.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                System Pages & Views
              </span>
              <div className="space-y-1">
                {matchedPages.map((page) => {
                  const Icon = page.icon;
                  return (
                    <button
                      key={page.id}
                      onClick={() => {
                        onNavigate(page.id);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold transition-colors text-left"
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <span>{page.label}</span>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Matched Employees */}
          {matchedEmployees.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Employees ({matchedEmployees.length})
              </span>
              <div className="space-y-1">
                {matchedEmployees.map((emp) => (
                  <div
                    key={emp.id}
                    onClick={() => {
                      onNavigate('employees');
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold flex items-center justify-center">
                        {emp.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white">{emp.name}</div>
                        <div className="text-[10px] text-slate-400">{emp.department} • {emp.phone}</div>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      ₹{emp.salary.toLocaleString('en-IN')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matched Payroll Payslips */}
          {matchedPayroll.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Payroll Slips ({matchedPayroll.length})
              </span>
              <div className="space-y-1">
                {matchedPayroll.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      onOpenPayslipModal(p);
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-950/50 cursor-pointer transition-colors border border-transparent hover:border-indigo-200"
                  >
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{p.employeeName}</div>
                      <span className="text-[10px] text-slate-400">July 2026 Payslip</span>
                    </div>
                    <span className="px-2.5 py-1 text-xs font-bold bg-indigo-600 text-white rounded-lg">
                      View Slip (₹{p.netSalary.toLocaleString('en-IN')})
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
