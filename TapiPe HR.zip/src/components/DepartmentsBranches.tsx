import React, { useState } from 'react';
import { Building2, Plus, Users, MapPin, Briefcase, Edit2, Trash2, Image, Palette } from 'lucide-react';
import { DepartmentItem, DesignationItem, BranchItem } from '../types';

interface DepartmentsBranchesProps {
  departments: DepartmentItem[];
  designations: DesignationItem[];
  branches: BranchItem[];
  onAddDept: (dept: DepartmentItem) => void;
  onAddBranch: (branch: BranchItem) => void;
}

export const DepartmentsBranches: React.FC<DepartmentsBranchesProps> = ({
  departments: initialDepts,
  designations: initialDesignations,
  branches: initialBranches,
  onAddDept,
  onAddBranch,
}) => {
  const [activeTab, setActiveTab] = useState<'departments' | 'designations' | 'branches'>('departments');
  const [deptList, setDeptList] = useState<DepartmentItem[]>(initialDepts);
  const [designationList, setDesignationList] = useState<DesignationItem[]>(initialDesignations);
  const [branchList, setBranchList] = useState<BranchItem[]>(initialBranches);

  // Department Modals
  const [showDeptModal, setShowDeptModal] = useState(false);
  const [editingDept, setEditingDept] = useState<DepartmentItem | null>(null);
  const [deptName, setDeptName] = useState('');
  const [deptHead, setDeptHead] = useState('Rohan Sharma');
  const [deptColor, setDeptColor] = useState('#4f46e5');
  const [deptLogo, setDeptLogo] = useState('');
  const [deptBudget, setDeptBudget] = useState(500000);

  // Designation Modals
  const [showDsgModal, setShowDsgModal] = useState(false);
  const [editingDsg, setEditingDsg] = useState<DesignationItem | null>(null);
  const [dsgTitle, setDsgTitle] = useState('');
  const [dsgDept, setDsgDept] = useState('Engineering');
  const [dsgLevel, setDsgLevel] = useState('L3');
  const [dsgMinSalary, setDsgMinSalary] = useState(600000);
  const [dsgMaxSalary, setDsgMaxSalary] = useState(1200000);

  // Branch Modals
  const [showBranchModal, setShowBranchModal] = useState(false);
  const [editingBranch, setEditingBranch] = useState<BranchItem | null>(null);
  const [branchName, setBranchName] = useState('');
  const [branchCity, setBranchCity] = useState('');
  const [branchAddress, setBranchAddress] = useState('');

  // Department Actions
  const openDeptModal = (dept?: DepartmentItem) => {
    if (dept) {
      setEditingDept(dept);
      setDeptName(dept.name);
      setDeptHead(dept.headName);
      setDeptColor(dept.color || '#4f46e5');
      setDeptLogo(dept.logoUrl || '');
      setDeptBudget(dept.monthlyBudget);
    } else {
      setEditingDept(null);
      setDeptName('');
      setDeptHead('Rohan Sharma');
      setDeptColor('#4f46e5');
      setDeptLogo('');
      setDeptBudget(500000);
    }
    setShowDeptModal(true);
  };

  const handleSaveDept = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deptName.trim()) return;

    const newDep: DepartmentItem = {
      id: editingDept ? editingDept.id : `DEP-${Date.now()}`,
      name: deptName,
      code: deptName.substring(0, 3).toUpperCase(),
      headName: deptHead,
      employeeCount: editingDept ? editingDept.employeeCount : 1,
      monthlyBudget: deptBudget,
      color: deptColor,
      logoUrl: deptLogo,
    };

    if (editingDept) {
      setDeptList(deptList.map((d) => (d.id === newDep.id ? newDep : d)));
    } else {
      setDeptList([...deptList, newDep]);
      onAddDept(newDep);
    }
    setShowDeptModal(false);
  };

  const handleDeleteDept = (id: string) => {
    if (confirm('Delete this department?')) {
      setDeptList(deptList.filter((d) => d.id !== id));
    }
  };

  // Designation Actions
  const openDsgModal = (dsg?: DesignationItem) => {
    if (dsg) {
      setEditingDsg(dsg);
      setDsgTitle(dsg.title);
      setDsgDept(dsg.department);
      setDsgLevel(dsg.level);
      setDsgMinSalary(dsg.minSalary);
      setDsgMaxSalary(dsg.maxSalary);
    } else {
      setEditingDsg(null);
      setDsgTitle('');
      setDsgDept(deptList[0]?.name || 'Engineering');
      setDsgLevel('L3');
      setDsgMinSalary(600000);
      setDsgMaxSalary(1200000);
    }
    setShowDsgModal(true);
  };

  const handleSaveDsg = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dsgTitle.trim()) return;

    const newDsg: DesignationItem = {
      id: editingDsg ? editingDsg.id : `DSG-${Date.now()}`,
      title: dsgTitle,
      department: dsgDept,
      level: dsgLevel,
      minSalary: Number(dsgMinSalary),
      maxSalary: Number(dsgMaxSalary),
    };

    if (editingDsg) {
      setDesignationList(designationList.map((d) => (d.id === newDsg.id ? newDsg : d)));
    } else {
      setDesignationList([...designationList, newDsg]);
    }
    setShowDsgModal(false);
  };

  const handleDeleteDsg = (id: string) => {
    if (confirm('Delete this designation?')) {
      setDesignationList(designationList.filter((d) => d.id !== id));
    }
  };

  // Branch Actions
  const openBranchModal = (br?: BranchItem) => {
    if (br) {
      setEditingBranch(br);
      setBranchName(br.name);
      setBranchCity(br.city);
      setBranchAddress(br.address);
    } else {
      setEditingBranch(null);
      setBranchName('');
      setBranchCity('Mumbai');
      setBranchAddress('BKC Tech Park');
    }
    setShowBranchModal(true);
  };

  const handleSaveBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchName.trim()) return;

    const newBr: BranchItem = {
      id: editingBranch ? editingBranch.id : `BR-${Date.now()}`,
      name: branchName,
      code: branchName.substring(0, 3).toUpperCase(),
      city: branchCity || 'Mumbai',
      state: 'Maharashtra',
      address: branchAddress,
      employeeCount: editingBranch ? editingBranch.employeeCount : 1,
    };

    if (editingBranch) {
      setBranchList(branchList.map((b) => (b.id === newBr.id ? newBr : b)));
    } else {
      setBranchList([...branchList, newBr]);
      onAddBranch(newBr);
    }
    setShowBranchModal(false);
  };

  const handleDeleteBranch = (id: string) => {
    if (confirm('Delete this office branch?')) {
      setBranchList(branchList.filter((b) => b.id !== id));
    }
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Org Structure
            </span>
            <span className="text-xs text-slate-400">TapiPE Fintech Pvt. Ltd.</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Departments, Designations & Branches
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Manage organizational hierarchy, team heads, salary bands, colors, and office locations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'departments' && (
            <button
              onClick={() => openDeptModal()}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              Add Department
            </button>
          )}
          {activeTab === 'designations' && (
            <button
              onClick={() => openDsgModal()}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              Add Designation
            </button>
          )}
          {activeTab === 'branches' && (
            <button
              onClick={() => openBranchModal()}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              Add Branch
            </button>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 bg-white dark:bg-slate-800/90 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm text-xs font-bold w-max">
        <button
          onClick={() => setActiveTab('departments')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'departments'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          Departments ({deptList.length})
        </button>
        <button
          onClick={() => setActiveTab('designations')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'designations'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          Designations ({designationList.length})
        </button>
        <button
          onClick={() => setActiveTab('branches')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'branches'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          Branches ({branchList.length})
        </button>
      </div>

      {/* Tab Content: Departments */}
      {activeTab === 'departments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {deptList.map((dep) => (
            <div
              key={dep.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3 relative overflow-hidden"
            >
              <div
                className="absolute top-0 left-0 right-0 h-1.5"
                style={{ backgroundColor: dep.color || '#4f46e5' }}
              />

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  {dep.logoUrl ? (
                    <img src={dep.logoUrl} alt={dep.name} className="w-6 h-6 rounded-md object-cover" />
                  ) : (
                    <div
                      className="w-6 h-6 rounded-md flex items-center justify-center text-white text-[10px] font-extrabold"
                      style={{ backgroundColor: dep.color || '#4f46e5' }}
                    >
                      {dep.code}
                    </div>
                  )}
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 font-bold text-[10px] text-slate-700 dark:text-slate-300">
                    {dep.code}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openDeptModal(dep)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteDept(dep.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{dep.name}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Head: {dep.headName}</p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                <span>Monthly Budget:</span>
                <span>₹{dep.monthlyBudget.toLocaleString('en-IN')}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab Content: Designations */}
      {activeTab === 'designations' && (
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                <th className="p-3.5">Designation Title</th>
                <th className="p-3.5">Department</th>
                <th className="p-3.5">Grade Level</th>
                <th className="p-3.5">Salary Band Range (Monthly CTC)</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
              {designationList.map((dsg) => (
                <tr key={dsg.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                  <td className="p-3.5 font-bold text-slate-900 dark:text-white">{dsg.title}</td>
                  <td className="p-3.5 text-indigo-600 dark:text-indigo-400 font-semibold">{dsg.department}</td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 font-mono font-bold">
                      {dsg.level}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                    ₹{dsg.minSalary.toLocaleString('en-IN')} - ₹{dsg.maxSalary.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => openDsgModal(dsg)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteDsg(dsg.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab Content: Branches */}
      {activeTab === 'branches' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {branchList.map((br) => (
            <div
              key={br.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{br.name}</h3>
                  <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                    {br.city}, {br.state}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openBranchModal(br)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteBranch(br.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">{br.address}</p>
            </div>
          ))}
        </div>
      )}

      {/* Department Modal */}
      {showDeptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingDept ? 'Edit Department' : 'Add New Department'}
            </h3>
            <form onSubmit={handleSaveDept} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Department Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Quality Assurance"
                  value={deptName}
                  onChange={(e) => setDeptName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Department Head</label>
                <input
                  type="text"
                  required
                  value={deptHead}
                  onChange={(e) => setDeptHead(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Theme Accent Color</label>
                  <input
                    type="color"
                    value={deptColor}
                    onChange={(e) => setDeptColor(e.target.value)}
                    className="w-full h-9 rounded-xl border border-slate-200 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Monthly Budget (₹)</label>
                  <input
                    type="number"
                    value={deptBudget}
                    onChange={(e) => setDeptBudget(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold mb-1">Department Logo URL</label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={deptLogo}
                  onChange={(e) => setDeptLogo(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowDeptModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Department
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Designation Modal */}
      {showDsgModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingDsg ? 'Edit Designation' : 'Add Designation'}
            </h3>
            <form onSubmit={handleSaveDsg} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Designation Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lead Frontend Architect"
                  value={dsgTitle}
                  onChange={(e) => setDsgTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Department</label>
                  <select
                    value={dsgDept}
                    onChange={(e) => setDsgDept(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    {deptList.map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Grade Level</label>
                  <input
                    type="text"
                    required
                    value={dsgLevel}
                    onChange={(e) => setDsgLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Min Salary CTC (₹)</label>
                  <input
                    type="number"
                    value={dsgMinSalary}
                    onChange={(e) => setDsgMinSalary(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Max Salary CTC (₹)</label>
                  <input
                    type="number"
                    value={dsgMaxSalary}
                    onChange={(e) => setDsgMaxSalary(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowDsgModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Designation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Branch Modal */}
      {showBranchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingBranch ? 'Edit Branch' : 'Add Office Branch'}
            </h3>
            <form onSubmit={handleSaveBranch} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Branch Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hyderabad Fintech Hub"
                  value={branchName}
                  onChange={(e) => setBranchName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">City</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hyderabad"
                  value={branchCity}
                  onChange={(e) => setBranchCity(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Full Address</label>
                <input
                  type="text"
                  value={branchAddress}
                  onChange={(e) => setBranchAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowBranchModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Branch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

