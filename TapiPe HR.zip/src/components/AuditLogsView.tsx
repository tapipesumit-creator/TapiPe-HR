import React from 'react';
import { ShieldCheck, Lock, Activity, User } from 'lucide-react';
import { AuditLogItem } from '../types';

interface AuditLogsViewProps {
  logs: AuditLogItem[];
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ logs }) => {
  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Security Compliance
            </span>
            <span className="text-xs text-slate-400">SOC-2 & GDPR Immutable Trail</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Security Audit & Activity Logs
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Immutable log of system modifications, payroll runs, permission changes, and login attempts.
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
              <th className="p-3.5">Timestamp</th>
              <th className="p-3.5">User</th>
              <th className="p-3.5">Role</th>
              <th className="p-3.5">Action Executed</th>
              <th className="p-3.5">Module</th>
              <th className="p-3.5">IP Address</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
            {logs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                <td className="p-3.5 font-mono text-slate-400">{log.timestamp}</td>
                <td className="p-3.5 font-bold text-slate-900 dark:text-white">{log.user || log.userName}</td>
                <td className="p-3.5 font-bold text-indigo-600 dark:text-indigo-400 uppercase text-[10px]">{log.role}</td>
                <td className="p-3.5">{log.action}</td>
                <td className="p-3.5">
                  <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 font-bold text-[10px]">
                    {log.module}
                  </span>
                </td>
                <td className="p-3.5 font-mono text-slate-400">{log.ipAddress}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
