import React from 'react';
import {
  LayoutDashboard,
  Users,
  Clock,
  Wallet,
  Building2,
  CalendarDays,
  FileText,
  Briefcase,
  Target,
  Laptop,
  HelpCircle,
  Megaphone,
  BarChart3,
  ShieldCheck,
  Settings,
  History,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Sliders,
  CalendarHeart,
  Lock,
} from 'lucide-react';
import { NavigationPage, UserAccount } from '../types';

interface SidebarProps {
  currentPage: NavigationPage;
  currentUser: UserAccount;
  onNavigate: (page: NavigationPage) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  openAIChat: () => void;
  unreadNotificationsCount: number;
}

interface MenuItem {
  id: NavigationPage;
  label: string;
  icon: React.ElementType;
  badge?: string;
}

interface MenuGroup {
  title: string;
  items: MenuItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  currentUser,
  onNavigate,
  collapsed,
  onToggleCollapse,
  openAIChat,
  unreadNotificationsCount,
}) => {
  const menuGroups: MenuGroup[] = [
    {
      title: 'CORE HR & PAYROLL',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'employees', label: 'Employee Directory', icon: Users, badge: '26 Active' },
        { id: 'attendance', label: 'Attendance & Punch', icon: Clock },
        { id: 'payroll', label: 'Payroll & Payslips', icon: Wallet, badge: 'July Batch' },
        { id: 'salary_structure', label: 'Salary Structure', icon: Sliders },
      ],
    },
    {
      title: 'ORGANIZATION & LEAVES',
      items: [
        { id: 'leave_management', label: 'Leave & Approvals', icon: CalendarHeart, badge: '2 New' },
        { id: 'holiday_calendar', label: 'Holiday Calendar', icon: CalendarDays },
        { id: 'departments_branches', label: 'Depts & Branches', icon: Building2 },
      ],
    },
    {
      title: 'TALENT & OPERATIONS',
      items: [
        { id: 'recruitment', label: 'Recruitment', icon: Briefcase, badge: '3 Jobs' },
        { id: 'document_center', label: 'Document Center', icon: FileText },
        { id: 'performance', label: 'Performance & KPI', icon: Target },
        { id: 'assets_inventory', label: 'Assets & IT', icon: Laptop },
        { id: 'visitor_helpdesk', label: 'Helpdesk & Visitors', icon: HelpCircle },
        { id: 'notices_announcements', label: 'Notices & Events', icon: Megaphone },
      ],
    },
    {
      title: 'ANALYTICS & GOVERNANCE',
      items: [
        { id: 'reports', label: 'Reports & Export', icon: BarChart3 },
        { id: 'access', label: 'User Access & Roles', icon: ShieldCheck },
        { id: 'settings', label: 'Company Settings', icon: Settings },
        { id: 'audit_logs', label: 'Audit & Activity Logs', icon: History },
      ],
    },
  ];

  return (
    <aside
      className={`relative flex flex-col h-screen border-r transition-all duration-300 z-30 select-none ${
        collapsed ? 'w-20' : 'w-64'
      } bg-slate-900 border-slate-800 text-slate-100 shadow-xl`}
    >
      {/* Brand Logo & Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-slate-800/80 shrink-0">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-emerald-400 text-white font-black text-xl shadow-lg shadow-indigo-500/20 shrink-0">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
                TapiPE HR
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                TapiPE Fintech
              </span>
            </div>
          )}
        </div>

        <button
          onClick={onToggleCollapse}
          className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors hidden sm:flex"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation Scroll Area */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-4 custom-scrollbar">
        {/* ASK SUMIT AI Button */}
        <button
          onClick={openAIChat}
          className={`w-full flex items-center gap-3 p-3 rounded-2xl bg-gradient-to-r from-purple-900/60 via-indigo-900/60 to-slate-800 border border-purple-500/40 text-purple-200 hover:border-purple-400 transition-all shadow-md group ${
            collapsed ? 'justify-center px-2' : ''
          }`}
          title="Ask Sumit - Super Admin AI Assistant"
        >
          <div className="p-2 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-500 text-white shadow-sm shrink-0 group-hover:scale-105 transition-transform">
            <Sparkles className="w-4 h-4 text-purple-100 animate-spin-slow" />
          </div>
          {!collapsed && (
            <div className="flex flex-col text-left overflow-hidden">
              <span className="text-xs font-black text-white tracking-tight flex items-center gap-1.5">
                ASK SUMIT
                <span className="text-[9px] bg-purple-500/30 text-purple-300 font-bold px-1.5 py-0.2 rounded border border-purple-400/30">
                  AI HR
                </span>
              </span>
              <span className="text-[10px] text-purple-300/80 truncate">Instant payroll queries & rules</span>
            </div>
          )}
        </button>

        {/* Grouped Menu List */}
        {menuGroups.map((group, groupIdx) => (
          <div key={groupIdx} className="space-y-1">
            {!collapsed ? (
              <div className="px-2 pt-1 pb-1.5 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">
                {group.title}
              </div>
            ) : (
              <div className="h-px bg-slate-800 my-2" />
            )}

            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              const isAllowed = currentUser.permissions ? (currentUser.permissions[item.id] ?? false) : true;

              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl font-medium text-xs transition-all duration-200 group relative ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                      : isAllowed
                      ? 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      : 'text-slate-600 hover:bg-slate-800/40 cursor-pointer'
                  }`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-transform duration-200 ${
                      isActive ? 'scale-110 text-white' : isAllowed ? 'text-slate-400 group-hover:text-slate-200' : 'text-slate-600'
                    }`}
                  />

                  {!collapsed && (
                    <span className={`truncate flex-1 text-left ${!isAllowed ? 'opacity-60' : ''}`}>
                      {item.label}
                    </span>
                  )}

                  {!collapsed && !isAllowed && (
                    <Lock className="w-3 h-3 text-slate-500 shrink-0" title="Restricted Page" />
                  )}

                  {!collapsed && isAllowed && item.badge && (
                    <span
                      className={`text-[10px] px-2 py-0.2 rounded-full font-bold tracking-wide ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-800 text-slate-300 group-hover:bg-slate-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}

                  {/* Tooltip for collapsed state */}
                  {collapsed && (
                    <div className="absolute left-full ml-2 px-2.5 py-1 bg-slate-800 text-slate-100 text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                      {item.label} {!isAllowed && '(Restricted)'}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Footer Status */}
      {!collapsed && (
        <div className="p-3 mx-3 mb-3 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center gap-3 shrink-0">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div className="flex flex-col text-left overflow-hidden">
            <span className="text-xs font-bold text-slate-200 truncate">TapiPE Cloud</span>
            <span className="text-[10px] text-slate-400">RBAC Secured 🔒</span>
          </div>
        </div>
      )}
    </aside>
  );
};
