import React, { useState } from 'react';
import { FileText, Download, Printer, Shield, User, Sparkles, Plus, Edit2, Trash2, Copy, Eye, Mail, FileCode, CheckCircle2 } from 'lucide-react';
import { DocumentItem, Employee, DocumentTemplateItem } from '../types';

interface DocumentCenterProps {
  documents: DocumentItem[];
  employees: Employee[];
  templates?: DocumentTemplateItem[];
  onAddDocument: (doc: DocumentItem) => void;
  onSaveTemplate?: (tmpl: DocumentTemplateItem) => void;
  onDeleteTemplate?: (tmplId: string) => void;
}

export const DocumentCenter: React.FC<DocumentCenterProps> = ({
  documents: initialDocs,
  employees,
  templates: initialTemplates = [],
  onAddDocument,
  onSaveTemplate,
  onDeleteTemplate,
}) => {
  const [activeTab, setActiveTab] = useState<'vault' | 'templates'>('vault');
  const [docList, setDocList] = useState<DocumentItem[]>(initialDocs);
  const [selectedDoc, setSelectedDoc] = useState<DocumentItem | null>(initialDocs[0] || null);

  const [templateList, setTemplateList] = useState<DocumentTemplateItem[]>(initialTemplates);
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplateItem | null>(initialTemplates[0] || null);

  // Modals
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<DocumentTemplateItem | null>(null);

  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || 'EMP-101');
  const [selectedTemplateId, setSelectedTemplateId] = useState(initialTemplates[0]?.id || '');
  const [docType, setDocType] = useState<DocumentItem['type']>('Offer Letter');

  const [emailSuccess, setEmailSuccess] = useState(false);

  // Template Form State
  const [tmplTitle, setTmplTitle] = useState('');
  const [tmplCategory, setTmplCategory] = useState('Onboarding');
  const [tmplType, setTmplType] = useState('Offer Letter');
  const [tmplBody, setTmplBody] = useState('');

  const activeEmp = employees.find((e) => e.id === (selectedDoc?.employeeId || selectedEmpId)) || employees[0];

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find((e) => e.id === selectedEmpId) || employees[0];

    const newDoc: DocumentItem = {
      id: `DOC-${Date.now()}`,
      employeeId: emp.id,
      employeeName: emp.name,
      type: docType,
      title: `Official ${docType} - ${emp.name}`,
      issuedDate: new Date().toISOString().split('T')[0],
      status: 'Issued',
    };

    setDocList([newDoc, ...docList]);
    onAddDocument(newDoc);
    setSelectedDoc(newDoc);
    setShowGenerateModal(false);
  };

  const openTemplateModal = (tmpl?: DocumentTemplateItem) => {
    if (tmpl) {
      setEditingTemplate(tmpl);
      setTmplTitle(tmpl.title);
      setTmplCategory(tmpl.category);
      setTmplType(tmpl.type);
      setTmplBody(tmpl.templateBody);
    } else {
      setEditingTemplate(null);
      setTmplTitle('New Custom Employment Template');
      setTmplCategory('Onboarding');
      setTmplType('Offer Letter');
      setTmplBody('Dear {{EMPLOYEE_NAME}},\n\nWe are pleased to offer you the role of {{DESIGNATION}} at {{COMPANY_NAME}}.\nSalary: ₹{{SALARY}}\nJoining Date: {{JOINING_DATE}}.\n\nSincerely,\nSumit (Super Admin)');
    }
    setShowTemplateModal(true);
  };

  const handleSaveTemplateForm = (e: React.FormEvent) => {
    e.preventDefault();
    const newTmpl: DocumentTemplateItem = {
      id: editingTemplate ? editingTemplate.id : `TMPL-${Date.now()}`,
      title: tmplTitle,
      category: tmplCategory,
      type: tmplType,
      templateBody: tmplBody,
      lastUpdated: new Date().toISOString().split('T')[0],
      isCustom: true,
    };

    if (editingTemplate) {
      setTemplateList(templateList.map((t) => (t.id === newTmpl.id ? newTmpl : t)));
    } else {
      setTemplateList([newTmpl, ...templateList]);
    }

    if (onSaveTemplate) onSaveTemplate(newTmpl);
    setSelectedTemplate(newTmpl);
    setShowTemplateModal(false);
  };

  const handleDeleteTmpl = (id: string) => {
    if (confirm('Are you sure you want to delete this document template?')) {
      setTemplateList(templateList.filter((t) => t.id !== id));
      if (onDeleteTemplate) onDeleteTemplate(id);
      if (selectedTemplate?.id === id) setSelectedTemplate(templateList[0] || null);
    }
  };

  const handleDuplicateTmpl = (tmpl: DocumentTemplateItem) => {
    const dup: DocumentTemplateItem = {
      ...tmpl,
      id: `TMPL-${Date.now()}`,
      title: `${tmpl.title} (Copy)`,
      lastUpdated: new Date().toISOString().split('T')[0],
      isCustom: true,
    };
    setTemplateList([dup, ...templateList]);
    if (onSaveTemplate) onSaveTemplate(dup);
    setSelectedTemplate(dup);
  };

  // Helper to resolve variables in body
  const renderTemplateText = (bodyText: string, emp: Employee) => {
    if (!bodyText) return '';
    return bodyText
      .replaceAll('{{EMPLOYEE_NAME}}', emp.name)
      .replaceAll('{{DESIGNATION}}', emp.designation)
      .replaceAll('{{DEPARTMENT}}', emp.department)
      .replaceAll('{{SALARY}}', emp.salary ? emp.salary.toLocaleString('en-IN') : '0')
      .replaceAll('{{JOINING_DATE}}', emp.joiningDate || '2026-08-01')
      .replaceAll('{{COMPANY_NAME}}', 'TapiPE Fintech Pvt. Ltd.')
      .replaceAll('{{BRANCH}}', emp.branch || 'Mumbai HQ')
      .replaceAll('{{SIGNATORY}}', 'Sumit (Super Admin & Authorized Signatory)');
  };

  const sendDocEmail = () => {
    setEmailSuccess(true);
    setTimeout(() => setEmailSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Document Vault & Templates
            </span>
            <span className="text-xs text-slate-400">TapiPE HR Automated Generator</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Official Document & Letterhead Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Generate and manage Offer Letters, Appointment Letters, Experience Letters, ID Cards, and Warning Notices.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => openTemplateModal()}
            className="flex items-center gap-2 px-3.5 py-2.5 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 transition-all"
          >
            <Plus className="w-4 h-4 text-indigo-400" />
            Add Template
          </button>
          <button
            onClick={() => setShowGenerateModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            Generate Document
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-2">
        <button
          onClick={() => setActiveTab('vault')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'vault'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          Issued Documents ({docList.length})
        </button>
        <button
          onClick={() => setActiveTab('templates')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'templates'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
          }`}
        >
          <FileCode className="w-4 h-4" />
          Template Manager ({templateList.length})
        </button>
      </div>

      {/* TAB 1: ISSUED DOCUMENTS VAULT */}
      {activeTab === 'vault' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Document List Panel */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
            <h3 className="font-bold text-slate-900 dark:text-white text-base border-b border-slate-100 dark:border-slate-700 pb-3">
              Issued Document Vault
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar pr-1">
              {docList.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDoc(doc)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    selectedDoc?.id === doc.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 shadow-xs'
                      : 'bg-slate-50/50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">{doc.title}</span>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[9px] shrink-0">
                      {doc.type}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                    <span>{doc.employeeName}</span>
                    <span>Issued: {doc.issuedDate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Preview & Printable Document Stage */}
          <div className="lg:col-span-2 p-6 rounded-2xl bg-slate-100 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-700">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Document Preview: {selectedDoc?.title || 'Offer Letter'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Official TapiPE Fintech Letterhead</p>
              </div>

              <div className="flex items-center gap-2">
                {emailSuccess && (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Emailed!
                  </span>
                )}
                <button
                  onClick={sendDocEmail}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-200"
                >
                  <Mail className="w-4 h-4 text-purple-600" /> Email PDF
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-200"
                >
                  <Printer className="w-4 h-4 text-slate-600" /> Print
                </button>
                <button
                  onClick={() => alert(`Downloading official PDF for ${selectedDoc?.title}...`)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                >
                  <Download className="w-4 h-4" /> Download PDF
                </button>
              </div>
            </div>

            {/* Document Preview Paper Canvas */}
            <div className="p-8 bg-white text-slate-900 rounded-2xl shadow-lg border border-slate-200 font-sans space-y-6 text-xs leading-relaxed max-w-2xl mx-auto">
              {/* Letterhead Header */}
              <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
                <div>
                  <h2 className="text-xl font-black text-indigo-950 tracking-tight">TAPIPE FINTECH PVT. LTD.</h2>
                  <p className="text-[10px] text-slate-500">302 Fintech Towers, BKC, Mumbai 400051 • GSTIN: 27AAAAA0000A1Z5</p>
                </div>
                <div className="p-2.5 rounded-xl bg-indigo-600 text-white font-extrabold text-sm">
                  TapiPE HR
                </div>
              </div>

              {/* Document Title */}
              <div className="text-center pt-2">
                <h1 className="text-base font-extrabold tracking-widest uppercase text-indigo-900 border-b border-indigo-200 inline-block pb-1">
                  OFFICIAL {selectedDoc?.type?.toUpperCase() || 'LETTER'}
                </h1>
                <p className="text-[10px] text-slate-400 mt-1">Ref: TAP/{selectedDoc?.id || 'DOC-101'}/2026</p>
              </div>

              {/* Letter Body */}
              <div className="space-y-3 text-slate-800">
                <p className="font-bold">Date: {selectedDoc?.issuedDate || 'July 31, 2026'}</p>
                <p className="font-bold">To,<br />{activeEmp.name}<br />{activeEmp.designation}, {activeEmp.department}<br />TapiPE Fintech Pvt. Ltd.</p>

                <p>Dear <strong>{activeEmp.name}</strong>,</p>

                <p>
                  We are pleased to issue this official <strong>{selectedDoc?.type || 'Employment Document'}</strong> on behalf of <strong>TapiPE Fintech Pvt. Ltd.</strong> in recognition of your role as <strong>{activeEmp.designation}</strong> within our <strong>{activeEmp.department}</strong> division.
                </p>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 font-mono text-[11px]">
                  <div>• Employee ID: <strong>{activeEmp.id}</strong></div>
                  <div>• Official Joining Date: <strong>{activeEmp.joiningDate}</strong></div>
                  <div>• Base Monthly CTC: <strong>₹{activeEmp.salary.toLocaleString('en-IN')}</strong></div>
                  <div>• Office Location: <strong>{activeEmp.branch || 'Mumbai HQ'}</strong></div>
                </div>

                <p>
                  This document confirms your employment status, compliance with Indian labor regulations, and entitlement to company provident fund (PF) and group health insurance benefits.
                </p>

                <p>We look forward to your continued dedication and excellence.</p>
              </div>

              {/* Signature Block */}
              <div className="pt-8 flex items-end justify-between border-t border-slate-200">
                <div>
                  <div className="font-serif italic text-lg text-indigo-900 font-bold">Sumit & Team</div>
                  <div className="font-bold text-xs">Sumit</div>
                  <div className="text-[10px] text-slate-500">Super Admin & Authorized Signatory</div>
                </div>
                <div className="text-right text-[10px] text-slate-400">
                  Official Seal of TapiPE Fintech Pvt. Ltd.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TEMPLATE MANAGER */}
      {activeTab === 'templates' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Templates List */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Custom Templates ({templateList.length})
              </h3>
              <button
                onClick={() => openTemplateModal()}
                className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 hover:bg-indigo-100 transition-all text-xs font-bold"
              >
                + New
              </button>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar">
              {templateList.map((tmpl) => (
                <div
                  key={tmpl.id}
                  onClick={() => setSelectedTemplate(tmpl)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    selectedTemplate?.id === tmpl.id
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 shadow-xs'
                      : 'bg-slate-50/50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">{tmpl.title}</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-[9px] shrink-0">
                      {tmpl.type}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                    <span>Category: {tmpl.category}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDuplicateTmpl(tmpl);
                        }}
                        title="Duplicate Template"
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md"
                      >
                        <Copy className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openTemplateModal(tmpl);
                        }}
                        title="Edit Template"
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-indigo-600" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTmpl(tmpl.id);
                        }}
                        title="Delete Template"
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Selected Template Live Code & Preview */}
          <div className="lg:col-span-2 p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            {selectedTemplate ? (
              <>
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-700">
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      Template: {selectedTemplate.title}
                    </h3>
                    <p className="text-xs text-slate-500">
                      Type: {selectedTemplate.type} • Category: {selectedTemplate.category}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openTemplateModal(selectedTemplate)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-indigo-600 text-white"
                    >
                      <Edit2 className="w-3.5 h-3.5" /> Edit Template
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  {/* Template Raw Body Code */}
                  <div className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono space-y-2">
                    <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Raw Template Markup</div>
                    <pre className="whitespace-pre-wrap leading-relaxed text-[11px] text-slate-300">
                      {selectedTemplate.templateBody}
                    </pre>
                  </div>

                  {/* Rendered Live Preview with Employee Data */}
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold uppercase tracking-wider">Live Dynamic Preview ({activeEmp.name})</div>
                    <div className="whitespace-pre-wrap leading-relaxed text-[11px] text-slate-800 dark:text-slate-200 font-sans">
                      {renderTemplateText(selectedTemplate.templateBody, activeEmp)}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="p-12 text-center text-slate-500">Select or create a template to preview.</div>
            )}
          </div>
        </div>
      )}

      {/* Generate Document Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Generate Official Document</h3>
            <form onSubmit={handleGenerate} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Select Employee</label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.id} - {emp.department})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Document Type</label>
                <select
                  value={docType}
                  onChange={(e) => setDocType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                >
                  <option value="Offer Letter">Offer Letter</option>
                  <option value="Appointment Letter">Appointment Letter</option>
                  <option value="Experience Letter">Experience Letter</option>
                  <option value="Warning Letter">Warning Letter</option>
                  <option value="Promotion Letter">Promotion Letter</option>
                  <option value="Relieving Letter">Relieving Letter</option>
                  <option value="ID Card">ID Card</option>
                  <option value="Salary Slip">Salary Slip</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowGenerateModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Generate Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Template Modal */}
      {showTemplateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-lg space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {editingTemplate ? 'Edit Custom Template' : 'Create Custom Template'}
            </h3>

            <form onSubmit={handleSaveTemplateForm} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Template Title</label>
                <input
                  type="text"
                  required
                  value={tmplTitle}
                  onChange={(e) => setTmplTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={tmplCategory}
                    onChange={(e) => setTmplCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  >
                    <option value="Onboarding">Onboarding</option>
                    <option value="Compliance">Compliance</option>
                    <option value="Offboarding">Offboarding</option>
                    <option value="General">General</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Document Type</label>
                  <input
                    type="text"
                    value={tmplType}
                    onChange={(e) => setTmplType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-semibold">Template Body (Markdown / Placeholders)</label>
                  <span className="text-[10px] text-indigo-500 font-mono">Variables: &#123;&#123;EMPLOYEE_NAME&#125;&#125;, &#123;&#123;DESIGNATION&#125;&#125;</span>
                </div>
                <textarea
                  rows={8}
                  value={tmplBody}
                  onChange={(e) => setTmplBody(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-mono text-[11px]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowTemplateModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Template
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

