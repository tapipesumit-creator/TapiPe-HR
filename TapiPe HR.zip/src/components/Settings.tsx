import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Building2,
  DollarSign,
  CheckCircle2,
  Save,
  Globe,
  Sliders,
  Shield,
  Upload,
  Image,
  ToggleLeft,
  ToggleRight,
  Sun,
  Moon,
  Laptop,
} from 'lucide-react';
import { CompanySettings, SalaryRules } from '../types';

interface SettingsProps {
  companySettings: CompanySettings;
  salaryRules: SalaryRules;
  onSaveSettings: (settings: CompanySettings, rules: SalaryRules) => void;
  isDarkMode?: boolean;
  onToggleTheme?: () => void;
}

export const Settings: React.FC<SettingsProps> = ({
  companySettings,
  salaryRules,
  onSaveSettings,
  isDarkMode,
  onToggleTheme,
}) => {
  const [settingsForm, setSettingsForm] = useState<CompanySettings>({ ...companySettings });
  const [rulesForm, setRulesForm] = useState<SalaryRules>({ ...salaryRules });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(settingsForm, rulesForm);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const toggleRule = (key: keyof SalaryRules) => {
    setRulesForm((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const payrollToggles: { key: keyof SalaryRules; label: string; desc: string }[] = [
    { key: 'pfEnabled', label: 'Provident Fund (EPF 12%)', desc: 'Statutory 12% deduction on Basic Salary' },
    { key: 'esiEnabled', label: 'Employee State Insurance (ESI 0.75%)', desc: 'Statutory medical insurance for salary ≤ ₹21,000' },
    { key: 'ptEnabled', label: 'Professional Tax (PT)', desc: 'State government statutory slab tax deduction (₹200/mo)' },
    { key: 'tdsEnabled', label: 'Tax Deducted at Source (TDS)', desc: 'Income tax withholding as per Govt tax slabs' },
    { key: 'loanEnabled', label: 'Salary Loan & Advances', desc: 'Auto-deduct approved salary loans & advance payouts' },
    { key: 'overtimeEnabled', label: 'Overtime Pay Multiplier', desc: 'Calculate extra hours at configured overtime rate' },
    { key: 'nightShiftEnabled', label: 'Night Shift Allowance', desc: 'Calculate night shift differential allowances' },
    { key: 'bonusEnabled', label: 'Performance Bonus & Commission', desc: 'Include performance incentives in gross payout' },
    { key: 'lateDeductionEnabled', label: 'Late Attendance Penalty', desc: 'Auto-penalty for late check-in beyond grace period' },
    { key: 'reimbursementEnabled', label: 'Expense Reimbursements', desc: 'Tax-free travel & operational expense payouts' },
  ];

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Company & Payroll Settings
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
              Admin Governance
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Manage company branding, statutory switches (PF/ESI/PT/TDS), bank details & payroll rules.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-slate-950 text-xs font-bold rounded-xl animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            Settings Saved & Applied Live!
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Company Details & Branding */}
        <div className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-700">
            <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-white text-base">Company Profile & Branding</h2>
              <p className="text-xs text-slate-500">Legal entity info, custom logos, signature, and tax credentials.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Registered Company Name
              </label>
              <input
                type="text"
                required
                value={settingsForm.companyName}
                onChange={(e) => setSettingsForm({ ...settingsForm, companyName: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Legal Entity Name
              </label>
              <input
                type="text"
                value={settingsForm.legalEntity || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, legalEntity: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-semibold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                GSTIN Number
              </label>
              <input
                type="text"
                value={settingsForm.gstin}
                onChange={(e) => setSettingsForm({ ...settingsForm, gstin: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 uppercase font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                PAN Number
              </label>
              <input
                type="text"
                value={settingsForm.panNumber || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, panNumber: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 uppercase font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Official Contact Email
              </label>
              <input
                type="email"
                value={settingsForm.contactEmail}
                onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Phone Number
              </label>
              <input
                type="text"
                value={settingsForm.contactPhone || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-3">
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Registered Office Address
              </label>
              <input
                type="text"
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
            </div>

            {/* Logos & Assets */}
            <div className="sm:col-span-2 lg:col-span-3 pt-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Company Logo URL (Main)
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={settingsForm.companyLogoUrl || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, companyLogoUrl: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Digital Signature Image URL
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={settingsForm.digitalSignatureUrl || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, digitalSignatureUrl: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Official Website
                </label>
                <input
                  type="text"
                  placeholder="https://tapipe.in"
                  value={settingsForm.website || ''}
                  onChange={(e) => setSettingsForm({ ...settingsForm, website: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-xs"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 2: Statutory & Payroll ON/OFF Toggles */}
        <div className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-700">
            <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-white text-base">
                Payroll Statutory & Component Switches
              </h2>
              <p className="text-xs text-slate-500">
                Turn specific statutory deductions or allowance calculations ON or OFF live across all payslips.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {payrollToggles.map((item) => {
              const isEnabled = Boolean(rulesForm[item.key]);

              return (
                <div
                  key={item.key}
                  onClick={() => toggleRule(item.key)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isEnabled
                      ? 'bg-purple-50/60 dark:bg-purple-950/30 border-purple-300 dark:border-purple-700/60'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/60 opacity-60'
                  }`}
                >
                  <div className="flex flex-col pr-3">
                    <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.desc}
                    </span>
                  </div>

                  <button
                    type="button"
                    className={`p-1.5 rounded-xl font-bold text-xs shrink-0 flex items-center gap-1.5 transition-all ${
                      isEnabled
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {isEnabled ? (
                      <>
                        <ToggleRight className="w-5 h-5 text-emerald-300" />
                        <span>ENABLED</span>
                      </>
                    ) : (
                      <>
                        <ToggleLeft className="w-5 h-5 text-slate-400" />
                        <span>OFF</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Section 3: Statutory Rates & Working Days */}
        <div className="p-6 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-700">
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-white text-base">Standard Working Days & Percentage Rates</h2>
              <p className="text-xs text-slate-500">Configure default working days per month and percentage calculation factors.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Standard Working Days / Month
              </label>
              <input
                type="number"
                min={20}
                max={31}
                value={rulesForm.standardWorkingDays}
                onChange={(e) => setRulesForm({ ...rulesForm, standardWorkingDays: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Employee PF Contribution (%)
              </label>
              <input
                type="number"
                step={0.5}
                value={rulesForm.pfPercentage}
                onChange={(e) => setRulesForm({ ...rulesForm, pfPercentage: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                ESI Contribution (%)
              </label>
              <input
                type="number"
                step={0.25}
                value={rulesForm.esiPercentage}
                onChange={(e) => setRulesForm({ ...rulesForm, esiPercentage: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Overtime Rate (₹ / Hour)
              </label>
              <input
                type="number"
                step={50}
                value={rulesForm.overtimeRatePerHour}
                onChange={(e) => setRulesForm({ ...rulesForm, overtimeRatePerHour: Number(e.target.value) })}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs shadow-lg shadow-indigo-600/25 transition-all hover:scale-102"
          >
            <Save className="w-4 h-4" />
            Save Rules & Company Settings
          </button>
        </div>
      </form>
    </div>
  );
};

