import React from 'react';
import { ShieldAlert, ArrowLeft, Lock, Building, UserCheck } from 'lucide-react';
import { UserAccount, NavigationPage } from '../types';

interface AccessDeniedProps {
  currentUser: UserAccount;
  targetPage: NavigationPage;
  onNavigateHome: () => void;
}

export const AccessDenied: React.FC<AccessDeniedProps> = ({
  currentUser,
  targetPage,
  onNavigateHome,
}) => {
  const pageTitles: Record<NavigationPage, string> = {
    dashboard: 'Dashboard',
    employees: 'Employee Directory',
    attendance: 'Attendance & Punch',
    payroll: 'Payroll Processing & Payslips',
    salary_structure: 'Salary Structure Configuration',
    leave_management: 'Leave Management & Approvals',
    holiday_calendar: 'Holiday Calendar',
    departments_branches: 'Departments & Branches',
    recruitment: 'Recruitment & Job Postings',
    document_center: 'Document Center & Generation',
    performance: 'Performance Reviews & KPIs',
    assets_inventory: 'Assets & IT Inventory',
    visitor_helpdesk: 'Visitor Logs & Helpdesk',
    notices_announcements: 'Notices & Company Broadcasts',
    reports: 'Reports & Export Analytics',
    access: 'User Access & Role RBAC Management',
    settings: 'Company Settings',
    audit_logs: 'Security Audit & Activity Logs',
  };

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-300">
      <div className="max-w-md w-full bg-white dark:bg-slate-800/90 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl p-8 space-y-6 relative overflow-hidden">
        {/* Top Accent Stripe */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-rose-500 via-purple-600 to-rose-500" />

        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 shadow-md">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
            Access Restricted (403 Unauthorized)
          </span>
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Page Permission Required
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Your current role (<span className="font-bold uppercase text-indigo-600 dark:text-indigo-400">{currentUser.role}</span>) does not have authorization to access the <span className="font-bold text-slate-800 dark:text-slate-200">"{pageTitles[targetPage] || targetPage}"</span> module.
          </p>
        </div>

        {/* Current User Card */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-700/80 text-left flex items-center justify-between text-xs">
          <div>
            <div className="font-bold text-slate-900 dark:text-white">{currentUser.name}</div>
            <div className="text-[11px] text-slate-400">{currentUser.email}</div>
          </div>
          <span className="px-2.5 py-1 text-[10px] font-extrabold uppercase rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
            {currentUser.role}
          </span>
        </div>

        <div className="pt-2">
          <button
            onClick={onNavigateHome}
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-md shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Allowed Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};
