import React, { useState } from 'react';
import {
  DollarSign,
  Download,
  CheckCircle,
  Clock,
  Search,
  Filter,
  FileText,
  TrendingUp,
  AlertCircle,
  Lock,
} from 'lucide-react';
import { PayrollRecord, SalaryRules, UserRole } from '../types';

interface PayrollProps {
  payroll: PayrollRecord[];
  salaryRules: SalaryRules;
  role: UserRole;
  onUpdatePayrollBonusDeduction: (id: string, bonus: number, deduction: number) => void;
  onOpenPayslipModal: (record: PayrollRecord) => void;
  onProcessAllPayroll: () => void;
}

export const Payroll: React.FC<PayrollProps> = ({
  payroll,
  salaryRules,
  role,
  onUpdatePayrollBonusDeduction,
  onOpenPayslipModal,
  onProcessAllPayroll,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');

  // Modal for editing Bonus & Deduction
  const [editingRecord, setEditingRecord] = useState<PayrollRecord | null>(null);
  const [bonusInput, setBonusInput] = useState<number>(0);
  const [deductionInput, setDeductionInput] = useState<number>(0);

  const handleOpenEdit = (rec: PayrollRecord) => {
    setEditingRecord(rec);
    setBonusInput(rec.bonus);
    setDeductionInput(rec.deduction || 0);
  };

  const handleSaveBonusDeduction = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRecord) {
      onUpdatePayrollBonusDeduction(editingRecord.id, Number(bonusInput), Number(deductionInput));
      setEditingRecord(null);
    }
  };

  const filteredPayroll = payroll.filter((p) => {
    const matchesSearch =
      p.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDept = selectedDept === 'all' || p.department === selectedDept;

    return matchesSearch && matchesDept;
  });

  const totalNetPayout = payroll.reduce((acc, curr) => acc + curr.netSalary, 0);
  const totalPF = payroll.reduce((acc, curr) => acc + curr.pfDeduction, 0);
  const totalTDS = payroll.reduce((acc, curr) => acc + curr.tdsDeduction, 0);
  const totalBonuses = payroll.reduce((acc, curr) => acc + curr.bonus, 0);

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              Payroll Processing & Payslips
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
              July 2026 Cycle
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Automated salary calculations based on attendance, statutory PF (12%), ESI, TDS Tax & custom bonuses.
          </p>
        </div>

        {role === 'admin' && (
          <button
            onClick={onProcessAllPayroll}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 transition-all shrink-0"
          >
            <Lock className="w-4 h-4" />
            Lock & Batch Process July Payroll
          </button>
        )}
      </div>

      {/* Summary Stat Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 text-white shadow-md border border-indigo-800">
          <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider block">
            Net Salary Payable
          </span>
          <div className="mt-2 text-2.5xl font-black tracking-tight">
            ₹{totalNetPayout.toLocaleString('en-IN')}
          </div>
          <p className="text-[10px] text-slate-300 mt-1">Direct Bank Transfer Batch Ready</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Provident Fund (PF 12%)
          </span>
          <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
            ₹{totalPF.toLocaleString('en-IN')}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">EPFO Compliance Deductions</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            TDS Tax Withheld
          </span>
          <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
            ₹{totalTDS.toLocaleString('en-IN')}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">Income Tax Department Portal Sync</p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Total Performance Bonuses
          </span>
          <div className="mt-2 text-2xl font-black text-emerald-600 dark:text-emerald-400">
            +₹{totalBonuses.toLocaleString('en-IN')}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">Incentives & Overtime</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/80 dark:border-slate-700">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search payroll by employee name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
          {['all', 'Engineering', 'HR', 'Sales', 'Finance', 'Operations', 'Design'].map((dept) => (
            <button
              key={dept}
              onClick={() => setSelectedDept(dept)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize whitespace-nowrap transition-all ${
                selectedDept === dept
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-600'
              }`}
            >
              {dept === 'all' ? 'All Departments' : dept}
            </button>
          ))}
        </div>
      </div>

      {/* Automated Payroll Table */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4">Base Salary</th>
                <th className="py-3.5 px-4">Effective Days</th>
                <th className="py-3.5 px-4">Earned Salary</th>
                <th className="py-3.5 px-4">Bonus / Incentive</th>
                <th className="py-3.5 px-4">Total Deductions (PF+Tax)</th>
                <th className="py-3.5 px-4">Final Net Salary</th>
                <th className="py-3.5 px-4 text-right">Action / Payslip</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs text-slate-800 dark:text-slate-200">
              {filteredPayroll.map((p) => {
                const totalDeductions = p.pfDeduction + p.esiDeduction + p.tdsDeduction + (p.deduction || 0);

                return (
                  <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">{p.employeeName}</div>
                      <span className="text-[10px] text-slate-400">{p.department}</span>
                    </td>

                    <td className="py-3.5 px-4 font-medium">
                      ₹{p.baseSalary.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3.5 px-4 font-semibold">
                      {p.presentDays}/{p.workingDays} days
                    </td>

                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white">
                      ₹{p.earnedSalary.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3.5 px-4 text-emerald-600 dark:text-emerald-400 font-bold">
                      +₹{p.bonus.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3.5 px-4 text-rose-600 dark:text-rose-400 font-bold">
                      -₹{totalDeductions.toLocaleString('en-IN')}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-black text-slate-900 dark:text-white text-sm bg-slate-100 dark:bg-slate-700/60 px-2.5 py-1 rounded-lg inline-block">
                        ₹{p.netSalary.toLocaleString('en-IN')}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {role === 'admin' && (
                          <button
                            onClick={() => handleOpenEdit(p)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:text-indigo-600 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 transition-colors"
                            title="Adjust Bonus or Deductions"
                          >
                            Adjust
                          </button>
                        )}

                        <button
                          onClick={() => onOpenPayslipModal(p)}
                          className="flex items-center gap-1 px-3 py-1 text-[11px] font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-xs transition-all"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          Payslip
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADJUST BONUS / DEDUCTION MODAL */}
      {editingRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl p-6 relative">
            <div className="mb-4">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Adjust Bonus & Deductions
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Employee: <span className="font-bold text-slate-800 dark:text-slate-200">{editingRecord.employeeName}</span>
              </p>
            </div>

            <form onSubmit={handleSaveBonusDeduction} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Performance Bonus / Incentive (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  step={500}
                  value={bonusInput}
                  onChange={(e) => setBonusInput(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Custom Deductions / Loss Pay (₹)
                </label>
                <input
                  type="number"
                  min={0}
                  step={100}
                  value={deductionInput}
                  onChange={(e) => setDeductionInput(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-bold focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Base Salary:</span>
                  <span className="font-bold">₹{editingRecord.baseSalary.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-indigo-600 dark:text-indigo-400 font-bold">
                  <span>Recalculated Net Pay:</span>
                  <span>
                    ₹
                    {Math.max(
                      0,
                      editingRecord.earnedSalary +
                        Number(bonusInput) -
                        Number(deductionInput) -
                        editingRecord.pfDeduction -
                        editingRecord.esiDeduction -
                        editingRecord.tdsDeduction
                    ).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setEditingRecord(null)}
                  className="px-4 py-2 rounded-xl font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20"
                >
                  Apply & Recalculate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
