import React, { useState } from 'react';
import { Laptop, Plus, CheckCircle2, ShieldAlert, User, Cpu } from 'lucide-react';
import { AssetCustomItem } from '../types';

interface AssetsInventoryProps {
  assets: AssetCustomItem[];
  onAddAsset: (a: AssetCustomItem) => void;
}

export const AssetsInventory: React.FC<AssetsInventoryProps> = ({
  assets: initialAssets,
  onAddAsset,
}) => {
  const [assetList, setAssetList] = useState<AssetCustomItem[]>(initialAssets);
  const [showAddModal, setShowAddModal] = useState(false);

  const [name, setName] = useState('');
  const [category, setCategory] = useState<AssetCustomItem['category']>('Laptop');
  const [serial, setSerial] = useState('');
  const [assignedTo, setAssignedTo] = useState('Vikram Malhotra');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newAst: AssetCustomItem = {
      id: `AST-${Date.now()}`,
      name,
      category,
      serialNumber: serial || `SN-${Math.floor(Math.random() * 900000 + 100000)}`,
      assignedToEmployeeName: assignedTo,
      assignedDate: new Date().toISOString().split('T')[0],
      status: 'Assigned',
      warrantyExpiry: '2028-12-31',
    };

    setAssetList([...assetList, newAst]);
    onAddAsset(newAst);
    setShowAddModal(false);
    setName('');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              IT Hardware
            </span>
            <span className="text-xs text-slate-400">Asset Tracking & Maintenance</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Company Assets Inventory
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Track laptops, monitors, smartphones, access cards, and hardware serial numbers.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          Assign Asset
        </button>
      </div>

      {/* Assets Table */}
      <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
              <th className="p-3.5">Asset Name</th>
              <th className="p-3.5">Category</th>
              <th className="p-3.5">Serial Number</th>
              <th className="p-3.5">Assigned Employee</th>
              <th className="p-3.5">Assigned Date</th>
              <th className="p-3.5">Warranty Expiry</th>
              <th className="p-3.5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
            {assetList.map((ast) => (
              <tr key={ast.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                <td className="p-3.5 font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-indigo-600" />
                  {ast.name}
                </td>
                <td className="p-3.5 text-indigo-600 dark:text-indigo-400 font-semibold">{ast.category}</td>
                <td className="p-3.5 font-mono font-bold">{ast.serialNumber}</td>
                <td className="p-3.5 font-bold text-slate-900 dark:text-white">{ast.assignedToEmployeeName}</td>
                <td className="p-3.5 text-slate-400">{ast.assignedDate}</td>
                <td className="p-3.5 text-slate-400">{ast.warrantyExpiry}</td>
                <td className="p-3.5">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-bold text-[10px]">
                    {ast.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Asset Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Assign IT Asset</h3>
            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Asset Model Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MacBook Pro M3 Max 16-inch"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Laptop">Laptop</option>
                    <option value="Monitor">Monitor</option>
                    <option value="Mobile Device">Mobile Device</option>
                    <option value="Peripherals">Peripherals</option>
                    <option value="Access Card">Access Card</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Serial Number</label>
                  <input
                    type="text"
                    placeholder="e.g. C02G1234MD6R"
                    value={serial}
                    onChange={(e) => setSerial(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Assigned Employee</label>
                <input
                  type="text"
                  required
                  value={assignedTo}
                  onChange={(e) => setAssignedTo(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
