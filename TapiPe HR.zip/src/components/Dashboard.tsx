import React from 'react';
import {
  Users,
  DollarSign,
  UserCheck,
  UserX,
  TrendingUp,
  Receipt,
  UserPlus,
  CalendarCheck,
  FileSpreadsheet,
  ArrowUpRight,
  Clock,
  Briefcase,
  CheckCircle2,
  AlertCircle,
  Clock3,
} from 'lucide-react';
import { Employee, AttendanceRecord, PayrollRecord, NavigationPage, UserRole } from '../types';

interface DashboardProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  payroll: PayrollRecord[];
  monthlyTrends: { month: string; amount: number }[];
  onNavigate: (page: NavigationPage) => void;
  role: UserRole;
  onOpenAddEmployee: () => void;
  onOpenCheckInModal: () => void;
  onOpenPayslipModal: (record: PayrollRecord) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  employees,
  attendance,
  payroll,
  monthlyTrends,
  onNavigate,
  role,
  onOpenAddEmployee,
  onOpenCheckInModal,
  onOpenPayslipModal,
}) => {
  // Calculated Metrics
  const totalEmployees = employees.length;
  const activeEmployees = employees.filter((e) => e.status === 'active').length;

  const totalPayrollCost = payroll.reduce((acc, curr) => acc + curr.netSalary, 0);
  const totalGrossBudget = employees.reduce((acc, curr) => acc + curr.salary, 0);

  const presentToday = attendance.filter((a) => a.status === 'present').length;
  const absentToday = attendance.filter((a) => a.status === 'absent').length;
  const halfDayToday = attendance.filter((a) => a.status === 'half_day').length;
  const leaveToday = attendance.filter((a) => a.status === 'on_leave').length;

  const attendancePercentage = totalEmployees > 0 ? Math.round((presentToday / totalEmployees) * 100) : 0;

  // Pie chart calculation angles for Donut Chart
  const totalAtt = totalEmployees || 1;
  const pPct = presentToday / totalAtt;
  const hPct = halfDayToday / totalAtt;
  const lPct = leaveToday / totalAtt;
  const aPct = absentToday / totalAtt;

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Top Welcome & Quick Actions Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Fintech HR Command Center
            </span>
            <span className="text-xs text-slate-400">July 2026 Payroll Cycle</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {role === 'admin' ? 'HR Administrator' : 'Staff Member'} 👋
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Real-time automated salary calculation, attendance monitoring & compliance reports.
          </p>
        </div>

        {/* Quick Shortcut Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenCheckInModal}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 transition-all hover:scale-102"
          >
            <Clock3 className="w-4 h-4" />
            Check-In Today
          </button>

          {role === 'admin' && (
            <>
              <button
                onClick={onOpenAddEmployee}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition-all hover:scale-102"
              >
                <UserPlus className="w-4 h-4" />
                Add Employee
              </button>
              <button
                onClick={() => onNavigate('payroll')}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 shadow-sm transition-all"
              >
                <Receipt className="w-4 h-4" />
                Process Payroll
              </button>
            </>
          )}
        </div>
      </div>

      {/* 1. Stat Cards Grid (Razorpay Modern Style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1: Total Employees */}
        <div
          onClick={() => onNavigate('employees')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Employees
            </span>
            <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {totalEmployees}
            </span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> {activeEmployees} Active
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>6 Departments</span>
            <span className="text-indigo-600 dark:text-indigo-400 font-medium group-hover:underline flex items-center">
              View all <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Stat 2: Total Monthly Salary */}
        <div
          onClick={() => onNavigate('payroll')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Salary Payout
            </span>
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-1">
            <span className="text-2.5xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              ₹{totalPayrollCost.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Gross Budget: ₹{totalGrossBudget.toLocaleString('en-IN')}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-medium group-hover:underline flex items-center">
              Details <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Stat 3: Present Today */}
        <div
          onClick={() => onNavigate('attendance')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Present Today
            </span>
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {presentToday}
            </span>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
              {attendancePercentage}% Turnout
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{halfDayToday} Half Day</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-medium group-hover:underline flex items-center">
              Attendance Log <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>

        {/* Stat 4: Absent / On Leave */}
        <div
          onClick={() => onNavigate('attendance')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Absent / On Leave
            </span>
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 group-hover:scale-110 transition-transform">
              <UserX className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {absentToday + leaveToday}
            </span>
            <span className="text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-2 py-0.5 rounded-full">
              {absentToday} Unexcused
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>{leaveToday} On Approved Leave</span>
            <span className="text-rose-600 dark:text-rose-400 font-medium group-hover:underline flex items-center">
              Check Status <ArrowUpRight className="w-3 h-3 ml-0.5" />
            </span>
          </div>
        </div>
      </div>

      {/* 2. Charts Section (Pie Chart + Monthly Salary Graph) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pie/Donut Chart for Today's Attendance */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Attendance Breakdown</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Live status for today</p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
              {totalEmployees} Employees
            </span>
          </div>

          {/* Interactive Custom SVG Donut Chart */}
          <div className="py-6 flex flex-col items-center justify-center relative">
            <div className="w-44 h-44 relative flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                {/* Background Circle */}
                <path
                  className="text-slate-100 dark:text-slate-700 stroke-current"
                  strokeWidth="3.8"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                {/* Present Segment (Emerald) */}
                <path
                  className="text-emerald-500 stroke-current transition-all duration-1000 ease-out"
                  strokeDasharray={`${pPct * 100}, 100`}
                  strokeDashoffset="0"
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                {/* Half Day Segment (Amber) */}
                <path
                  className="text-amber-500 stroke-current transition-all duration-1000 ease-out"
                  strokeDasharray={`${hPct * 100}, 100`}
                  strokeDashoffset={`-${pPct * 100}`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                {/* On Leave Segment (Indigo) */}
                <path
                  className="text-indigo-500 stroke-current transition-all duration-1000 ease-out"
                  strokeDasharray={`${lPct * 100}, 100`}
                  strokeDashoffset={`-${(pPct + hPct) * 100}`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                {/* Absent Segment (Rose) */}
                <path
                  className="text-rose-500 stroke-current transition-all duration-1000 ease-out"
                  strokeDasharray={`${aPct * 100}, 100`}
                  strokeDashoffset={`-${(pPct + hPct + lPct) * 100}`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              {/* Inner Center Label */}
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-2xl font-black text-slate-900 dark:text-white">
                  {attendancePercentage}%
                </span>
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Present
                </span>
              </div>
            </div>
          </div>

          {/* Donut Legend */}
          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-100 dark:border-slate-700/60">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
              <span className="text-slate-600 dark:text-slate-300">Present: </span>
              <span className="font-bold text-slate-900 dark:text-white ml-auto">{presentToday}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0"></span>
              <span className="text-slate-600 dark:text-slate-300">Half Day: </span>
              <span className="font-bold text-slate-900 dark:text-white ml-auto">{halfDayToday}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0"></span>
              <span className="text-slate-600 dark:text-slate-300">On Leave: </span>
              <span className="font-bold text-slate-900 dark:text-white ml-auto">{leaveToday}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0"></span>
              <span className="text-slate-600 dark:text-slate-300">Absent: </span>
              <span className="font-bold text-slate-900 dark:text-white ml-auto">{absentToday}</span>
            </div>
          </div>
        </div>

        {/* Monthly Salary Payout Graph (Bar Chart) */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Monthly Salary Expense Graph</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Total payroll payout history (2026)</p>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            >
              Full Report <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Bar Chart Bars */}
          <div className="py-6 px-2 flex items-end justify-between gap-3 h-56">
            {monthlyTrends.map((trend, idx) => {
              const maxVal = 700000;
              const heightPct = Math.round((trend.amount / maxVal) * 100);
              const isCurrent = idx === monthlyTrends.length - 1;

              return (
                <div key={trend.month} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-bold text-white bg-slate-900 px-2 py-1 rounded-md shadow-lg pointer-events-none whitespace-nowrap mb-1">
                    ₹{(trend.amount / 1000).toFixed(1)}k
                  </div>

                  {/* Bar */}
                  <div className="w-full max-w-[36px] bg-slate-100 dark:bg-slate-700/50 rounded-t-xl overflow-hidden flex items-end h-full">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-t-xl transition-all duration-700 ${
                        isCurrent
                          ? 'bg-gradient-to-t from-indigo-600 to-indigo-400 shadow-md shadow-indigo-500/30'
                          : 'bg-gradient-to-t from-slate-400 to-slate-300 dark:from-slate-600 dark:to-slate-500 group-hover:from-indigo-500 group-hover:to-indigo-300'
                      }`}
                    />
                  </div>

                  {/* Label */}
                  <span
                    className={`text-xs font-semibold ${
                      isCurrent ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {trend.month}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Graph Legend & Insights */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-indigo-600 inline-block"></span>
              <span>Current Month (Jul 2026): ₹6,37,000</span>
            </div>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> +1.6% vs June
            </span>
          </div>
        </div>
      </div>

      {/* 3. Recent Payroll Runs & Live Today's Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Payroll Runs */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">July 2026 Payroll Summary</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Processed salary records</p>
            </div>
            <button
              onClick={() => onNavigate('payroll')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              View All Payroll
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 mt-2">
            {payroll.slice(0, 4).map((p) => (
              <div key={p.id} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs shrink-0">
                    {p.employeeName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">{p.employeeName}</h4>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">{p.department}</span>
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <div>
                    <div className="text-xs font-black text-slate-900 dark:text-white">
                      ₹{p.netSalary.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded">
                      Processed
                    </span>
                  </div>
                  <button
                    onClick={() => onOpenPayslipModal(p)}
                    className="p-1.5 text-xs text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 rounded-lg border border-indigo-200 dark:border-indigo-800 transition-colors font-medium"
                    title="View Payslip"
                  >
                    Slip
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Attendance Stream */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Today's Check-In Feed</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Live employee logs</p>
            </div>
            <button
              onClick={() => onNavigate('attendance')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              Full Log
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 mt-2">
            {attendance.slice(0, 4).map((att) => (
              <div key={att.id} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold text-xs shrink-0">
                    {att.employeeName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">{att.employeeName}</h4>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      In: {att.checkIn || '--:--'} • Out: {att.checkOut || '--:--'}
                    </span>
                  </div>
                </div>

                <div>
                  {att.status === 'present' && (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Present
                    </span>
                  )}
                  {att.status === 'half_day' && (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Half Day
                    </span>
                  )}
                  {att.status === 'absent' && (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> Absent
                    </span>
                  )}
                  {att.status === 'on_leave' && (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
                      <Briefcase className="w-3 h-3" /> On Leave
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
