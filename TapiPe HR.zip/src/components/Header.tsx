import React, { useState } from 'react';
import {
  Search,
  Bell,
  Sun,
  Moon,
  Sparkles,
  Shield,
  User,
  CheckCheck,
  Building,
  UserCheck,
  LogOut,
} from 'lucide-react';
import { UserRole, NotificationItem, UserAccount } from '../types';

interface HeaderProps {
  currentUser: UserAccount;
  onRoleChange: (role: UserRole) => void;
  onLogout: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  openAIChat: () => void;
  openSearch: () => void;
  openProfileModal?: () => void;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onClearNotifications: () => void;
  companyName: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onRoleChange,
  onLogout,
  isDarkMode,
  onToggleTheme,
  openAIChat,
  openSearch,
  openProfileModal,
  notifications,
  onMarkNotificationRead,
  onClearNotifications,
  companyName,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const rolesList: { id: UserRole; label: string; name: string }[] = [
    { id: 'super_admin', label: 'Super Admin', name: 'Sumit' },
    { id: 'admin', label: 'Admin', name: 'Vikram Malhotra' },
    { id: 'hr', label: 'HR Manager', name: 'Priya Patel' },
    { id: 'manager', label: 'Engineering Manager', name: 'Rohan Sharma' },
    { id: 'staff', label: 'Staff Employee', name: 'Aarav Mehta' },
    { id: 'employee', label: 'Employee Self-Service', name: 'Kavita Singh' },
  ];

  return (
    <header className="sticky top-0 z-20 h-16 px-4 md:px-6 flex items-center justify-between border-b backdrop-blur-md transition-colors bg-white/90 dark:bg-slate-900/90 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 shadow-xs">
      {/* Search Input Trigger */}
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <button
          onClick={openSearch}
          className="w-full flex items-center gap-2.5 px-3.5 py-2 text-xs font-medium rounded-xl border transition-all text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-purple-400 dark:hover:border-purple-500 shadow-2xs group"
        >
          <Search className="w-4 h-4 text-slate-400 group-hover:text-purple-500" />
          <span className="truncate">Search employees, payslips, departments, docs...</span>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 ml-auto px-2 py-0.5 text-[10px] font-semibold text-slate-400 bg-slate-200 dark:bg-slate-700 rounded border border-slate-300 dark:border-slate-600">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right Utility Bar */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Active Role Quick Switcher */}
        <div className="relative">
          <button
            onClick={() => setShowRoleDropdown(!showRoleDropdown)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-all shadow-2xs"
          >
            <Shield className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span className="hidden sm:inline capitalize font-extrabold">{currentUser.role.replace('_', ' ')}</span>
          </button>

          {showRoleDropdown && (
            <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl z-50 p-2 space-y-1 animate-in fade-in slide-in-from-top-2">
              <div className="px-2.5 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Simulate Role
              </div>
              {rolesList.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    onRoleChange(r.id);
                    setShowRoleDropdown(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    currentUser.role === r.id
                      ? 'bg-purple-600 text-white font-bold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  <div className="flex flex-col text-left">
                    <span>{r.label}</span>
                    <span className={`text-[10px] ${currentUser.role === r.id ? 'text-purple-200' : 'text-slate-400'}`}>
                      {r.name}
                    </span>
                  </div>
                  {currentUser.role === r.id && <UserCheck className="w-4 h-4 text-white shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ASK SUMIT AI Button */}
        <button
          onClick={openAIChat}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-black shadow-sm shadow-purple-500/25 transition-all hover:scale-105"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>ASK SUMIT</span>
        </button>

        {/* Theme Toggle Button */}
        <button
          onClick={onToggleTheme}
          className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
        </button>

        {/* Notification Bell Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white shadow-xs animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Popover */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
              <div className="p-3.5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between bg-slate-50 dark:bg-slate-800/50">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-800 dark:text-slate-100">Notifications</span>
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 text-[10px] font-semibold bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 rounded-full">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                {notifications.length > 0 && (
                  <button
                    onClick={onClearNotifications}
                    className="text-xs text-slate-500 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 flex items-center gap-1 font-medium"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    Clear all
                  </button>
                )}
              </div>

              <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/50">
                {notifications.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    No notifications right now
                  </div>
                ) : (
                  notifications.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onMarkNotificationRead(item.id)}
                      className={`p-3.5 transition-colors cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700/50 flex items-start gap-3 ${
                        !item.read ? 'bg-purple-50/40 dark:bg-purple-950/20' : ''
                      }`}
                    >
                      <div
                        className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                          !item.read ? 'bg-purple-600' : 'bg-transparent'
                        }`}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate">
                            {item.title}
                          </h4>
                          <span className="text-[10px] text-slate-400 shrink-0">{item.time}</span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 line-clamp-2">
                          {item.message}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Account Profile Badge */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-700">
          <button
            onClick={openProfileModal}
            className="flex items-center gap-2 p-1 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-all text-left"
            title="Edit My Profile Settings"
          >
            {currentUser.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-9 h-9 rounded-full object-cover border border-purple-400/40 shadow-xs"
              />
            ) : (
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 via-indigo-600 to-purple-500 text-white flex items-center justify-center font-extrabold text-xs shadow-xs border border-purple-400/40">
                {currentUser.name.substring(0, 2).toUpperCase()}
              </div>
            )}
            <div className="hidden lg:flex flex-col text-left">
              <span className="text-xs font-extrabold text-slate-800 dark:text-slate-100 leading-tight">
                {currentUser.name}
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1 font-medium">
                <Building className="w-2.5 h-2.5" /> {currentUser.email}
              </span>
            </div>
          </button>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            className="p-2 ml-1 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 transition-colors shrink-0"
            title="Sign Out / Logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
