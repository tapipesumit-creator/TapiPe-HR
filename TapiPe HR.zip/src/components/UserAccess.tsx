import React, { useState } from 'react';
import {
  ShieldCheck,
  UserCheck,
  Check,
  X,
  Lock,
  Plus,
  Edit2,
  Trash2,
  UserX,
  Key,
  Shield,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Sliders,
} from 'lucide-react';
import { UserRole, UserAccount, NavigationPage } from '../types';
import { getDefaultPermissionsForRole } from '../services/authStore';

interface UserAccessProps {
  currentUser: UserAccount;
  users: UserAccount[];
  onAddUser: (user: Omit<UserAccount, 'id' | 'createdAt'>) => void;
  onUpdateUser: (user: UserAccount) => void;
  onDeleteUser: (id: string) => void;
  onToggleDisableUser: (id: string) => void;
  onResetPassword: (id: string, newPass: string) => void;
  onRoleChange: (role: UserRole) => void;
}

export const UserAccess: React.FC<UserAccessProps> = ({
  currentUser,
  users,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onToggleDisableUser,
  onResetPassword,
  onRoleChange,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [resetPassUser, setResetPassUser] = useState<UserAccount | null>(null);
  const [permissionsUser, setPermissionsUser] = useState<UserAccount | null>(null);

  // Form State for Add / Edit
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [roleInput, setRoleInput] = useState<UserRole>('employee');

  // Password Reset Form
  const [newPassword, setNewPassword] = useState('');

  // Permissions Form
  const [tempPermissions, setTempPermissions] = useState<Record<NavigationPage, boolean>>(
    getDefaultPermissionsForRole('employee')
  );

  const isSuperAdmin = currentUser.role === 'super_admin';

  // Quick Open Add Modal
  const handleOpenAddModal = () => {
    setNameInput('');
    setEmailInput('');
    setPasswordInput('');
    setRoleInput('employee');
    setShowAddModal(true);
  };

  // Submit Add User
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !emailInput.trim() || !passwordInput.trim()) return;

    onAddUser({
      name: nameInput.trim(),
      email: emailInput.trim(),
      password: passwordInput,
      role: roleInput,
      isDisabled: false,
      permissions: getDefaultPermissionsForRole(roleInput),
    });

    setShowAddModal(false);
  };

  // Quick Open Edit Modal
  const handleOpenEditModal = (user: UserAccount) => {
    setEditingUser(user);
    setNameInput(user.name);
    setEmailInput(user.email);
    setRoleInput(user.role);
  };

  // Submit Edit User
  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      onUpdateUser({
        ...editingUser,
        name: nameInput.trim(),
        email: emailInput.trim(),
        role: roleInput,
        // If role changed, update permissions to role default if desired, or keep current
        permissions: editingUser.role !== roleInput ? getDefaultPermissionsForRole(roleInput) : editingUser.permissions,
      });
      setEditingUser(null);
    }
  };

  // Open Reset Pass
  const handleOpenResetPass = (user: UserAccount) => {
    setResetPassUser(user);
    setNewPassword('');
  };

  const handleResetPassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetPassUser && newPassword.trim()) {
      onResetPassword(resetPassUser.id, newPassword.trim());
      setResetPassUser(null);
    }
  };

  // Open Permissions Modal
  const handleOpenPermissions = (user: UserAccount) => {
    setPermissionsUser(user);
    setTempPermissions({ ...user.permissions });
  };

  const handleSavePermissions = () => {
    if (permissionsUser) {
      onUpdateUser({
        ...permissionsUser,
        permissions: tempPermissions,
      });
      setPermissionsUser(null);
    }
  };

  const allPageKeys: { id: NavigationPage; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard View' },
    { id: 'employees', label: 'Employee Directory' },
    { id: 'attendance', label: 'Attendance & Punch' },
    { id: 'payroll', label: 'Payroll & Payslips' },
    { id: 'salary_structure', label: 'Salary Structure' },
    { id: 'leave_management', label: 'Leave Approvals' },
    { id: 'holiday_calendar', label: 'Holiday Calendar' },
    { id: 'departments_branches', label: 'Depts & Branches' },
    { id: 'recruitment', label: 'Recruitment Jobs' },
    { id: 'document_center', label: 'Document Center' },
    { id: 'performance', label: 'Performance & KPIs' },
    { id: 'assets_inventory', label: 'Assets & IT' },
    { id: 'visitor_helpdesk', label: 'Helpdesk & Visitors' },
    { id: 'notices_announcements', label: 'Company Notices' },
    { id: 'reports', label: 'Reports & Export' },
    { id: 'access', label: 'User RBAC Management' },
    { id: 'settings', label: 'Company Settings' },
    { id: 'audit_logs', label: 'Security Audit Logs' },
  ];

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.role.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRole = roleFilter === 'all' || u.role === roleFilter;

    return matchesSearch && matchesRole;
  });

  const rolesInfo: { id: UserRole; title: string; desc: string; color: string }[] = [
    {
      id: 'super_admin',
      title: 'Super Admin (Sumit)',
      desc: 'Master unrestricted access over entire company, global settings, RBAC permissions, and user accounts.',
      color: 'bg-purple-600',
    },
    {
      id: 'admin',
      title: 'Company Admin',
      desc: 'Full operational access to payroll, employee records, reports, and attendance adjustments.',
      color: 'bg-indigo-600',
    },
    {
      id: 'hr',
      title: 'HR Manager',
      desc: 'Access to recruitment, onboarding, leave approvals, performance reviews, and document generation.',
      color: 'bg-pink-600',
    },
    {
      id: 'manager',
      title: 'Engineering Manager',
      desc: 'Access to team attendance, leave approvals, performance KPI assignments, and department goals.',
      color: 'bg-blue-600',
    },
    {
      id: 'staff',
      title: 'Staff Member',
      desc: 'Standard employee self-service to check-in/out, view payslips, apply for leave, and view notices.',
      color: 'bg-emerald-600',
    },
    {
      id: 'employee',
      title: 'Employee Self-Service',
      desc: 'Personal portal to manage personal bank details, download Form 16, and raise helpdesk tickets.',
      color: 'bg-amber-600',
    },
  ];

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              User Management & Granular RBAC
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
              Super Admin Control
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Manage system user accounts, assign roles, reset passwords, enable/disable access, and configure per-page permissions.
          </p>
        </div>

        {isSuperAdmin && (
          <button
            onClick={handleOpenAddModal}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-600/30 transition-all shrink-0"
          >
            <Plus className="w-4 h-4" />
            Add New System User
          </button>
        )}
      </div>

      {/* User Accounts Management Section */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs overflow-hidden space-y-4 p-5">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Active System User Accounts</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 font-bold text-slate-600 dark:text-slate-300">
              {users.length} Users
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search user name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 focus:outline-none"
            >
              <option value="all">All Roles</option>
              <option value="super_admin">Super Admin</option>
              <option value="admin">Admin</option>
              <option value="hr">HR Manager</option>
              <option value="manager">Manager</option>
              <option value="staff">Staff</option>
              <option value="employee">Employee</option>
            </select>
          </div>
        </div>

        {/* Users Table */}
        <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <th className="py-3 px-4">User Details</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Account Status</th>
                <th className="py-3 px-4">Page Access</th>
                <th className="py-3 px-4 text-right">Super Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
              {filteredUsers.map((u) => {
                const allowedPageCount = Object.values(u.permissions).filter(Boolean).length;
                const isSelf = u.id === currentUser.id;

                return (
                  <tr key={u.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        {u.name}
                        {isSelf && (
                          <span className="px-1.5 py-0.2 text-[9px] font-black uppercase bg-indigo-500 text-white rounded">
                            You
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">{u.email}</span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase ${
                          u.role === 'super_admin'
                            ? 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-300 dark:border-purple-800'
                            : u.role === 'admin'
                            ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300'
                            : u.role === 'hr'
                            ? 'bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300'
                            : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      {u.isDisabled ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 inline-flex items-center gap-1">
                          <UserX className="w-3 h-3" /> Disabled
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Active
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        {u.role === 'super_admin' ? 'Unrestricted (18/18)' : `${allowedPageCount}/18 Pages`}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      {isSuperAdmin ? (
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Granular Permissions Button */}
                          <button
                            onClick={() => handleOpenPermissions(u)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-purple-600 dark:text-purple-400"
                            title="Assign Custom Page Permissions"
                          >
                            <Sliders className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit User Button */}
                          <button
                            onClick={() => handleOpenEditModal(u)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-indigo-600 dark:text-indigo-400"
                            title="Edit User Details & Role"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Reset Password Button */}
                          <button
                            onClick={() => handleOpenResetPass(u)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-amber-600 dark:text-amber-400"
                            title="Reset Password"
                          >
                            <Key className="w-3.5 h-3.5" />
                          </button>

                          {/* Disable / Enable Toggle Button */}
                          {!isSelf && (
                            <button
                              onClick={() => onToggleDisableUser(u.id)}
                              className={`p-1.5 rounded-lg border text-xs font-bold transition-colors ${
                                u.isDisabled
                                  ? 'border-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600'
                                  : 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-slate-600 dark:text-slate-300'
                              }`}
                              title={u.isDisabled ? 'Enable User Account' : 'Disable User Account'}
                            >
                              {u.isDisabled ? 'Enable' : 'Disable'}
                            </button>
                          )}

                          {/* Delete User Button */}
                          {!isSelf && (
                            <button
                              onClick={() => {
                                if (confirm(`Are you sure you want to delete user account "${u.name}" (${u.email})?`)) {
                                  onDeleteUser(u.id);
                                }
                              }}
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-rose-50 dark:hover:bg-rose-950 text-rose-600 dark:text-rose-400"
                              title="Delete User"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">Super Admin Restricted</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Role Switcher & Descriptions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rolesInfo.map((r) => {
          const isActive = currentUser.role === r.id;
          return (
            <div
              key={r.id}
              onClick={() => onRoleChange(r.id)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                isActive
                  ? 'bg-slate-900 text-white border-purple-500 shadow-xl ring-2 ring-purple-500/30'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white hover:border-purple-400'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-2 rounded-xl text-white ${r.color}`}>
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <h3 className="font-extrabold text-sm">{r.title}</h3>
                </div>
                {isActive && (
                  <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500 text-slate-950">
                    Active Session
                  </span>
                )}
              </div>

              <p className="text-xs opacity-80 leading-relaxed">{r.desc}</p>
            </div>
          );
        })}
      </div>

      {/* ADD USER MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md shadow-2xl space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">Add New System User</h3>

            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Corporate Email</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. rahul@tapipe.in"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Password</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul@123"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Assigned Role</label>
                <select
                  value={roleInput}
                  onChange={(e) => setRoleInput(e.target.value as UserRole)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold"
                >
                  <option value="super_admin">Super Admin (Unrestricted)</option>
                  <option value="admin">Company Admin</option>
                  <option value="hr">HR Manager</option>
                  <option value="manager">Engineering Manager</option>
                  <option value="staff">Staff Member</option>
                  <option value="employee">Employee Self-Service</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-md shadow-purple-600/30"
                >
                  Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT USER MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md shadow-2xl space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">Edit User Account & Role</h3>

            <form onSubmit={handleEditSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Corporate Email</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Assigned Role</label>
                <select
                  value={roleInput}
                  onChange={(e) => setRoleInput(e.target.value as UserRole)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-bold"
                >
                  <option value="super_admin">Super Admin (Unrestricted)</option>
                  <option value="admin">Company Admin</option>
                  <option value="hr">HR Manager</option>
                  <option value="manager">Engineering Manager</option>
                  <option value="staff">Staff Member</option>
                  <option value="employee">Employee Self-Service</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 text-white font-bold shadow-md shadow-purple-600/30"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RESET PASSWORD MODAL */}
      {resetPassUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md shadow-2xl space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              Reset Password for {resetPassUser.name}
            </h3>

            <form onSubmit={handleResetPassSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">New Password</label>
                <input
                  type="text"
                  required
                  placeholder="Enter new password..."
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setResetPassUser(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 text-white font-bold shadow-md"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* GRANULAR PERMISSIONS MODAL */}
      {permissionsUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-2xl shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Assign Granular Page Permissions
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Configuring explicit access rights for <span className="font-bold text-purple-600 dark:text-purple-400">{permissionsUser.name}</span> ({permissionsUser.email})
              </p>
            </div>

            <div className="flex-1 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-2 p-1 text-xs">
              {allPageKeys.map((p) => {
                const isAllowed = tempPermissions[p.id] ?? false;
                return (
                  <div
                    key={p.id}
                    onClick={() =>
                      setTempPermissions({
                        ...tempPermissions,
                        [p.id]: !isAllowed,
                      })
                    }
                    className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between transition-all ${
                      isAllowed
                        ? 'bg-purple-50/60 dark:bg-purple-950/40 border-purple-400/80 text-slate-900 dark:text-white font-bold'
                        : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <span>{p.label}</span>
                    <input
                      type="checkbox"
                      checked={isAllowed}
                      onChange={() => {}} // Handled by div click
                      className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
                    />
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-700 shrink-0">
              <button
                type="button"
                onClick={() => setPermissionsUser(null)}
                className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-bold hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePermissions}
                className="px-5 py-2 rounded-xl bg-purple-600 text-white font-bold shadow-md shadow-purple-600/30"
              >
                Save Page Permissions
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
