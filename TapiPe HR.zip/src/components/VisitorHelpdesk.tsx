import React, { useState } from 'react';
import { HelpCircle, Plus, CheckCircle2, Clock, UserCheck, MessageSquare } from 'lucide-react';
import { SupportTicket, VisitorLog } from '../types';

interface VisitorHelpdeskProps {
  tickets: SupportTicket[];
  visitors: VisitorLog[];
  onAddTicket: (t: SupportTicket) => void;
  onAddVisitor: (v: VisitorLog) => void;
}

export const VisitorHelpdesk: React.FC<VisitorHelpdeskProps> = ({
  tickets: initialTickets,
  visitors: initialVisitors,
  onAddTicket,
  onAddVisitor,
}) => {
  const [activeTab, setActiveTab] = useState<'tickets' | 'visitors'>('tickets');
  const [ticketList, setTicketList] = useState<SupportTicket[]>(initialTickets);
  const [visitorList, setVisitorList] = useState<VisitorLog[]>(initialVisitors);

  const [showTicketModal, setShowTicketModal] = useState(false);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<SupportTicket['category']>('Payroll');
  const [priority, setPriority] = useState<SupportTicket['priority']>('High');

  const [showVisitorModal, setShowVisitorModal] = useState(false);
  const [vName, setVName] = useState('');
  const [vPhone, setVPhone] = useState('');
  const [vPurpose, setVPurpose] = useState('Client Meeting');
  const [vHost, setVHost] = useState('Vikram Malhotra');

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) return;

    const newT: SupportTicket = {
      id: `TCK-${Date.now()}`,
      employeeId: 'EMP-105',
      employeeName: 'Aarav Mehta',
      category,
      subject,
      description: subject,
      priority,
      status: 'Open',
      createdDate: new Date().toISOString().split('T')[0],
    };

    setTicketList([newT, ...ticketList]);
    onAddTicket(newT);
    setShowTicketModal(false);
    setSubject('');
  };

  const handleVisitorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vName.trim()) return;

    const newV: VisitorLog = {
      id: `VIS-${Date.now()}`,
      visitorName: vName,
      phone: vPhone || '+91 99887 76655',
      company: 'External Partner',
      purpose: vPurpose,
      hostEmployeeName: vHost,
      checkInTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: new Date().toISOString().split('T')[0],
      status: 'Inside',
    };

    setVisitorList([newV, ...visitorList]);
    onAddVisitor(newV);
    setShowVisitorModal(false);
    setVName('');
  };

  return (
    <div className="space-y-6 pb-8 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Operations & Desk
            </span>
            <span className="text-xs text-slate-400">Helpdesk & Visitor Security</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Helpdesk Tickets & Visitor Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Resolve HR/Payroll support queries and manage office reception visitor logs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'tickets' ? (
            <button
              onClick={() => setShowTicketModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              Raise Support Ticket
            </button>
          ) : (
            <button
              onClick={() => setShowVisitorModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md transition-all shrink-0"
            >
              <Plus className="w-4 h-4" />
              Check-In Visitor
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-white dark:bg-slate-800/90 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm text-xs font-bold w-max">
        <button
          onClick={() => setActiveTab('tickets')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'tickets'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          Support Tickets ({ticketList.length})
        </button>
        <button
          onClick={() => setActiveTab('visitors')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'visitors'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
          }`}
        >
          Visitor Logs ({visitorList.length})
        </button>
      </div>

      {/* Support Tickets View */}
      {activeTab === 'tickets' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {ticketList.map((tck) => (
            <div
              key={tck.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 shadow-sm space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base">{tck.subject}</h3>
                  <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">{tck.category} Category</span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    tck.priority === 'High'
                      ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300'
                      : 'bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300'
                  }`}
                >
                  {tck.priority} Priority
                </span>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>By: {tck.employeeName}</span>
                <span className="font-bold text-slate-900 dark:text-white">{tck.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Visitor Logs View */}
      {activeTab === 'visitors' && (
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-700">
                <th className="p-3.5">Visitor Name</th>
                <th className="p-3.5">Phone</th>
                <th className="p-3.5">Company</th>
                <th className="p-3.5">Purpose</th>
                <th className="p-3.5">Host Employee</th>
                <th className="p-3.5">Check-In Time</th>
                <th className="p-3.5">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium text-slate-800 dark:text-slate-200">
              {visitorList.map((vis) => (
                <tr key={vis.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                  <td className="p-3.5 font-bold text-slate-900 dark:text-white">{vis.visitorName}</td>
                  <td className="p-3.5">{vis.phone}</td>
                  <td className="p-3.5 font-semibold text-indigo-600 dark:text-indigo-400">{vis.company}</td>
                  <td className="p-3.5">{vis.purpose}</td>
                  <td className="p-3.5 font-bold">{vis.hostEmployeeName}</td>
                  <td className="p-3.5 font-mono">{vis.checkInTime}</td>
                  <td className="p-3.5">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-bold text-[10px]">
                      {vis.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Ticket Modal */}
      {showTicketModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Raise Support Ticket</h3>
            <form onSubmit={handleTicketSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Query Subject</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Form 16 Tax Certificate Request"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Payroll">Payroll</option>
                    <option value="IT Support">IT Support</option>
                    <option value="HR Policies">HR Policies</option>
                    <option value="Leave & Attendance">Leave & Attendance</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowTicketModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Visitor Modal */}
      {showVisitorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Check-In Office Visitor</h3>
            <form onSubmit={handleVisitorSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Visitor Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Chandra"
                  value={vName}
                  onChange={(e) => setVName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Phone Number</label>
                <input
                  type="text"
                  placeholder="+91 98000 00000"
                  value={vPhone}
                  onChange={(e) => setVPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Host Employee</label>
                <input
                  type="text"
                  required
                  value={vHost}
                  onChange={(e) => setVHost(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowVisitorModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold">
                  Save Check-In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
