import { UserAccount, UserRole, NavigationPage } from '../types';

const STORAGE_USERS_KEY = 'tapipe_hr_users_v2';
const STORAGE_SESSION_KEY = 'tapipe_hr_current_session_v2';

export function getDefaultPermissionsForRole(role: UserRole): Record<NavigationPage, boolean> {
  const allTrue: Record<NavigationPage, boolean> = {
    dashboard: true,
    employees: true,
    attendance: true,
    payroll: true,
    salary_structure: true,
    leave_management: true,
    holiday_calendar: true,
    departments_branches: true,
    recruitment: true,
    document_center: true,
    performance: true,
    assets_inventory: true,
    visitor_helpdesk: true,
    notices_announcements: true,
    reports: true,
    access: true,
    settings: true,
    audit_logs: true,
  };

  if (role === 'super_admin') {
    return allTrue;
  }

  if (role === 'admin') {
    return {
      ...allTrue,
      access: true, // Admin can view access
    };
  }

  if (role === 'hr') {
    return {
      dashboard: true,
      employees: true,
      attendance: true,
      payroll: false,
      salary_structure: false,
      leave_management: true,
      holiday_calendar: true,
      departments_branches: true,
      recruitment: true,
      document_center: true,
      performance: true,
      assets_inventory: true,
      visitor_helpdesk: true,
      notices_announcements: true,
      reports: true,
      access: false,
      settings: false,
      audit_logs: false,
    };
  }

  if (role === 'manager') {
    return {
      dashboard: true,
      employees: true,
      attendance: true,
      payroll: false,
      salary_structure: false,
      leave_management: true,
      holiday_calendar: true,
      departments_branches: false,
      recruitment: false,
      document_center: true,
      performance: true,
      assets_inventory: true,
      visitor_helpdesk: true,
      notices_announcements: true,
      reports: false,
      access: false,
      settings: false,
      audit_logs: false,
    };
  }

  // Staff and Employee
  return {
    dashboard: true,
    employees: false,
    attendance: true,
    payroll: false,
    salary_structure: false,
    leave_management: true,
    holiday_calendar: true,
    departments_branches: false,
    recruitment: false,
    document_center: true,
    performance: false,
    assets_inventory: false,
    visitor_helpdesk: true,
    notices_announcements: true,
    reports: false,
    access: false,
    settings: false,
    audit_logs: false,
  };
}

export const INITIAL_DEFAULT_USERS: UserAccount[] = [
  {
    id: 'USR-001',
    name: 'Sumit',
    email: 'admin@tapipe.in',
    password: 'Admin@123',
    role: 'super_admin',
    isDisabled: false,
    permissions: getDefaultPermissionsForRole('super_admin'),
    createdAt: '2026-01-01',
  },
  {
    id: 'USR-002',
    name: 'Vikram Malhotra',
    email: 'admin1@tapipe.in',
    password: 'Admin@123',
    role: 'admin',
    isDisabled: false,
    permissions: getDefaultPermissionsForRole('admin'),
    createdAt: '2026-01-02',
  },
  {
    id: 'USR-003',
    name: 'Priya Patel',
    email: 'hr@tapipe.in',
    password: 'Hr@123',
    role: 'hr',
    isDisabled: false,
    permissions: getDefaultPermissionsForRole('hr'),
    createdAt: '2026-01-03',
  },
  {
    id: 'USR-004',
    name: 'Aarav Mehta',
    email: 'staff@tapipe.in',
    password: 'Staff@123',
    role: 'staff',
    isDisabled: false,
    permissions: getDefaultPermissionsForRole('staff'),
    createdAt: '2026-01-04',
  },
  {
    id: 'USR-005',
    name: 'Kavita Singh',
    email: 'employee@tapipe.in',
    password: 'Employee@123',
    role: 'employee',
    isDisabled: false,
    permissions: getDefaultPermissionsForRole('employee'),
    createdAt: '2026-01-05',
  },
];

export function loadUsersFromStorage(): UserAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_USERS_KEY);
    if (raw) {
      const parsed: UserAccount[] = JSON.parse(raw);
      // Ensure all initial default accounts exist in case storage was created prior
      const existingEmails = new Set(parsed.map((u) => u.email.toLowerCase()));
      let updated = false;

      INITIAL_DEFAULT_USERS.forEach((defUser) => {
        if (!existingEmails.has(defUser.email.toLowerCase())) {
          parsed.push(defUser);
          updated = true;
        }
      });

      if (updated) {
        localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(parsed));
      }
      return parsed;
    }
  } catch (err) {
    console.error('Failed reading users from storage:', err);
  }

  // First run seed
  localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(INITIAL_DEFAULT_USERS));
  return INITIAL_DEFAULT_USERS;
}

export function saveUsersToStorage(users: UserAccount[]): void {
  try {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed saving users to storage:', err);
  }
}

export function loadSessionFromStorage(): UserAccount | null {
  try {
    const rawSession = localStorage.getItem(STORAGE_SESSION_KEY) || sessionStorage.getItem(STORAGE_SESSION_KEY);
    if (rawSession) {
      const user: UserAccount = JSON.parse(rawSession);
      // Verify user is still valid and not disabled
      const allUsers = loadUsersFromStorage();
      const current = allUsers.find((u) => u.id === user.id || u.email.toLowerCase() === user.email.toLowerCase());
      if (current && !current.isDisabled) {
        return current;
      }
    }
  } catch (err) {
    console.error('Failed reading session:', err);
  }
  return null;
}

export function saveSessionToStorage(user: UserAccount | null, rememberMe = true): void {
  try {
    if (!user) {
      localStorage.removeItem(STORAGE_SESSION_KEY);
      sessionStorage.removeItem(STORAGE_SESSION_KEY);
      return;
    }

    const payload = JSON.stringify(user);
    if (rememberMe) {
      localStorage.setItem(STORAGE_SESSION_KEY, payload);
    } else {
      sessionStorage.setItem(STORAGE_SESSION_KEY, payload);
    }
  } catch (err) {
    console.error('Failed saving session:', err);
  }
}

export function getDefaultRedirectPageForRole(role: UserRole): NavigationPage {
  switch (role) {
    case 'super_admin':
    case 'admin':
      return 'dashboard';
    case 'hr':
      return 'dashboard';
    case 'manager':
      return 'dashboard';
    case 'staff':
    case 'employee':
      return 'dashboard';
    default:
      return 'dashboard';
  }
}
