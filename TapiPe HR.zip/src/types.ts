export type NavigationPage =
  | 'dashboard'
  | 'employees'
  | 'attendance'
  | 'payroll'
  | 'salary_structure'
  | 'leave_management'
  | 'holiday_calendar'
  | 'departments_branches'
  | 'recruitment'
  | 'document_center'
  | 'performance'
  | 'assets_inventory'
  | 'visitor_helpdesk'
  | 'notices_announcements'
  | 'reports'
  | 'access'
  | 'settings'
  | 'audit_logs';

export type UserRole = 'super_admin' | 'admin' | 'hr' | 'manager' | 'staff' | 'employee';

export type AttendanceStatus = 'present' | 'absent' | 'half_day' | 'on_leave' | 'late' | 'wfh';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  isDisabled: boolean;
  permissions: Record<NavigationPage, boolean>;
  createdAt: string;
  phone?: string;
  avatarUrl?: string;
  signatureUrl?: string;
}

export interface Employee {
  id: string;
  name: string;
  phone: string;
  email: string;
  salary: number; // Monthly CTC in INR
  department: string;
  designation: string;
  branch: string;
  joiningDate: string;
  status: 'active' | 'on_leave' | 'inactive';
  
  // Bank & Tax Details
  bankName?: string;
  bankAccount: string;
  ifscCode?: string;
  panNumber: string;
  aadhaarNumber?: string;
  passportNumber?: string;
  drivingLicense?: string;
  pfNumber?: string;
  esiNumber?: string;
  uanNumber?: string;

  // Personal Info
  dob?: string;
  gender?: 'Male' | 'Female' | 'Other';
  bloodGroup?: string;
  fatherName?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyRelation?: string;
  nomineeName?: string;
  nomineeRelation?: string;
  address?: string;

  // Education & Experience
  highestQualification?: string;
  experienceYears?: number;
  skills?: string[];

  // Insurance & Medical
  insurancePolicyNo?: string;
  medicalConditions?: string;

  // Document Links & Uploads
  signatureUrl?: string;
  aadhaarDocUrl?: string;
  panDocUrl?: string;
  resumeDocUrl?: string;
  passportDocUrl?: string;
  drivingLicenseDocUrl?: string;
  certificatesDocUrl?: string;
  experienceLetterUrl?: string;
  passbookUrl?: string;
  cancelledChequeUrl?: string;
  joiningKitUrl?: string;

  avatarUrl?: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  checkIn?: string; // HH:MM AM/PM
  checkOut?: string;
  status: AttendanceStatus;
  workHours?: number;
  lateMinutes?: number;
  overtimeHours?: number;
  notes?: string;
  location?: string;
  method?: 'GPS' | 'QR Code' | 'Biometric' | 'Manual' | 'Face ID';
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  designation: string;
  month: string; // e.g., "July 2026"
  baseSalary: number;
  hra: number;
  specialAllowance: number;
  medicalAllowance: number;
  travelAllowance: number;
  internetAllowance: number;
  bonus: number;
  deduction?: number;
  overtimePay: number;
  reimbursements: number;
  
  // Deductions
  workingDays: number;
  presentDays: number;
  halfDays: number;
  paidLeaves: number;
  earnedSalary: number;
  pfDeduction: number; // 12%
  esiDeduction: number; // 0.75%
  tdsDeduction: number; // Income tax
  professionalTax: number;
  loanDeduction: number;
  latePenalty: number;
  
  grossSalary: number;
  netSalary: number;
  status: 'draft' | 'processed' | 'paid';
  paymentDate?: string;
  paymentMode?: 'Bank Transfer' | 'NEFT' | 'UPI' | 'Cheque';
  transactionId?: string;
}

export interface SalaryComponent {
  id: string;
  name: string;
  type: 'earning' | 'deduction';
  calculationType: 'flat' | 'percentage_base';
  value: number;
  taxable: boolean;
  status: 'active' | 'inactive';
}

export interface LeaveApplication {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  type: 'Casual Leave' | 'Sick Leave' | 'Paid Leave' | 'Comp Off' | 'Marriage Leave' | 'Maternity Leave' | 'Paternity Leave';
  startDate: string;
  endDate: string;
  daysCount: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  appliedDate: string;
  approvedBy?: string;
}

export interface HolidayItem {
  id: string;
  date: string; // YYYY-MM-DD
  name: string;
  day: string;
  type: 'National' | 'Regional' | 'Optional';
  branch: string;
  isRecurring?: boolean;
}

export interface DepartmentItem {
  id: string;
  name: string;
  code: string;
  headName: string;
  employeeCount: number;
  monthlyBudget: number;
  color?: string;
  logoUrl?: string;
}

export interface DesignationItem {
  id: string;
  title: string;
  department: string;
  level: string;
  minSalary: number;
  maxSalary: number;
}

export interface BranchItem {
  id: string;
  name: string;
  code: string;
  city: string;
  state: string;
  address: string;
  employeeCount: number;
}

export interface CandidateItem {
  id: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  department: string;
  experienceYears: number;
  stage: 'Applied' | 'Screening' | 'Technical Round' | 'HR Round' | 'Offered' | 'Joined' | 'Rejected';
  expectedCtc: number;
  appliedDate: string;
  rating: number; // 1 to 5
}

export interface JobPosting {
  id: string;
  title: string;
  department: string;
  location: string;
  openings: number;
  type: 'Full-time' | 'Part-time' | 'Contract';
  status: 'Active' | 'Draft' | 'Closed';
  applicantsCount: number;
  postedDate: string;
}

export interface DocumentItem {
  id: string;
  employeeId: string;
  employeeName: string;
  type: 'Offer Letter' | 'Appointment Letter' | 'Experience Letter' | 'Warning Letter' | 'Promotion Letter' | 'Relieving Letter' | 'ID Card' | 'Salary Slip';
  title: string;
  issuedDate: string;
  status: 'Issued' | 'Draft' | 'Archived';
}

export interface PerformanceGoal {
  id: string;
  employeeId: string;
  employeeName: string;
  goalTitle: string;
  kpiMetrics: string;
  targetDate: string;
  progressPercent: number;
  rating: number; // 1 to 5
  status: 'In Progress' | 'Achieved' | 'Overdue';
}

export interface PerformanceReview {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  reviewerName: string;
  reviewPeriod: string;
  rating: number;
  promoted?: boolean;
  comments: string;
}

export interface GoalItem {
  id: string;
  employeeId: string;
  employeeName: string;
  title: string;
  category: string;
  targetDate: string;
  progress: number;
  status: 'In Progress' | 'Achieved' | 'Overdue';
}

export interface AssetItem {
  id: string;
  assetTag: string;
  name: string;
  category: 'Laptop' | 'Mobile' | 'Monitor' | 'Headset' | 'Server/Accessory';
  serialNumber: string;
  assignedEmployeeId?: string;
  assignedEmployeeName?: string;
  issueDate?: string;
  condition: 'Brand New' | 'Good' | 'In Maintenance' | 'Retired';
}

export interface AssetCustomItem {
  id: string;
  name: string;
  category: string;
  serialNumber: string;
  assignedToEmployeeName?: string;
  assignedDate?: string;
  status: 'Assigned' | 'Available' | 'In Repair';
  warrantyExpiry?: string;
}

export interface SupportTicket {
  id: string;
  ticketNo?: string;
  employeeId?: string;
  employeeName: string;
  category: 'IT Support' | 'HR Query' | 'Payroll Discrepancy' | 'Admin & Facilities';
  subject: string;
  description?: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: 'Open' | 'In Progress' | 'Resolved';
  createdAt?: string;
  createdDate?: string;
}

export interface VisitorItem {
  id: string;
  visitorName: string;
  company: string;
  phone: string;
  hostEmployee: string;
  purpose: string;
  checkInTime: string;
  checkOutTime?: string;
  badgeNumber?: string;
  status: 'Inside' | 'Checked Out';
}

export interface VisitorLog {
  id: string;
  visitorName: string;
  phone: string;
  company: string;
  purpose: string;
  hostEmployeeName: string;
  checkInTime: string;
  date: string;
  status: 'Inside' | 'Checked Out';
}

export interface NoticeItem {
  id: string;
  title: string;
  category: 'Policy Update' | 'Announcement' | 'Event' | 'Holiday Notice';
  content: string;
  publishedDate: string;
  author: string;
  pinned: boolean;
}

export interface CompanyNotice {
  id: string;
  title: string;
  content: string;
  category: 'HR Policy' | 'Event' | 'Townhall' | 'Security' | 'Holiday';
  postedBy: string;
  postedDate: string;
  isPinned: boolean;
  scheduledDate?: string;
  isArchived?: boolean;
}

export interface AuditLogItem {
  id: string;
  user: string;
  userName?: string;
  role: string;
  action: string;
  module: string;
  ipAddress: string;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'info' | 'success' | 'warning' | 'payroll';
  read: boolean;
}

export interface DocumentTemplateItem {
  id: string;
  type: string; // 'Offer Letter' | 'Appointment Letter' | 'Confirmation Letter' | 'Promotion Letter' | 'Transfer Letter' | 'Warning Letter' | 'Experience Letter' | 'Relieving Letter' | 'Salary Slip' | 'Joining Kit' | 'ID Card';
  title: string;
  category: string;
  templateBody: string;
  lastUpdated: string;
  isCustom: boolean;
}

export interface LeaveTypeItem {
  id: string;
  name: string;
  code: string;
  maxDaysPerYear: number;
  paid: boolean;
  carryForward: boolean;
  description: string;
}

export interface CompanySettings {
  companyName: string;
  legalEntity: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  gstin: string;
  panNumber: string;
  contactEmail: string;
  contactPhone: string;
  currency: string; // "INR (₹)"
  payCycleDay: number;
  pfRegistrationNo: string;
  esiRegistrationNo: string;

  // Branding & Assets
  companyLogoUrl?: string;
  darkLogoUrl?: string;
  lightLogoUrl?: string;
  faviconUrl?: string;
  website?: string;
  bankName?: string;
  bankAccountNo?: string;
  ifscCode?: string;
  digitalSignatureUrl?: string;
}

export interface SalaryRules {
  standardWorkingDays: number;
  pfPercentage: number;
  esiPercentage: number;
  overtimeRatePerHour: number;
  allowancesPercent: number;

  // On/Off Toggles
  pfEnabled: boolean;
  esiEnabled: boolean;
  ptEnabled: boolean;
  tdsEnabled: boolean;
  loanEnabled: boolean;
  overtimeEnabled: boolean;
  nightShiftEnabled: boolean;
  bonusEnabled: boolean;
  lateDeductionEnabled: boolean;
  reimbursementEnabled: boolean;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}
